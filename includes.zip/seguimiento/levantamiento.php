<?php
/**
 * Levantamiento técnico del edificio (wizard por pasos).
 * Flujo pensado para el recorrido físico real del inspector:
 *   Paso 1: datos del edificio (pisos, aptos por piso, áreas comunes).
 *   Paso 2: recorrido PISO POR PISO. En cada piso: elementos comunes
 *           (ascensor, escaleras…) + los apartamentos de ese piso.
 *   Paso 3: cierre (azotea, tanques, impermeabilización) + resumen final.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/territorial.php';
require_once __DIR__ . '/../includes/seguimiento.php';

requierePermiso('seguimiento', 'ver');
$puedeEditar = puede('seguimiento', 'editar');

$inspeccionId = (int)($_GET['inspeccion'] ?? 0);
if ($inspeccionId <= 0) {
    flash('error', 'Edificio no especificado.');
    header('Location: ' . APP_URL_BASE . 'seguimiento/index.php');
    exit;
}

$insp = segInspeccion($inspeccionId);
if (!$insp) {
    flash('error', 'El edificio no existe.');
    header('Location: ' . APP_URL_BASE . 'seguimiento/index.php');
    exit;
}
$ed = recEdificio($inspeccionId);
$edificioIdActual = (int)($ed['id'] ?? 0);

// Solo edita quien hizo el levantamiento (o un administrador). Los demás
// lo ven en modo consulta: así nadie modifica el trabajo de otro.
$esAutor = $edificioIdActual > 0 ? recPuedeEditarLevantamiento($edificioIdActual) : true;
$soloLectura = !$esAutor;
if ($soloLectura) $puedeEditar = false;

$autor = $edificioIdActual > 0 ? recAutorLevantamiento($edificioIdActual) : [];

$pisos = recPisos((int)$ed['id']);

// Progreso del levantamiento, para la barra de avance. Se calcula aquí
// para que la barra salga llena desde el primer render; luego el
// JavaScript la va refrescando conforme se cargan datos.
$progresoLev = ['porcentaje' => 0, 'faltan' => 0, 'completo' => false, 'grupos' => []];
if ($edificioIdActual > 0) {
    try { $progresoLev = recProgresoLevantamiento($edificioIdActual); } catch (Throwable $e) {}
}

// Locales comerciales del edificio (planta baja). Se levantan igual que
// un apartamento, pero se muestran en su propio panel.
$locales = $edificioIdActual ? recLocalesEdificio($edificioIdActual) : [];
// Plan de tiempo (fase 3): se lee para precargar las fechas. Sin esto,
// los campos salían siempre vacíos aunque ya se hubieran guardado.
$planEd = $edificioIdActual ? recPlan($edificioIdActual) : null;
$tiposElem = recTiposElementoPiso();

// Color/decisión de la edificación para la intro.
$catDecision = catalogoDecisionFinal();
$decisionEd = $insp['decision_final'] ?? '';
$colorEd = $catDecision[$decisionEd]['color'] ?? '#767c94';
$colorCorto = $catDecision[$decisionEd]['corto'] ?? ($decisionEd ?: 'Sin clasificar');

$pageTitle    = 'Levantamiento técnico';
$pageSubtitle = '';
$activeModule = 'seguimiento';
include __DIR__ . '/../includes/header.php';
?>

<style>
    .wz-wrap { max-width:920px; margin:0 auto; }
    .wz-steps { display:flex; gap:8px; margin-bottom:20px; flex-wrap:wrap; }
    .wz-step { flex:1; min-width:120px; padding:10px 14px; border-radius:10px; background:#f2f5fc;
               border:1px solid #e6e9f2; color:#767c94; font-size:13px; cursor:pointer; }
    .wz-step.activo { background:#eaf0ff; border-color:#22366F; color:#22366F; font-weight:600; }
    .wz-step.hecho { background:#e5f7ee; color:#2E7D32; }
    .wz-step .n { display:inline-block; width:22px; height:22px; border-radius:50%; background:#fff;
                  text-align:center; line-height:22px; font-weight:700; margin-right:6px; font-size:12px; }
    .wz-panel { background:#fff; border:1px solid #e6e9f2; border-radius:12px; padding:22px 24px; }
    .wz-panel h3 { margin:0 0 4px; color:#22366F; font-size:16px; }
    .wz-panel .sub { color:#767c94; font-size:13px; margin:0 0 18px; }
    .hidden { display:none; }

    /* ---- Interruptor "No es ingeniero" ---- */
    .sw { position:relative; display:inline-block; width:44px; height:24px; flex-shrink:0; }
    .sw input { position:absolute; opacity:0; width:0; height:0; }
    .sw-pista { position:absolute; inset:0; background:#c8cddb; border-radius:24px;
                transition:background .18s; display:block; }
    .sw-bolita { position:absolute; top:3px; left:3px; width:18px; height:18px;
                 background:#fff; border-radius:50%; transition:transform .18s;
                 box-shadow:0 1px 3px rgba(0,0,0,.28); display:block; }
    .sw input:checked + .sw-pista { background:#22366F; }
    .sw input:checked + .sw-pista .sw-bolita { transform:translateX(20px); }
    .sw input:focus-visible + .sw-pista { outline:2px solid #22366F; outline-offset:2px; }
    .sw input:disabled + .sw-pista { opacity:.5; cursor:not-allowed; }

    .campo-estado { margin:12px 0; }
    .campo-estado .tit { display:block; font-weight:600; font-size:13px; color:#2a3140; margin-bottom:5px; }
    .seg-radio { display:inline-flex; align-items:center; gap:5px; margin-right:14px; font-size:13px; color:#2a3140; cursor:pointer; }
    /* Piso: cada uno es una sección grande y colapsable */
    .piso-card { border:1px solid #d9e0ee; border-radius:8px; margin-bottom:6px; overflow:hidden; }
    .piso-head { padding:13px 16px; background:#22366F; color:#fff; cursor:pointer; font-weight:600;
                 display:flex; align-items:center; justify-content:space-between; }
    .piso-head .estado { font-size:11px; font-weight:500; opacity:.85; }
    .piso-body { padding:16px 18px; }
    .bloque-tit { font-size:13px; font-weight:700; color:#22366F; margin:6px 0 10px; text-transform:uppercase; letter-spacing:.4px; }
    .elem-row { display:flex; align-items:center; gap:10px; flex-wrap:wrap; padding:8px 0; border-bottom:1px solid #f0f2f7; }
    .elem-nom { font-weight:600; color:#2a3140; min-width:130px; }
    .apto-card { border:1px solid #e6e9f2; border-radius:10px; margin:10px 0; overflow:hidden; }
    .apto-head { padding:10px 14px; background:#f2f5fc; cursor:pointer; font-weight:600; color:#22366F; }
    .apto-body { padding:12px 14px; }

    /* Apartamento completo en modo lectura: los campos se ven como
       información fija (no como formulario) hasta tocar "Editar". */
    .apto-body.apto-lectura input,
    .apto-body.apto-lectura select {
        background:#f4f6fb !important; border-color:#e2e6ef !important;
        color:#2a3140 !important; cursor:default; pointer-events:none;
        font-weight:600; -webkit-text-fill-color:#2a3140;
    }
    .apto-body.apto-lectura .btn { display:none !important; }
    .apto-body.apto-lectura .amb-fotos { pointer-events:none; }
    .apto-lectura-aviso {
        display:flex; align-items:center; gap:7px; background:#eef7f0;
        border:1px solid #2E7D3233; border-radius:8px; padding:8px 12px;
        margin-bottom:12px; font-size:12.5px; color:#2E7D32; font-weight:600;
    }
    .subiendo { font-size:12px; color:#767c94; }

    /* --- Ajustes para teléfono: compactar para que no se colapse --- */
    @media (max-width: 620px) {
        .wz-panel { padding:16px 14px; }
        .wz-step { min-width:0; font-size:11px; padding:8px 6px; flex-basis:30%; }
        .wz-step .n { width:18px; height:18px; line-height:18px; margin-right:3px; }
        /* Cada elemento del piso se apila en vertical, ocupando el ancho */
        .elem-row { flex-direction:column; align-items:stretch; gap:6px; padding:12px 0; }
        .elem-nom { min-width:0; font-size:14px; }
        .elem-row .el-estado { width:100% !important; }
        .elem-row .seg-radio { margin-right:0; }
        .elem-row .btn { width:100%; justify-content:center; }
        /* Los campos de m² a reparar, 2 por fila */
        .amb-reparacion [style*="width:110px"], .amb-reparacion [style*="width:120px"] { width:calc(50% - 4px) !important; }
        .apto-body .field { width:calc(50% - 5px) !important; }

        /* --- Paso 1: los tres campos (pisos / aptos / total) uno por fila --- */
        #paso-1 .field { flex:1 1 100% !important; min-width:0 !important; }

        /* --- Selector de piso a ancho completo --- */
        #selector-piso { width:100% !important; }
        #paso-2 .field[style*="max-width"] { max-width:100% !important; }

        /* --- Jefe de familia: un campo por fila (se escribe con el pulgar) --- */
        .jefe-field { width:100% !important; flex:1 1 100% !important; }

        /* --- Áreas comunes: una por fila --- */
        .area-row { flex-direction:column !important; align-items:stretch !important; gap:8px !important; }
        .area-row .form-control, .area-row .btn { width:100% !important; }
        .area-row .area-m2, .area-row .area-trabajo { width:100% !important; }

        /* El grid de áreas pasa a una sola columna: en dos, los
           nombres largos como "Depósito de basura" se parten en
           tres líneas y el texto "Reparar" queda cortado. */
        .areas-grid { grid-template-columns:1fr !important; }

        /* El nombre del área ocupa su línea y "Reparar" va debajo,
           alineado a la izquierda. */
        .area-chk-lbl {
            flex-direction:column !important;
            align-items:flex-start !important;
            gap:6px !important;
        }
        .area-chk-lbl > span:first-child {
            font-weight:600;
            line-height:1.3;
        }
        .area-chk-lbl .seg-radio {
            width:100%;
            padding:5px 0 0;
            border-top:1px solid #eef0f5;
        }

        /* --- Cierre: los radios de estado no se aprietan --- */
        .campo-estado { flex-wrap:wrap !important; }
        .campo-estado .seg-radio { flex:1 1 46%; }

        /* Botonera del wizard */
        .wz-panel > div:last-child .btn { width:100%; justify-content:center; margin-bottom:6px; }
    }

    /* Pantallas muy angostas: los ambientes, 2 por fila */
    @media (max-width: 400px) {
        .apto-body .field { width:calc(50% - 4px) !important; }
        .wz-step { flex-basis:100%; }
    }

    /* --- Ajustes táctiles para trabajo en campo --- */
    @media (max-width: 900px) {
        /* 16px evita que iOS haga zoom automático al tocar un campo */
        .form-control, input[type=text], input[type=number], input[type=tel], input[type=date], select, textarea {
            font-size: 16px !important;
        }
        /* Área de toque cómoda (mínimo recomendado: 44px) */
        .btn, .btn-sm { min-height: 42px; display: inline-flex; align-items: center; justify-content: center; }
        .seg-radio { padding: 6px 0; display: inline-flex; align-items: center; gap: 6px; }
        .seg-radio input[type=checkbox], .seg-radio input[type=radio] { width: 20px; height: 20px; }
        /* Los sliders de avance necesitan más altura para el dedo */
        input[type=range] { height: 34px; }
    }
</style>

<?php if ($soloLectura): ?>
<div style="background:#eef2fb;border:2px solid #22366F33;border-radius:11px;
            padding:14px 18px;margin-bottom:16px;display:flex;gap:13px;
            align-items:center;flex-wrap:wrap;">
    <div style="font-size:26px;color:#22366F;"><i class="bi bi-eye-fill"></i></div>
    <div style="flex:1;min-width:220px;">
        <div style="font-weight:700;color:#22366F;font-size:15px;">Modo consulta</div>
        <div style="font-size:12.5px;color:#5b6478;margin-top:2px;">
            Este levantamiento lo hizo
            <strong><?= e($autor['creado_nombre'] ?? 'otra persona') ?></strong><?php
            if (!empty($autor['creado_en'])): ?>
            el <?= date('d/m/Y', strtotime($autor['creado_en'])) ?><?php endif; ?>.
            Puede verlo completo, pero solo su autor o un administrador pueden modificarlo.
        </div>
    </div>
    <a href="<?= APP_URL_BASE ?>seguimiento/remodelacion.php?inspeccion=<?= $inspeccionId ?>"
       class="btn btn-outline btn-sm">
        <i class="bi bi-arrow-left"></i> Volver a la ficha
    </a>
</div>
<?php endif; ?>

<div class="wz-wrap">

<!-- Indicador de pasos -->
<div class="wz-steps">
    <div class="wz-step <?= $ed['completado'] ? 'hecho' : 'activo' ?>" id="tab-1" onclick="irPaso(1)">
        <span class="n">1</span> Datos del edificio
    </div>
    <div class="wz-step <?= $ed['completado'] ? 'activo' : '' ?>" id="tab-2" onclick="irPaso(2)">
        <span class="n">2</span> Recorrido piso por piso
    </div>
    <div class="wz-step" id="tab-3" onclick="irPaso(3)">
        <span class="n">3</span> Cierre (azotea y resumen)
    </div>
</div>

<!-- Barra de avance del levantamiento -->
<div id="lev-progreso" style="background:#fff;border:1px solid #e6e9f2;border-radius:10px;
     padding:12px 15px;margin-bottom:16px;">
    <div style="display:flex;justify-content:space-between;align-items:center;
                gap:10px;margin-bottom:7px;flex-wrap:wrap;">
        <span style="font-weight:700;color:#22366F;font-size:13.5px;">
            <i class="bi bi-clipboard-check"></i> Avance del levantamiento
        </span>
        <span id="lev-prog-txt" style="font-size:12.5px;color:#5b6478;font-weight:600;">
            <?= (int)$progresoLev['porcentaje'] ?>% ·
            <?php if ($progresoLev['completo']): ?>
                <span style="color:#2E7D32;">Todo completo</span>
            <?php else: ?>
                Faltan <?= (int)$progresoLev['faltan'] ?> dato<?= (int)$progresoLev['faltan'] === 1 ? '' : 's' ?>
            <?php endif; ?>
        </span>
    </div>
    <div style="background:#eef1f7;border-radius:20px;height:11px;overflow:hidden;">
        <div id="lev-prog-barra"
             style="height:100%;border-radius:20px;transition:width .35s ease;
                    width:<?= (int)$progresoLev['porcentaje'] ?>%;
                    background:<?= $progresoLev['completo'] ? '#2E7D32' : '#22366F' ?>;"></div>
    </div>
    <div id="lev-prog-detalle" style="font-size:11px;color:#8a93a8;margin-top:6px;">
        <?php
        $partes = [];
        foreach (($progresoLev['grupos'] ?? []) as $g) {
            if ((int)$g['total'] === 0) continue;
            $partes[] = e($g['nombre']) . ' ' . (int)$g['hechos'] . '/' . (int)$g['total'];
        }
        echo implode(' · ', $partes);
        ?>
    </div>
</div>

<!-- ============ PASO 1: DATOS DEL EDIFICIO ============ -->
<div class="wz-panel<?= $ed['completado'] ? ' hidden' : '' ?>" id="paso-1">

    <?php
    // --- Encabezado con los datos de la inspección (solo lectura) ---
    $cat = catalogoDecisionFinal();
    $dec = $insp['decision_final'] ?? '';
    $colorDec = $cat[$dec]['color'] ?? '#767c94';
    $cortoDec = $cat[$dec]['corto'] ?? ($dec ?: 'Sin clasificar');
    $ubic = array_filter([
        $insp['avenida_calle'] ?? '', $insp['parroquia'] ?? '',
        $insp['municipio'] ?? '', $insp['estado'] ?? ''
    ]);
    ?>
    <div style="border:1px solid #e6e9f2;border-radius:12px;overflow:hidden;margin-bottom:22px;">
        <div style="background:<?= $colorDec ?>;color:#fff;padding:14px 18px;">
            <div style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;opacity:.85;">Edificación a intervenir</div>
            <div style="font-size:19px;font-weight:700;"><?= e($insp['nombre_edificio'] ?: 'Sin nombre') ?></div>
            <div style="font-size:12px;opacity:.9;margin-top:2px;"><i class="bi bi-circle-fill" style="font-size:8px;"></i> <?= e($cortoDec) ?></div>
        </div>
        <div style="padding:14px 18px;display:grid;grid-template-columns:1fr 1fr;gap:10px 20px;">
            <?php
            $datos = [
                ['Código', $insp['codigo'] ?? '—', 'bi-upc-scan'],
                ['Uso', $insp['uso_edificacion'] ?? '—', 'bi-buildings'],
                ['Parroquia', mb_strtoupper($insp['parroquia'] ?? '—', 'UTF-8'), 'bi-geo-alt', true],
                ['Municipio', $insp['municipio'] ?? '—', 'bi-map'],
                ['Familias', $insp['familias'] ?? '—', 'bi-people'],
                ['Personas', $insp['numero_personas'] ?? '—', 'bi-person'],
                ['Pisos (inspección)', $insp['num_pisos'] ?? '—', 'bi-layers'],
                ['Ubicación', implode(', ', $ubic) ?: '—', 'bi-pin-map'],
            ];
            foreach ($datos as $fila):
                [$lbl, $val, $ico] = $fila;
                $destacar = $fila[3] ?? false;
            ?>
            <div style="font-size:13px;">
                <div style="color:#8b91a3;font-size:11px;"><i class="bi <?= $ico ?>"></i> <?= $lbl ?></div>
                <div style="color:#2a3140;font-weight:<?= $destacar ? '700' : '600' ?>;<?= $destacar ? 'font-size:16px;letter-spacing:.3px;' : '' ?>"><?= e((string)$val) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Foto de la etiqueta de la edificación -->
    <div class="bloque-tit"><i class="bi bi-tag"></i> Foto de la etiqueta</div>
    <p class="sub" style="margin-bottom:8px;">Tome la foto de la etiqueta pegada en la fachada de la edificación.</p>

    <div id="bloque-etiqueta">
        <button type="button" class="btn btn-outline" onclick="subirFotoEtiqueta(this)" style="margin-bottom:6px;">
            <i class="bi bi-camera"></i> Foto de la etiqueta
        </button>
        <div id="etiqueta-fotos" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;"></div>
    </div>

    <!-- Ingeniero responsable: se registra antes de empezar -->
    <?php
    recAsegurarIngeniero();
    $ingenieros = recIngenierosActivos();
    $ingActual  = $ed['ingeniero_id'] ?? null;

    // Datos del responsable ya asignado (puede no ser ingeniero).
    $respActual = null;
    try { $respActual = recIngenieroDe((int)$ed['id']); } catch (Throwable $e) {}

    // Profesiones para el desplegable: las fijas del sistema mas las que
    // se hayan ido agregando en el catalogo. Se usa la misma lista que
    // admin/ingenieros.php para que no haya dos catalogos distintos.
    $profesionesFijas = ['Ingeniero', 'Arquitecto', 'Bombero', 'Protección Civil',
                         'Psicólogo', 'Psiquiatra', 'Antropólogo', 'Politólogo'];
    $profesionesCat = [];
    if (function_exists('catalogoProfesiones')) {
        try { $profesionesCat = catalogoProfesiones(); } catch (Throwable $e) {}
    }
    $profesiones = $profesionesFijas;
    foreach ($profesionesCat as $pc) {
        $pc = trim((string)$pc);
        if ($pc !== '' && !in_array($pc, $profesiones, true)) $profesiones[] = $pc;
    }
    sort($profesiones, SORT_NATURAL | SORT_FLAG_CASE);

    // El interruptor arranca activado si el responsable guardado tiene una
    // profesion distinta de "Ingeniero": significa que se registro por aqui.
    $profResp = trim((string)($respActual['profesion'] ?? ''));
    $esNoIngeniero = ($respActual !== null && $profResp !== ''
                      && mb_strtolower($profResp, 'UTF-8') !== 'ingeniero');
    ?>
    <div style="background:#f7f9fd;border:1px solid #22366F22;border-radius:9px;
                padding:12px 14px;margin-bottom:14px;">
        <label class="text-sm" style="font-weight:700;color:#22366F;display:block;
               margin-bottom:6px;">
            <i class="bi bi-person-vcard"></i> Ingeniero responsable
            <span style="color:#A61C1C;">*</span>
        </label>

        <!-- Interruptor: el responsable no es ingeniero -->
        <label class="sw-wrap" style="display:flex;align-items:center;gap:9px;
               cursor:pointer;margin-bottom:10px;user-select:none;">
            <span class="sw">
                <input type="checkbox" id="no-es-ingeniero"
                       <?= $esNoIngeniero ? 'checked' : '' ?>
                       onchange="toggleNoIngeniero(this)">
                <span class="sw-pista"><span class="sw-bolita"></span></span>
            </span>
            <span style="font-size:12.5px;font-weight:600;color:#22366F;">
                No es ingeniero
            </span>
        </label>

        <!-- ========== A) Selector normal de ingeniero ========== -->
        <div id="bloque-ingeniero" style="<?= $esNoIngeniero ? 'display:none;' : '' ?>">
            <?php if ($ingenieros): ?>
            <select id="ingeniero-id" class="form-control" style="width:100%;max-width:420px;"
                    onchange="guardarIngeniero(this)">
                <option value="">— Seleccione el ingeniero a cargo —</option>
                <?php foreach ($ingenieros as $ing): ?>
                <option value="<?= (int)$ing['id'] ?>"
                        <?= ((int)$ingActual === (int)$ing['id']) ? 'selected' : '' ?>>
                    <?= e($ing['nombre']) ?><?= !empty($ing['cedula']) ? ' · ' . e($ing['cedula']) : '' ?><?php
                        $pIng = trim((string)($ing['profesion'] ?? ''));
                        if ($pIng !== '' && mb_strtolower($pIng, 'UTF-8') !== 'ingeniero') {
                            echo ' (' . e($pIng) . ')';
                        }
                    ?>
                </option>
                <?php endforeach; ?>
            </select>
            <div class="text-sm" style="color:#5b6478;margin-top:5px;font-size:11.5px;">
                Queda registrado en el informe de la edificación.
            </div>
            <?php else: ?>
            <div style="font-size:12.5px;color:#8a6d1a;">
                No hay ingenieros registrados.
                <?php if (usuarioEsMaster() || puede('configuracion','ver')): ?>
                <a href="<?= APP_URL_BASE ?>admin/ingenieros.php" target="_blank"
                   style="color:#22366F;font-weight:600;">Agréguelos aquí</a>.
                <?php endif; ?>
                <br>Si el responsable no es ingeniero, active el interruptor de arriba.
            </div>
            <?php endif; ?>
        </div>

        <!-- ========== B) Datos del profesional que no es ingeniero ========== -->
        <div id="bloque-profesional" style="<?= $esNoIngeniero ? '' : 'display:none;' ?>">
            <div style="font-size:11.5px;color:#5b6478;margin-bottom:9px;">
                Registre los datos de la persona responsable.
                Los campos con <span style="color:#A61C1C;">*</span> son obligatorios.
            </div>

            <input type="hidden" id="prof-id"
                   value="<?= $esNoIngeniero ? (int)($respActual['id'] ?? 0) : '' ?>">

            <!-- Foto (opcional) -->
            <div style="margin-bottom:11px;">
                <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">
                    Foto <span style="color:#5b6478;font-weight:400;">(opcional)</span>
                </label>
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <div id="prof-foto-previa"
                         style="width:64px;height:64px;border-radius:9px;border:1px solid #d8dce6;
                                background:#fff center/cover no-repeat;display:flex;
                                align-items:center;justify-content:center;color:#aab;font-size:22px;
                                <?php if ($esNoIngeniero && !empty($respActual['foto'])): ?>
                                background-image:url('<?= APP_URL_BASE . e(ltrim($respActual['foto'], '/')) ?>');
                                <?php endif; ?>">
                        <?php if (!($esNoIngeniero && !empty($respActual['foto']))): ?>
                        <i class="bi bi-person"></i>
                        <?php endif; ?>
                    </div>
                    <input type="file" id="prof-foto" accept="image/*"
                           onchange="previsualizarFotoProf(this)"
                           style="font-size:12px;max-width:230px;">
                </div>
            </div>

            <!-- Nombre -->
            <div style="margin-bottom:9px;">
                <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">
                    Nombre completo <span style="color:#A61C1C;">*</span>
                </label>
                <input type="text" id="prof-nombre" class="form-control" maxlength="150"
                       style="max-width:420px;" placeholder="Nombre y apellido"
                       value="<?= $esNoIngeniero ? e((string)($respActual['nombre'] ?? '')) : '' ?>">
            </div>

            <!-- Cedula -->
            <div style="margin-bottom:9px;">
                <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">
                    Cédula <span style="color:#A61C1C;">*</span>
                </label>
                <input type="text" id="prof-cedula" class="form-control" maxlength="30"
                       style="max-width:260px;" placeholder="V-12345678"
                       value="<?= $esNoIngeniero ? e((string)($respActual['cedula'] ?? '')) : '' ?>">
            </div>

            <!-- Telefono -->
            <div style="margin-bottom:9px;">
                <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">
                    Número de teléfono <span style="color:#A61C1C;">*</span>
                </label>
                <input type="tel" id="prof-telefono" class="form-control" maxlength="40"
                       style="max-width:260px;" placeholder="0412-1234567"
                       value="<?= $esNoIngeniero ? e((string)($respActual['telefono'] ?? '')) : '' ?>">
            </div>

            <!-- Profesion: desplegable con opcion de agregar una nueva -->
            <div style="margin-bottom:11px;">
                <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">
                    Profesión <span style="color:#A61C1C;">*</span>
                </label>
                <?php
                // Si la profesion guardada no esta en la lista, se muestra
                // como "Otra" con el texto ya escrito.
                $profEsOtra = ($esNoIngeniero && $profResp !== ''
                               && !in_array($profResp, $profesiones, true));
                ?>
                <select id="prof-profesion" class="form-control" style="max-width:420px;"
                        onchange="cambiarProfesion(this)">
                    <option value="">— Seleccione la profesión —</option>
                    <?php foreach ($profesiones as $pf): ?>
                    <option value="<?= e($pf) ?>"
                            <?= ($esNoIngeniero && $profResp === $pf) ? 'selected' : '' ?>>
                        <?= e($pf) ?>
                    </option>
                    <?php endforeach; ?>
                    <option value="__otra__" <?= $profEsOtra ? 'selected' : '' ?>>
                        + Agregar otra profesión…
                    </option>
                </select>
                <input type="text" id="prof-profesion-nueva" class="form-control" maxlength="100"
                       placeholder="Escriba la nueva profesión"
                       style="margin-top:7px;max-width:420px;<?= $profEsOtra ? '' : 'display:none;' ?>"
                       value="<?= $profEsOtra ? e($profResp) : '' ?>">
            </div>

            <button type="button" class="btn btn-primary btn-sm" id="btn-guardar-prof"
                    onclick="guardarProfesional(this)">
                <i class="bi bi-check2-circle"></i> Guardar responsable
            </button>
            <div id="prof-aviso" style="margin-top:7px;font-size:12px;"></div>
        </div>
    </div>

    <!-- Algunas edificaciones no tienen etiqueta: hay que poder dejarlo asentado -->
    <label class="check-row" style="display:flex;align-items:flex-start;gap:9px;
           background:#f7f9fd;border-radius:9px;padding:11px 13px;margin-bottom:8px;cursor:pointer;">
        <input type="checkbox" id="sin-etiqueta" style="margin-top:2px;"
               onchange="onSinEtiqueta(this)"
               <?= !empty($ed['sin_etiqueta']) ? 'checked' : '' ?>>
        <span>
            <span style="font-weight:600;color:#2a3140;font-size:14px;">
                Esta edificación no tiene etiqueta
            </span>
            <span style="display:block;font-size:12.5px;color:#5b6478;margin-top:2px;">
                Marque esta casilla si no encontró la etiqueta en la fachada.
                Queda registrado y puede continuar.
            </span>
        </span>
    </label>

    <div id="motivo-sin-etiqueta" style="display:<?= !empty($ed['sin_etiqueta']) ? 'block' : 'none' ?>;margin-bottom:20px;">
        <label class="text-sm" style="font-weight:600;">¿Por qué? <span class="text-muted">(opcional)</span></label>
        <select id="etiqueta-motivo" class="form-control" onchange="guardarSinEtiqueta()">
            <option value="">— Indique el motivo —</option>
            <?php
            $motivoAct = $ed['etiqueta_motivo'] ?? '';
            $motivos = [
                'No fue colocada'        => 'Nunca fue colocada',
                'Se desprendió'          => 'Se desprendió o se perdió',
                'Ilegible'               => 'Está pero ilegible o borrada',
                'Fachada inaccesible'    => 'No se pudo acceder a la fachada',
                'Edificación derrumbada' => 'La edificación está derrumbada',
                'Otro'                   => 'Otro motivo',
            ];
            foreach ($motivos as $val => $txt): ?>
            <option value="<?= e($val) ?>" <?= $motivoAct === $val ? 'selected' : '' ?>><?= e($txt) ?></option>
            <?php endforeach; ?>
        </select>
        <input type="text" id="etiqueta-obs" class="form-control" style="margin-top:6px;"
               placeholder="Observación (opcional)" onblur="guardarSinEtiqueta()"
               value="<?= e($ed['etiqueta_obs'] ?? '') ?>">
    </div>

    <h3>Datos del edificio</h3>
    <p class="sub">Corrobore la información básica. Esto genera los pisos que va a recorrer.</p>
    <form id="form-edificio" onsubmit="return guardarEdificio(event)">
        <?php
        // Una casa no se divide en apartamentos: sus ambientes cuelgan
        // directo del piso. Se detecta por el uso de la edificación.
        $usoEd = mb_strtolower(trim($insp['uso_edificacion'] ?? ''), 'UTF-8');
        $esCasa = (strpos($usoEd, 'casa') !== false)
               || (strpos($usoEd, 'unifamiliar') !== false);
        ?>

        <div class="flex gap-8" style="flex-wrap:wrap;">
            <div class="field" style="flex:1;min-width:160px;">
                <label class="text-sm">
                    <?= $esCasa ? 'Cantidad de niveles *' : 'Cantidad de pisos *' ?>
                </label>
                <input type="number" id="num_pisos" class="form-control" min="1" max="200"
                       value="<?= $ed['num_pisos'] !== null ? (int)$ed['num_pisos'] : '' ?>" required
                       oninput="calcularTotalAptos()">
                <?php if ($esCasa): ?>
                <div class="text-sm" style="color:#5b6478;font-size:11.5px;margin-top:3px;">
                    Planta baja incluida. Si es de un solo nivel, escriba 1.
                </div>
                <?php endif; ?>
            </div>

            <?php if (!$esCasa): ?>
            <div class="field" style="flex:1;min-width:160px;">
                <label class="text-sm">Apartamentos por piso</label>
                <input type="number" id="aptos_por_piso" class="form-control" min="0" max="100"
                       value="<?= $ed['aptos_por_piso'] !== null ? (int)$ed['aptos_por_piso'] : '' ?>"
                       oninput="calcularTotalAptos()">
            </div>
            <div class="field" style="flex:1;min-width:160px;">
                <label class="text-sm">Total de apartamentos</label>
                <input type="number" id="total_apartamentos" class="form-control" readonly
                       style="background:#f2f5fc;font-weight:700;color:#22366F;"
                       value="<?= (int)($ed['num_pisos'] ?? 0) * (int)($ed['aptos_por_piso'] ?? 0) ?>">
            </div>
            <?php else: ?>
            <?php // En casas hay un solo "espacio" por nivel: la vivienda misma. ?>
            <input type="hidden" id="aptos_por_piso" value="1">
            <input type="hidden" id="total_apartamentos" value="<?= (int)($ed['num_pisos'] ?? 1) ?>">
            <div class="field" style="flex:2;min-width:220px;">
                <div style="background:#eef2fb;border-radius:9px;padding:11px 13px;
                            font-size:12.5px;color:#22366F;">
                    <i class="bi bi-house-door-fill"></i>
                    <strong>Es una casa.</strong> No se piden apartamentos:
                    en cada nivel registrará directamente sus ambientes
                    —habitaciones, baños, cocina— en el paso siguiente.
                </div>
            </div>
            <?php endif; ?>
        </div>

        <?php if (!$esCasa): ?>
        <!-- Locales comerciales (normalmente en planta baja) -->
        <?php
            $tieneLoc = !empty($ed['tiene_locales']);
            $numLoc   = (int)($ed['num_locales'] ?? 0);
        ?>
        <div style="margin-top:12px;padding:12px 14px;background:#f7f9fd;border-radius:10px;">
            <label class="seg-radio" style="font-weight:600;color:#22366F;">
                <input type="checkbox" id="tiene-locales" <?= $tieneLoc ? 'checked' : '' ?>
                       onchange="toggleLocales(this)">
                <i class="bi bi-shop"></i> El edificio tiene locales comerciales
            </label>
            <div id="locales-detalle" style="margin-top:10px;display:<?= $tieneLoc ? 'block' : 'none' ?>;">
                <div class="flex gap-8" style="flex-wrap:wrap;align-items:flex-end;">
                    <div class="field" style="flex:1;min-width:180px;">
                        <label class="text-sm">¿Cuántos locales? (planta baja)</label>
                        <input type="number" id="num_locales" class="form-control" min="0" max="60"
                               value="<?= $numLoc ?: '' ?>" placeholder="Ej: 4">
                    </div>
                    <div class="field" style="flex:2;min-width:200px;">
                        <div style="font-size:12px;color:#5b6478;">
                            Cada local se levanta aparte en el paso 2, con sus
                            propios ambientes (área de venta, depósito, baño) y
                            sus reparaciones, igual que un apartamento.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div style="margin-top:8px;">
            <label class="text-sm" style="font-weight:600;display:block;margin-bottom:8px;"><i class="bi bi-columns-gap"></i> Áreas comunes del edificio</label>
            <p class="sub" style="margin:0 0 10px;">Marque "Reparar" en las áreas que necesitan intervención. Se le pedirá una foto y qué trabajo requiere.</p>
            <?php
            $areasCat = recAreasComunesTipicas();
            $areasGuardadas = recAreasComunes((int)$ed['id']);

            // Los metros y el tipo de trabajo REALES viven en rec_reparacion,
            // no en rec_area_comun (ahi solo queda un resumen). Si no se leen
            // aqui, el formulario se dibuja vacio y al guardar de nuevo
            // sobreescribe con vacio lo que ya estaba bien guardado.
            $repAreas = [];   // [tipo_area] => ['principal'=>..., 'extras'=>[...]]
            foreach ($areasGuardadas as $akTmp => $acTmp) {
                $filas = [];
                try { $filas = recReparaciones('area_comun', (int)$acTmp['id']); }
                catch (Throwable $e) { $filas = []; }
                if (!$filas) continue;

                // partida 1 = trabajo principal; el resto son trabajos extra.
                $princ = ['trabajo' => '', 'sup' => []];
                $extras = [];
                foreach ($filas as $f) {
                    $part = (int)($f['partida'] ?? 1);
                    $sup  = $f['tipo_superficie'] ?? '';
                    $m2f  = (float)($f['metros_cuadrados'] ?? 0);
                    $ttf  = $f['tipo_trabajo'] ?? '';
                    if ($m2f <= 0 || $sup === '') continue;

                    // Todo lo que comparta el trabajo principal se agrupa ahi.
                    if ($princ['trabajo'] === '' || $ttf === $princ['trabajo']) {
                        $princ['trabajo'] = $princ['trabajo'] ?: $ttf;
                        $princ['sup'][$sup] = ($princ['sup'][$sup] ?? 0) + $m2f;
                    } else {
                        if (!isset($extras[$ttf])) $extras[$ttf] = [];
                        $extras[$ttf][$sup] = ($extras[$ttf][$sup] ?? 0) + $m2f;
                    }
                }
                $repAreas[$akTmp] = ['principal' => $princ, 'extras' => $extras];
            }

            // Áreas que el técnico agregó con nombre libre ("Otros").
            recAsegurarAreasPartidas();
            $areasPropias = [];
            try {
                $stAP = db()->prepare("SELECT * FROM rec_area_comun
                                        WHERE edificio_id = :e
                                          AND nombre_libre IS NOT NULL AND nombre_libre <> ''
                                        ORDER BY id");
                $stAP->execute(['e' => (int)$ed['id']]);
                foreach ($stAP->fetchAll() as $ap) {
                    $areasPropias[$ap['tipo']] = $ap;
                    $areasCat[$ap['tipo']] = $ap['nombre_libre'];
                    $areasGuardadas[$ap['tipo']] = $ap;
                }
            } catch (Throwable $e) {}
            // Las áreas comunes usan el MISMO catálogo que los ambientes:
            // antes tenían tres opciones inventadas que no existían en
            // rec_tipo_trabajo, así que su material nunca se calculaba.
            $tiposTrabajo = [];
            foreach (recTiposTrabajo() as $tt) {
                $tiposTrabajo[$tt['clave']] = $tt['nombre'];
            }
            ?>
            <div class="areas-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
                <?php foreach ($areasCat as $ak => $albl):
                    $ac = $areasGuardadas[$ak] ?? null;
                    $reparar = $ac && $ac['necesita_reparacion'];

                    // Datos reales guardados en rec_reparacion para esta area.
                    $rp        = $repAreas[$ak] ?? null;
                    $supGuard  = $rp['principal']['sup'] ?? [];
                    $extrasG   = $rp['extras'] ?? [];
                    // El trabajo mostrado sale de rec_reparacion; si por alguna
                    // razon no hay, se cae al resumen de rec_area_comun.
                    $trabajoAct = $rp['principal']['trabajo'] ?? '';
                    if ($trabajoAct === '') $trabajoAct = (string)($ac['tipo_trabajo'] ?? '');
                    // Si hay metros guardados, el area esta a reparar aunque el
                    // resumen se haya quedado desactualizado.
                    if (!$reparar && ($supGuard || $extrasG)) $reparar = true;
                ?>
                <div class="area-row" data-area="<?= $ak ?>" style="border:1px solid #eef0f5;border-radius:8px;overflow:hidden;">
                    <label class="area-chk-lbl" style="display:flex;align-items:center;justify-content:space-between;gap:7px;padding:9px 11px;cursor:pointer;font-size:13px;<?= $reparar ? 'background:#fdf3e7;font-weight:600;color:#A66A00;' : '' ?>">
                        <span><?= e($albl) ?></span>
                        <span class="seg-radio" style="font-size:12px;white-space:nowrap;">
                            <input type="checkbox" class="area-reparar" <?= $reparar ? 'checked' : '' ?>> <i class="bi bi-tools"></i> Reparar
                        </span>
                    </label>
                    <!-- Detalle de reparación: foto + tipo de trabajo + m². Solo si "Reparar". -->
                    <div class="area-detalle" style="padding:10px 11px;background:#f9fafd;display:<?= $reparar ? 'block' : 'none' ?>;">
                        <button type="button" class="btn btn-outline btn-sm" onclick="subirFotoArea('<?= $ak ?>', this)" style="margin-bottom:8px;">
                            <i class="bi bi-camera"></i> Foto del área a reparar
                        </button>
                        <div class="area-fotos" style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;"></div>
                        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">¿Qué trabajo necesita?</label>
                        <select class="form-control area-trabajo" style="width:100%;padding:6px 8px;font-size:12.5px;margin-bottom:8px;"
                                onchange="calcularMatArea(this)">
                            <option value="">Seleccione…</option>
                            <?php foreach ($tiposTrabajo as $tk => $tl): ?>
                            <option value="<?= $tk ?>" <?= ($trabajoAct === (string)$tk) ? 'selected' : '' ?>><?= $tl ?></option>
                            <?php endforeach; ?>
                        </select>
                        <label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">
                            Metros cuadrados a reparar
                        </label>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">
                            <?php foreach (['pared','techo','piso'] as $sup):
                                // rec_area_comun NO tiene columna tipo_superficie:
                                // el desglose real esta en rec_reparacion.
                                // Se muestra con coma, como se escribe en Venezuela
                                // (igual que los ambientes).
                                $valSup = isset($supGuard[$sup]) && $supGuard[$sup] > 0
                                        ? str_replace('.', ',',
                                            rtrim(rtrim(number_format((float)$supGuard[$sup], 2, '.', ''), '0'), '.'))
                                        : ''; ?>
                            <div style="width:104px;">
                                <label class="text-sm" style="text-transform:capitalize;
                                       font-size:11px;"><?= $sup ?></label>
                                <div style="display:flex;align-items:center;gap:4px;">
                                    <input type="text" inputmode="decimal"
                                           class="form-control area-sup"
                                           data-sup="<?= $sup ?>"
                                           value="<?= e((string)$valSup) ?>"
                                           style="flex:1;min-width:0;padding:6px 8px;font-size:12.5px;"
                                           oninput="normalizarDecimal(this); calcularMatArea(this);">
                                    <span style="font-size:11px;color:#8a6d1a;font-weight:600;">m²</span>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Campo oculto: conserva el total para el guardado -->
                        <?php $totalAreaG = $supGuard ? array_sum($supGuard) : (float)($ac['metros_cuadrados'] ?? 0); ?>
                        <input type="hidden" class="area-m2"
                               value="<?= $totalAreaG > 0 ? e(str_replace('.', ',', rtrim(rtrim(number_format($totalAreaG, 2, '.', ''), '0'), '.'))) : '' ?>">

                        <button type="button" class="btn btn-outline btn-sm"
                                style="margin-bottom:8px;border-color:#2d448855;color:#2d4488;
                                       font-size:11.5px;"
                                onclick="agregarPartidaArea(this, '<?= $ak ?>')">
                            <i class="bi bi-plus-circle"></i> Agregar otro trabajo aquí
                        </button>
                        <div class="area-partidas"></div>
                        <div class="area-materiales" style="font-size:12px;color:#22366F;background:#eef2fb;border-radius:6px;padding:8px 10px;display:none;"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Agregar un área que no está en la lista -->
            <?php if ($puedeEditar): ?>
            <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;
                        background:#f7f9fd;border-radius:9px;padding:11px 13px;">
                <span class="text-sm" style="color:#5b6478;font-weight:600;">
                    <i class="bi bi-plus-circle"></i> ¿Falta un área?
                </span>
                <input type="text" id="area-otra-nombre" class="form-control"
                       style="flex:1;min-width:190px;font-size:12.5px;"
                       placeholder="Escriba el nombre. Ej: Cuarto de medidores"
                       maxlength="120"
                       onkeydown="if(event.key==='Enter'){event.preventDefault();agregarAreaOtra();}">
                <button type="button" class="btn btn-outline btn-sm" onclick="agregarAreaOtra()">
                    <i class="bi bi-plus-lg"></i> Agregar
                </button>
            </div>
            <?php endif; ?>
        </div>

        <?php if ($puedeEditar): ?>
        <div style="margin-top:16px;">
            <button type="submit" class="btn btn-primary"><i class="bi bi-arrow-right"></i> Guardar y empezar el recorrido</button>
        </div>
        <?php endif; ?>
    </form>
</div>

<!-- ============ PASO 2: RECORRIDO PISO POR PISO ============ -->
<div class="wz-panel<?= $ed['completado'] ? '' : ' hidden' ?>" id="paso-2">
    <h3>Recorrido piso por piso</h3>
    <p class="sub">Seleccione un piso del listado. En cada uno registre lo común (ascensor, escaleras…) y luego entre a sus apartamentos.</p>

    <?php if (!$pisos): ?>
        <p class="text-muted">Primero complete los datos del edificio (Paso 1) para generar los pisos.</p>
    <?php else: ?>
        <!-- Selector de piso (dropdown) -->
        <div class="field" style="max-width:320px;margin-bottom:16px;">
            <label class="text-sm" style="font-weight:600;"><i class="bi bi-list-ol"></i> Seleccione el piso</label>
            <select id="selector-piso" class="form-control" onchange="mostrarPisoSeleccionado()">
                <option value="">— Elija un piso —</option>
                <?php foreach ($pisos as $piso): ?>
                <option value="<?= (int)$piso['id'] ?>">
                    <?= (int)$piso['numero_piso'] === 0 ? 'Planta Baja (PB)' : 'Piso ' . (int)$piso['numero_piso'] ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <?php if (!empty($ed['tiene_locales']) && $locales): ?>
        <!-- Panel de locales comerciales -->
        <div class="piso-card" style="margin-bottom:16px;border:1px solid #C9A22755;">
            <div class="piso-head" style="cursor:default;background:#fbf8ef;">
                <span style="font-weight:700;color:#8a6d1a;">
                    <i class="bi bi-shop"></i> Locales comerciales (<?= count($locales) ?>)
                </span>
            </div>
            <div style="padding:12px 14px;">
                <p class="sub" style="margin:0 0 10px;">
                    Cada local se levanta como un espacio aparte: indique sus
                    ambientes (área de venta, depósito, baño) y sus reparaciones.
                </p>
                <div class="apto-lista" id="locales-lista" data-locales="1"></div>
            </div>
        </div>
        <?php endif; ?>

        <?php foreach ($pisos as $piso):
            $elems = recElementosPiso((int)$piso['id']);
        ?>
        <div class="piso-card piso-panel hidden" data-piso="<?= (int)$piso['id'] ?>" data-numero-piso="<?= (int)$piso['numero_piso'] ?>" id="piso-panel-<?= (int)$piso['id'] ?>">
            <div class="piso-head" style="cursor:default;">
                <span><i class="bi bi-building"></i> <?= (int)$piso['numero_piso'] === 0 ? 'Planta Baja (PB)' : 'Piso ' . (int)$piso['numero_piso'] ?></span>
            </div>
            <div class="piso-body">

                <!-- Áreas comunes del piso -->
                <div class="bloque-tit"><i class="bi bi-diagram-3"></i> Áreas comunes del piso</div>
                <label class="seg-radio"><input type="checkbox" class="piso-areas" onchange="guardarPisoReactivo(<?= (int)$piso['id'] ?>)" <?= $piso['tiene_areas_comunes'] ? 'checked' : '' ?>> Este piso tiene áreas comunes</label>
                <input type="text" class="form-control piso-areas-desc" placeholder="¿Cuáles?" value="<?= e($piso['areas_comunes_desc'] ?? '') ?>" style="margin-top:6px;" onblur="guardarPisoReactivo(<?= (int)$piso['id'] ?>)">

                <!-- Elementos comunes del piso -->
                <div class="bloque-tit" style="margin-top:16px;"><i class="bi bi-gear"></i> Elementos del piso</div>
                <?php foreach ($tiposElem as $tk => $tlbl):
                    $el = $elems[$tk] ?? null;
                    $estadoActual = $el['estado'] ?? '';
                    // El estado se considera "válido para foto" si tiene algún valor.
                    $estadoValido = $estadoActual !== '';
                ?>
                <div class="elem-row" data-tipo="<?= $tk ?>" <?= ($el && $el['id']) ? 'data-elem-id="'.(int)$el['id'].'"' : '' ?>>
                    <span class="elem-nom"><?= e($tlbl) ?></span>
                    <select class="form-control el-estado" style="width:auto;" onchange="onEstadoElemento(this, <?= (int)$piso['id'] ?>)">
                        <option value="">Estado del elemento…</option>
                        <?php foreach (['Bueno','Regular','Requiere reparación','No funciona'] as $es): ?>
                        <option value="<?= $es ?>" <?= ($el && $el['estado'] === $es) ? 'selected' : '' ?>><?= $es ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label class="seg-radio"><input type="checkbox" class="el-reparar" <?= ($el && $el['necesita_reparacion']) ? 'checked' : '' ?> onchange="guardarPisoReactivo(<?= (int)$piso['id'] ?>)"> Reparación</label>
                    <button type="button" class="btn btn-outline btn-sm btn-foto-elem" onclick="subirFotoElemento(this, <?= (int)$piso['id'] ?>, '<?= $tk ?>')" <?= $estadoValido ? '' : 'disabled' ?>>
                        <i class="bi bi-camera"></i> Foto
                    </button>
                    <!-- Tipo de trabajo y metros del elemento -->
                    <div class="el-trabajo-caja" style="width:100%;display:<?= ($el && $el['necesita_reparacion']) ? 'flex' : 'none' ?>;
                                gap:8px;flex-wrap:wrap;margin-top:8px;background:#fbf8ef;
                                border-radius:8px;padding:9px 11px;">
                        <select class="form-control el-trabajo" style="flex:2;min-width:170px;"
                                onchange="guardarPisoReactivo(<?= (int)$piso['id'] ?>)">
                            <option value="">— ¿Qué trabajo? —</option>
                        </select>
                        <input type="text" inputmode="decimal" class="form-control el-m2"
                               style="width:110px;" placeholder="m²"
                               value="<?= str_replace('.', ',', (string)($el['metros_cuadrados'] ?? '')) ?>"
                               oninput="normalizarDecimal(this)"
                               onchange="guardarPisoReactivo(<?= (int)$piso['id'] ?>)">
                    </div>
                    <div class="elem-fotos" style="display:flex;gap:6px;flex-wrap:wrap;width:100%;"></div>
                </div>
                <?php endforeach; ?>

                <!-- Apartamentos de este piso -->
                <div class="bloque-tit" style="margin-top:20px;"><i class="bi bi-door-open"></i> Apartamentos de este piso</div>
                <p class="sub" style="margin:0 0 10px;">Los apartamentos se generan solos con nomenclatura <b>Piso-Letra</b> (ej: <?= (int)$piso['numero_piso'] ?>-A, <?= (int)$piso['numero_piso'] ?>-B…).</p>

                <?php if ($puedeEditar): ?>
                <!-- Ajustar la cantidad: no todos los pisos tienen los mismos apartamentos -->
                <div class="apto-generador" style="margin-bottom:12px;padding:11px 13px;background:#f7f9fd;border-radius:9px;">
                    <label class="text-sm" style="display:block;margin-bottom:6px;">
                        Este piso tiene <b class="apto-actual"><?= (int)($ed['aptos_por_piso'] ?: 1) ?></b> apartamento(s).
                        Si es diferente, ajuste la cantidad y regenere:
                    </label>
                    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                        <input type="number" class="form-control apto-cantidad" min="1" max="100"
                               value="<?= (int)($ed['aptos_por_piso'] ?: 1) ?>"
                               data-num="<?= (int)$piso['numero_piso'] ?>" style="width:100px;">
                        <button type="button" class="btn btn-outline btn-sm"
                                onclick="regenerarAptos(this, <?= (int)$piso['id'] ?>, <?= (int)$piso['numero_piso'] ?>)">
                            <i class="bi bi-arrow-repeat"></i> Regenerar apartamentos
                        </button>
                        <span class="apto-msg text-sm" style="margin-left:4px;"></span>
                    </div>
                    <div class="text-sm" style="color:#8a6d1a;margin-top:6px;font-size:12px;">
                        <i class="bi bi-info-circle"></i>
                        Si reduce la cantidad, se eliminan los apartamentos sobrantes con sus datos.
                    </div>
                </div>
                <?php endif; ?>

                <div class="apto-lista"></div>

            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <div style="margin-top:16px;">
        <button type="button" class="btn btn-outline" onclick="irPaso(1)"><i class="bi bi-arrow-left"></i> Datos del edificio</button>
        <button type="button" class="btn btn-primary" onclick="irPaso(3)">Ir al cierre <i class="bi bi-arrow-right"></i></button>
    </div>
</div>

<!-- ============ PASO 3: CIERRE (AZOTEA + RESUMEN) ============ -->
<div class="wz-panel hidden" id="paso-3">
    <h3>Cierre del levantamiento</h3>
    <p class="sub">Lo último del recorrido: al llegar a la azotea, registre su situación y la de los tanques de agua.</p>

    <form id="form-cierre" onsubmit="return guardarCierre(event)">
        <?php
        $globales = ['azotea' => 'Azotea', 'tanques' => 'Tanques de agua'];
        $opciones = ['Buena','Regular','Requiere reparación','No aplica'];
        foreach ($globales as $key => $lbl):
            $valActual = $ed[$key . '_estado'] ?? '';
        ?>
        <div class="campo-estado" data-cierre="<?= $key ?>">
            <label class="tit"><?= $lbl ?></label>
            <?php foreach ($opciones as $op): ?>
            <label class="seg-radio">
                <input type="radio" name="<?= $key ?>_estado" value="<?= $op ?>" <?= $valActual === $op ? 'checked' : '' ?>
                       onchange="onEstadoCierre('<?= $key ?>')">
                <?= $op ?>
            </label>
            <?php endforeach; ?>
        </div>
        <input type="text" class="form-control" name="<?= $key ?>_obs" placeholder="Observación (opcional)"
               value="<?= e($ed[$key . '_obs'] ?? '') ?>" style="margin-bottom:8px;">
        <!-- Foto condicional: solo si el estado es "Requiere reparación" -->
        <div class="cierre-foto" id="cierre-foto-<?= $key ?>" style="display:<?= $valActual === 'Requiere reparación' ? 'block' : 'none' ?>;margin-bottom:12px;">
            <button type="button" class="btn btn-outline btn-sm" onclick="subirFotoCierre('<?= $key ?>', this)">
                <i class="bi bi-camera"></i> Foto del área que requiere reparación
            </button>
            <div class="cierre-fotos" style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;"></div>
        </div>

        <?php // La impermeabilización es una condición de la azotea: se
              // pregunta como un sí/no. Marcado = requiere; sin marcar = no.
              // Es opcional (no bloquea el cierre).
              if ($key === 'azotea'):
                  $reqImper = trim((string)($ed['impermeabilizacion_estado'] ?? '')) !== '';
        ?>
        <label class="check-row" style="display:flex;align-items:flex-start;gap:9px;
               background:#f7f9fd;border-radius:9px;padding:11px 13px;margin-bottom:12px;cursor:pointer;">
            <input type="checkbox" id="req-impermeabilizacion" style="margin-top:2px;"
                   <?= $reqImper ? 'checked' : '' ?>>
            <span>
                <span style="font-weight:600;color:#2a3140;font-size:14px;">
                    La azotea requiere impermeabilización
                </span>
                <span style="display:block;font-size:12.5px;color:#5b6478;margin-top:2px;">
                    Marque esta casilla si la azotea necesita impermeabilizarse.
                </span>
            </span>
        </label>
        <?php endif; ?>
        <?php endforeach; ?>

        <hr style="margin:18px 0;border:0;border-top:1px solid #eef0f5;">
        <div class="bloque-tit"><i class="bi bi-calendar-range"></i> Tiempo estimado de la reconstrucción</div>
        <div class="flex gap-8" style="flex-wrap:wrap;">
            <div class="field" style="flex:1;min-width:160px;">
                <label class="text-sm">Fecha de inicio estimada</label>
                <input type="date" name="fecha_inicio_estimada" class="form-control"
                       value="<?= e($planEd['fecha_inicio_estimada'] ?? '') ?>">
            </div>
            <div class="field" style="flex:1;min-width:160px;">
                <label class="text-sm">Fecha de fin estimada</label>
                <input type="date" name="fecha_fin_estimada" class="form-control"
                       value="<?= e($planEd['fecha_fin_estimada'] ?? '') ?>">
            </div>
        </div>

        <?php if ($puedeEditar): ?>
        <div style="margin-top:16px;">
            <button type="submit" class="btn btn-primary"><i class="bi bi-check2-circle"></i> Guardar y ver resumen</button>
            <button type="button" class="btn btn-outline" onclick="irPaso(2)"><i class="bi bi-arrow-left"></i> Volver al recorrido</button>
        </div>
        <?php endif; ?>
    </form>

    <!-- Resumen de materiales (se llena al calcular) -->
    <div id="resumen-materiales" style="margin-top:20px;"></div>
</div>

</div><!-- /wz-wrap -->

<!-- Input de archivo oculto. Sin 'capture' para que el móvil ofrezca cámara Y galería. -->
<!-- Dos entradas: la cámara abre a tomar la foto, la galería a elegirla. -->
<input type="file" id="rec-file-camara" accept="image/*" capture="environment" style="display:none;" onchange="_onFotoElegida(this, true)">
<input type="file" id="rec-file-galeria" accept="image/*" style="display:none;" onchange="_onFotoElegida(this, false)">

<!-- Comprobante: disponible en cualquier momento, con o sin señal -->
<button type="button" onclick="comprobanteLocal()"
        style="position:fixed;left:12px;bottom:56px;z-index:1400;background:#fff;
               border:1px solid #dbe0ec;border-radius:20px;padding:7px 14px;font-size:12.5px;
               font-weight:600;color:#22366F;cursor:pointer;box-shadow:0 2px 8px rgba(20,30,60,.12);"
        title="Constancia de lo registrado hasta ahora">
    <i class="bi bi-file-earmark-text"></i> Comprobante
</button>

<!-- Acceso a las fotos guardadas en el teléfono -->
<button type="button" onclick="ObrasFotos.verGaleria()"
        style="position:fixed;left:12px;bottom:12px;z-index:1400;background:#fff;
               border:1px solid #dbe0ec;border-radius:20px;padding:7px 14px;font-size:12.5px;
               font-weight:600;color:#22366F;cursor:pointer;box-shadow:0 2px 8px rgba(20,30,60,.12);"
        title="Fotos guardadas en este teléfono">
    <i class="bi bi-images"></i> Mis fotos
</button>

<script>
const INSPECCION_ID = <?= $inspeccionId ?>;
const EDIFICIO_ID = <?= (int)$ed['id'] ?>;
const URL_BASE = '<?= APP_URL_BASE ?>seguimiento/';
const PUEDE_EDITAR = <?= $puedeEditar ? 'true' : 'false' ?>;
const SOLO_LECTURA = <?= $soloLectura ? 'true' : 'false' ?>;

/* ===================================================================
 * BARRA DE AVANCE DEL LEVANTAMIENTO
 *
 * Vuelve a preguntar el porcentaje al servidor y actualiza la barra.
 * Se llama después de cada acción que agrega o completa un dato.
 * =================================================================== */
async function refrescarProgreso() {
    if (!EDIFICIO_ID) return;
    try {
        const res = await fetch(URL_BASE + 'progreso_levantamiento.php?edificio=' + EDIFICIO_ID,
                                { credentials: 'same-origin' });
        const d = await res.json();
        if (!d || !d.ok) return;

        const barra = document.getElementById('lev-prog-barra');
        const txt   = document.getElementById('lev-prog-txt');
        const det   = document.getElementById('lev-prog-detalle');

        if (barra) {
            barra.style.width = d.porcentaje + '%';
            barra.style.background = d.completo ? '#2E7D32' : '#22366F';
        }
        if (txt) {
            if (d.completo) {
                txt.innerHTML = '100% · <span style="color:#2E7D32;">Todo completo</span>';
            } else {
                txt.textContent = d.porcentaje + '% · Faltan ' + d.faltan
                                + ' dato' + (d.faltan === 1 ? '' : 's');
            }
        }
        if (det && d.grupos) {
            const partes = [];
            Object.values(d.grupos).forEach(g => {
                if (g.total > 0) partes.push(g.nombre + ' ' + g.hechos + '/' + g.total);
            });
            det.textContent = partes.join(' · ');
        }
    } catch (e) { /* si falla, se deja la barra como está */ }
}

/* ===================================================================
 * RESPONSABLE DEL LEVANTAMIENTO
 *
 * Puede ser un ingeniero del directorio, o cualquier otro profesional
 * que se registra aqui mismo con el interruptor "No es ingeniero".
 *
 * En los dos casos el responsable termina guardado igual: en la tabla
 * `ingenieros` y referenciado desde rec_edificio.ingeniero_id. No se
 * crea ninguna tabla ni columna nueva.
 * =================================================================== */

/** Asigna un ingeniero del directorio (selector normal). */
async function guardarIngeniero(sel) {
    if (!PUEDE_EDITAR) return;
    const valor = sel.value || null;
    sel.disabled = true;
    try {
        const res = await fetch(URL_BASE + 'guardar_rec_edificio.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                accion: 'ingeniero',
                inspeccion_id: INSPECCION_ID,
                edificio_id: EDIFICIO_ID,
                ingeniero_id: valor,
            }),
            credentials: 'same-origin'
        });
        const texto = await res.text();
        let d;
        try { d = JSON.parse(texto); }
        catch (err) {
            console.error('Respuesta del servidor:', texto);
            alert('El servidor devolvió una respuesta inesperada.');
            return;
        }
        if (!d.ok) alert(d.mensaje || 'No se pudo guardar el ingeniero.');
    } catch (e) {
        alert('No se pudo guardar el ingeniero. Revise su conexión.');
    } finally {
        sel.disabled = false;
    }
}

/** Muestra el selector de ingeniero o el formulario del profesional. */
function toggleNoIngeniero(chk) {
    const bIng  = document.getElementById('bloque-ingeniero');
    const bProf = document.getElementById('bloque-profesional');
    if (!bIng || !bProf) return;

    if (chk.checked) {
        bIng.style.display  = 'none';
        bProf.style.display = '';
    } else {
        bIng.style.display  = '';
        bProf.style.display = 'none';
        const aviso = document.getElementById('prof-aviso');
        if (aviso) aviso.innerHTML = '';
    }
}

/** Al elegir "Agregar otra profesión…" se muestra el campo de texto. */
function cambiarProfesion(sel) {
    const otra = document.getElementById('prof-profesion-nueva');
    if (!otra) return;
    if (sel.value === '__otra__') {
        otra.style.display = '';
        otra.focus();
    } else {
        otra.style.display = 'none';
        otra.value = '';
    }
}

/** Vista previa de la foto antes de subirla. */
function previsualizarFotoProf(input) {
    const caja = document.getElementById('prof-foto-previa');
    if (!caja) return;
    const f = input.files && input.files[0];
    if (!f) return;

    // Aviso temprano: el servidor rechaza lo que pase de 8 MB.
    if (f.size > 8 * 1024 * 1024) {
        alert('La foto pesa más de 8 MB. Elija una más liviana.');
        input.value = '';
        return;
    }
    const lector = new FileReader();
    lector.onload = e => {
        caja.style.backgroundImage = 'url(' + e.target.result + ')';
        caja.innerHTML = '';
    };
    lector.readAsDataURL(f);
}

/** Profesión elegida, ya sea del desplegable o escrita a mano. */
function profesionElegida() {
    const sel = document.getElementById('prof-profesion');
    if (!sel) return '';
    if (sel.value === '__otra__') {
        const otra = document.getElementById('prof-profesion-nueva');
        return otra ? otra.value.trim() : '';
    }
    return sel.value.trim();
}

/** Guarda al profesional que no es ingeniero y lo deja como responsable. */
async function guardarProfesional(btn) {
    if (!PUEDE_EDITAR) return;

    const aviso = document.getElementById('prof-aviso');
    const pinta = (txt, color) => {
        if (aviso) {
            aviso.innerHTML = txt;
            aviso.style.color = color;
        }
    };

    const nombre    = (document.getElementById('prof-nombre').value || '').trim();
    const cedula    = (document.getElementById('prof-cedula').value || '').trim();
    const telefono  = (document.getElementById('prof-telefono').value || '').trim();
    const profesion = profesionElegida();

    // Los cuatro son obligatorios; la foto no.
    const faltan = [];
    if (!nombre)    faltan.push('nombre completo');
    if (!cedula)    faltan.push('cédula');
    if (!telefono)  faltan.push('número de teléfono');
    if (!profesion) faltan.push('profesión');

    if (faltan.length) {
        pinta('Falta completar: ' + faltan.join(', ') + '.', '#A61C1C');
        const primero = !nombre ? 'prof-nombre'
                      : !cedula ? 'prof-cedula'
                      : !telefono ? 'prof-telefono'
                      : 'prof-profesion';
        const el = document.getElementById(primero);
        if (el) el.focus();
        return;
    }

    const datos = new FormData();
    datos.append('inspeccion_id', INSPECCION_ID);
    datos.append('edificio_id', EDIFICIO_ID);
    datos.append('nombre', nombre);
    datos.append('cedula', cedula);
    datos.append('telefono', telefono);
    datos.append('profesion', profesion);

    const idPrev = document.getElementById('prof-id');
    if (idPrev && idPrev.value) datos.append('profesional_id', idPrev.value);

    const foto = document.getElementById('prof-foto');
    if (foto && foto.files && foto.files[0]) datos.append('foto', foto.files[0]);

    btn.disabled = true;
    const htmlPrev = btn.innerHTML;
    btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Guardando…';
    pinta('', '');

    try {
        const res = await fetch(URL_BASE + 'guardar_profesional_rec.php', {
            method: 'POST', body: datos, credentials: 'same-origin'
        });
        const texto = await res.text();
        let d;
        try { d = JSON.parse(texto); }
        catch (err) {
            console.error('Respuesta del servidor:', texto);
            pinta('El servidor devolvió una respuesta inesperada.', '#A61C1C');
            return;
        }

        if (!d.ok) {
            pinta(d.mensaje || 'No se pudo guardar.', '#A61C1C');
            return;
        }

        // Queda el id para que un segundo guardado actualice en vez de duplicar.
        if (idPrev && d.profesional_id) idPrev.value = d.profesional_id;
        if (foto) foto.value = '';
        pinta('<i class="bi bi-check-circle-fill"></i> ' + (d.mensaje || 'Guardado.'), '#2E7D32');

    } catch (e) {
        pinta('No se pudo guardar. Revise su conexión.', '#A61C1C');
    } finally {
        btn.disabled = false;
        btn.innerHTML = htmlPrev;
    }
}

// Cuántos pisos tiene ya el servidor. Si son más de cero, la copia
// local del teléfono sobra y se descarta para no duplicar.
const PISOS_REALES = <?= count($pisos ?? []) ?>;

// En casas no hay apartamentos: cada nivel lleva sus ambientes directo.
const ES_CASA = <?php
    $u = mb_strtolower(trim($insp['uso_edificacion'] ?? ''), 'UTF-8');
    echo (strpos($u, 'casa') !== false || strpos($u, 'unifamiliar') !== false)
         ? 'true' : 'false';
?>;

/**
 * En modo consulta se desactivan los campos y botones de edición,
 * pero las fotos siguen siendo ampliables y todo queda visible.
 */
function aplicarSoloLectura() {
    if (!SOLO_LECTURA) return;
    const cont = document.querySelector('.wz-wrap');
    if (!cont) return;

    cont.querySelectorAll('input, select, textarea').forEach(el => {
        el.disabled = true;
        el.style.background = '#f7f9fd';
        el.style.cursor = 'not-allowed';
    });

    cont.querySelectorAll('button').forEach(b => {
        const txt = (b.textContent || '').toLowerCase();
        // Los botones de navegación y de ver siguen activos.
        if (txt.includes('siguiente') || txt.includes('anterior')
            || txt.includes('volver') || txt.includes('comprobante')) return;
        b.disabled = true;
        b.style.opacity = '.45';
        b.style.cursor = 'not-allowed';
    });
}
// El script va al final: el DOM ya está listo, no hace falta esperar.
try { aplicarSoloLectura(); } catch (e) { /* seguir */ }
const RECETAS_TRABAJO = <?= json_encode(array_map(
    fn($lista) => array_map(fn($r) => [
        'material' => $r['material'], 'unidad' => $r['unidad'],
        'cantidad' => (float)$r['cantidad'],
    ], $lista),
    recRecetasTrabajo()
), JSON_UNESCAPED_UNICODE) ?>;

const TIPOS_TRABAJO = <?= json_encode(array_map(fn($t) => [
    'clave' => $t['clave'], 'nombre' => $t['nombre'],
    'descripcion' => $t['descripcion'] ?? '',
    'aplica' => $t['aplica_a'] ?? '',
], recTiposTrabajo()), JSON_UNESCAPED_UNICODE) ?>;

/**
 * Trabajos ADICIONALES ya guardados en cada area comun.
 * Se usan para volver a dibujarlos al recargar el paso 1: sin esto el
 * formulario aparecia sin ellos y al guardar de nuevo se borraban.
 * Forma: { lobby: [ { trabajo: 'friso_pared', sup: { pared: 12 } } ], ... }
 */
const AREA_EXTRAS = <?= json_encode(array_map(
    fn($r) => array_map(
        fn($tt, $sups) => ['trabajo' => $tt, 'sup' => $sups],
        array_keys($r['extras'] ?? []),
        array_values($r['extras'] ?? [])
    ),
    $repAreas ?? []
), JSON_UNESCAPED_UNICODE) ?>;

// Redibujar los trabajos adicionales guardados de cada area comun.
// Este <script> va DESPUES de la grilla de areas, asi que el DOM que
// necesita ya existe. Si DOMContentLoaded ya paso (script al final de
// la pagina), el listener no se dispararia nunca: por eso se ejecuta
// directamente en ese caso.
function restaurarExtrasAreas() {
    try {
        Object.keys(AREA_EXTRAS || {}).forEach(function (clave) {
            const lista = AREA_EXTRAS[clave] || [];
            if (!lista.length) return;
            const row = document.querySelector('.area-row[data-area="' + clave + '"]');
            if (!row) return;
            lista.forEach(function (ex) { agregarPartidaArea(row, clave, ex); });
        });
    } catch (e) { /* si algo falla, el paso 1 sigue usable */ }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', restaurarExtrasAreas);
} else {
    restaurarExtrasAreas();
}

/**
 * Avisa qué superficies cuentan para el trabajo elegido.
 * Levantar una pared consume metros de PARED: si el técnico llena
 * también techo y piso, esos metros no entran en el cálculo.
 */
function avisoSuperficies(sel) {
    const row = sel.closest('.amb-row');
    if (!row) return;
    const t = (TIPOS_TRABAJO || []).find(x => x.clave === sel.value);
    let aviso = row.querySelector('.amb-aplica');
    if (!aviso) {
        aviso = document.createElement('div');
        aviso.className = 'amb-aplica';
        aviso.style.cssText = 'font-size:11.5px;margin:-4px 0 8px;';
        sel.parentNode.insertBefore(aviso, sel.nextSibling);
    }
    if (!t || !t.aplica) { aviso.textContent = ''; return; }
    const sups = t.aplica.split(',').map(x => x.trim()).filter(Boolean);
    aviso.style.color = '#8a6d1a';
    const nombres = { pared: 'PARED', techo: 'TECHO', piso: 'PISO' };
    const legibles = sups.map(x => nombres[x] || x.toUpperCase());
    aviso.innerHTML = '<i class="bi bi-info-circle"></i> Anote los metros en: '
        + '<strong>' + legibles.join(' o ') + '</strong>'
        + (legibles.length === 1
            ? ' — los demás campos no cuentan para este trabajo.'
            : '');
}

const APTOS_POR_PISO = <?= (int)($ed['aptos_por_piso'] ?: 1) ?>;
const EDIFICIO_NOMBRE    = <?= json_encode($insp['nombre_edificio'] ?? '', JSON_UNESCAPED_UNICODE) ?>;
const EDIFICIO_CODIGO    = <?= json_encode($insp['codigo'] ?? '', JSON_UNESCAPED_UNICODE) ?>;
const EDIFICIO_PARROQUIA = <?= json_encode($insp['parroquia'] ?? '', JSON_UNESCAPED_UNICODE) ?>;

function irPaso(n) {
    [1,2,3].forEach(i => {
        document.getElementById('paso-'+i).classList.toggle('hidden', i !== n);
        document.getElementById('tab-'+i).classList.toggle('activo', i === n);
    });
    if (n === 2) { try { cargarLocales(); } catch (e) {} }
    if (n === 3) cargarResumen();
    window.scrollTo({top:0, behavior:'smooth'});
}

// Al marcar/desmarcar "Reparar" en un área, mostrar u ocultar su detalle.
document.querySelectorAll('.area-row .area-reparar').forEach(chk => {
    chk.addEventListener('change', function(){
        const row = this.closest('.area-row');
        const detalle = row.querySelector('.area-detalle');
        const lbl = row.querySelector('.area-chk-lbl');
        if (this.checked) {
            detalle.style.display = 'block';
            lbl.style.background = '#fdf3e7';
            lbl.style.fontWeight = '600';
            lbl.style.color = '#A66A00';
        } else {
            detalle.style.display = 'none';
            lbl.style.background = '';
            lbl.style.fontWeight = '';
            lbl.style.color = '';
        }
    });
});

// Subir foto de un área común a reparar.
let _areaFotoDestino = null;
// Destino de la próxima foto. Se declara aquí porque varias funciones
// de más arriba la usan antes de que el script llegue a su definición.
var _fotoDestino = null;

/**
 * Agrega un área común que no está en la lista.
 * El técnico escribe el nombre y queda con su botón de reparación,
 * foto, trabajo y metros, igual que las demás.
 */
async function agregarAreaOtra() {
    const inp = document.getElementById('area-otra-nombre');
    const nombre = (inp.value || '').trim();
    if (nombre.length < 3) {
        alert('Escriba el nombre del área (al menos 3 letras).');
        inp.focus();
        return;
    }

    // Clave interna: "otra_" + el nombre sin espacios ni acentos.
    const clave = 'otra_' + nombre.toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40);

    if (document.querySelector('.area-row[data-area="' + clave + '"]')) {
        alert('Ya existe un área con ese nombre.');
        return;
    }

    // Se manda también la inspección: el endpoint la necesita para
    // ubicar el edificio, y sin ella el envío diferido se rechaza.
    const payload = { accion: 'area_libre',
                      inspeccion_id: INSPECCION_ID,
                      edificio_id: EDIFICIO_ID,
                      clave: clave, nombre: nombre };

    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_edificio.php', payload,
            'Área común: ' + nombre);
        // Queda anotada en el teléfono: si se recarga la página antes
        // de recuperar señal, el área sigue ahí.
        try {
            const k = 'areas_libres_' + INSPECCION_ID;
            const prev = JSON.parse(localStorage.getItem(k) || '[]');
            if (!prev.some(a => a.clave === clave)) {
                prev.push({ clave: clave, nombre: nombre });
                localStorage.setItem(k, JSON.stringify(prev));
            }
        } catch (e) { /* sin espacio: seguir igual */ }
    } else {
        try {
            const res = await fetch(URL_BASE + 'guardar_rec_edificio.php', {
                method:'POST', headers:{'Content-Type':'application/json'},
                body: JSON.stringify(payload), credentials:'same-origin'
            });
            const d = await res.json();
            if (!d.ok) { alert(d.mensaje || 'No se pudo agregar.'); return; }
        } catch (e) {
            alert('Sin conexión. Intente de nuevo.');
            return;
        }
    }

    inp.value = '';
    pintarAreaNueva(clave, nombre);
}

/**
 * Limpia la estructura local cuando el servidor ya tiene los pisos.
 *
 * Si no se limpia, al volver a entrar el sistema sigue mostrando los
 * pisos del teléfono con ids negativos, y al guardar algo se crean
 * duplicados.
 */
function limpiarEstructuraLocalSiYaEsta() {
    try {
        // PISOS_REALES lo escribe el PHP: si el servidor ya tiene
        // pisos, lo del teléfono sobra.
        if (typeof PISOS_REALES === 'number' && PISOS_REALES > 0) {
            localStorage.removeItem('estructura_' + INSPECCION_ID);
        }
    } catch (e) { /* no interrumpir */ }
}

try { limpiarEstructuraLocalSiYaEsta(); } catch (e) { /* seguir */ }

/**
 * Vuelve a dibujar las áreas que se agregaron sin señal.
 * Se llama al cargar: si el técnico recargó la página antes de
 * recuperar conexión, sus áreas siguen ahí.
 */
function restaurarAreasLibres() {
    try {
        const k = 'areas_libres_' + INSPECCION_ID;
        const guardadas = JSON.parse(localStorage.getItem(k) || '[]');
        if (!guardadas.length) return;

        guardadas.forEach(a => {
            // Si ya está en pantalla, no se duplica.
            if (document.querySelector('.area-row[data-area="' + a.clave + '"]')) return;
            pintarAreaNueva(a.clave, a.nombre);
        });
    } catch (e) { /* no interrumpir */ }
}

/** Dibuja el área recién agregada, sin recargar la página. */
function pintarAreaNueva(clave, nombre) {
    const grid = document.querySelector('.area-row')?.parentNode;
    if (!grid) { location.reload(); return; }

    const opciones = (Array.isArray(TIPOS_TRABAJO) ? TIPOS_TRABAJO : [])
        .map(t => '<option value="' + t.clave + '">' + t.nombre + '</option>').join('');

    const div = document.createElement('div');
    div.className = 'area-row';
    div.dataset.area = clave;
    div.style.cssText = 'border:1px solid #2d448855;border-radius:8px;overflow:hidden;';
    div.innerHTML =
        '<label class="area-chk-lbl" style="display:flex;align-items:center;'
        + 'justify-content:space-between;gap:7px;padding:9px 11px;cursor:pointer;font-size:13px;">'
        + '<span>' + nombre + '</span>'
        + '<span class="seg-radio" style="font-size:12px;white-space:nowrap;">'
        + '<input type="checkbox" class="area-reparar"> <i class="bi bi-tools"></i> Reparar'
        + '</span></label>'
        + '<div class="area-detalle" style="padding:10px 11px;background:#f9fafd;display:none;">'
        + '<button type="button" class="btn btn-outline btn-sm" '
        + 'onclick="subirFotoArea(\'' + clave + '\', this)" style="margin-bottom:8px;">'
        + '<i class="bi bi-camera"></i> Foto del área a reparar</button>'
        + '<div class="area-fotos" style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px;"></div>'
        + '<label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">'
        + '¿Qué trabajo necesita?</label>'
        + '<select class="form-control area-trabajo" '
        + 'style="width:100%;padding:6px 8px;font-size:12.5px;margin-bottom:8px;" '
        + 'onchange="calcularMatArea(this)">'
        + '<option value="">Seleccione…</option>' + opciones + '</select>'
        + '<label style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">'
        + 'Metros cuadrados a reparar</label>'

        // Mismos tres campos por superficie que las áreas del catálogo.
        // Antes había un solo input y el guardado —que lee .area-sup—
        // no encontraba nada, así que los metros se perdían.
        + '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">'
        + ['pared', 'techo', 'piso'].map(sup =>
            '<div style="width:104px;">'
            + '<label class="text-sm" style="text-transform:capitalize;font-size:11px;">'
            + sup + '</label>'
            + '<div style="display:flex;align-items:center;gap:4px;">'
            + '<input type="text" inputmode="decimal" class="form-control area-sup" '
            + 'data-sup="' + sup + '" value="" '
            + 'style="flex:1;min-width:0;padding:6px 8px;font-size:12.5px;" '
            + 'oninput="normalizarDecimal(this); calcularMatArea(this);">'
            + '<span style="font-size:11px;color:#8a6d1a;font-weight:600;">m²</span>'
            + '</div></div>').join('')
        + '</div>'

        // Campo oculto con el total, igual que en el catálogo.
        + '<input type="hidden" class="area-m2" value="">'

        + '<button type="button" class="btn btn-outline btn-sm" '
        + 'style="margin-bottom:8px;border-color:#2d448855;color:#2d4488;font-size:11.5px;" '
        + 'onclick="agregarPartidaArea(this, \'' + clave + '\')">'
        + '<i class="bi bi-plus-circle"></i> Agregar otro trabajo aquí</button>'
        + '<div class="area-partidas"></div>'

        + '<div class="area-materiales" style="font-size:12px;color:#22366F;background:#eef2fb;'
        + 'border-radius:6px;padding:8px 10px;display:none;"></div></div>';

    grid.appendChild(div);

    // El checkbox "Reparar" de las filas del catálogo se conecta al cargar
    // la página; esta fila nace después, así que hay que conectarla aquí.
    const chk = div.querySelector('.area-reparar');
    if (chk) {
        chk.addEventListener('change', function () {
            const det = div.querySelector('.area-detalle');
            if (det) det.style.display = this.checked ? 'block' : 'none';
            const lbl = div.querySelector('.area-chk-lbl');
            if (lbl) {
                lbl.style.background  = this.checked ? '#fdf3e7' : '';
                lbl.style.fontWeight  = this.checked ? '600' : '';
                lbl.style.color       = this.checked ? '#A66A00' : '';
            }
        });
    }

    div.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return div;
}

/**
 * Agrega otro trabajo a la misma área común.
 * Funciona igual que en los ambientes: un área puede necesitar
 * demolición y además friso, por ejemplo.
 */
/**
 * Agrega un bloque de "otro trabajo" a un area comun.
 * `pre` permite reconstruir un trabajo ya guardado al recargar la pagina:
 *   pre = { trabajo: 'friso_pared', sup: { pared: 12, techo: 4 } }
 * `ctx` puede ser el boton (uso normal) o la propia .area-row (precarga).
 */
function agregarPartidaArea(ctx, clave, pre) {
    const row = (ctx && ctx.classList && ctx.classList.contains('area-row'))
        ? ctx : (ctx ? ctx.closest('.area-row') : null);
    const cont = row ? row.querySelector('.area-partidas') : null;
    if (!cont) return;

    const n = cont.querySelectorAll('.partida-area').length + 2;
    const trabPre = (pre && pre.trabajo) ? String(pre.trabajo) : '';
    const opciones = (Array.isArray(TIPOS_TRABAJO) ? TIPOS_TRABAJO : [])
        .map(t => '<option value="' + t.clave + '"'
                + (String(t.clave) === trabPre ? ' selected' : '')
                + '>' + t.nombre + '</option>').join('');

    const bloque = document.createElement('div');
    bloque.className = 'partida-area';
    bloque.style.cssText = 'border-top:1px dashed #C9A22766;margin-top:9px;padding-top:9px;';
    bloque.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:center;'
        + 'margin-bottom:6px;">'
        + '<span style="font-size:11.5px;font-weight:700;color:#8a6d1a;">'
        + '<i class="bi bi-tools"></i> Trabajo ' + n + '</span>'
        + '<button type="button" onclick="this.closest(\'.partida-area\').remove()" '
        + 'style="background:transparent;border:0;color:#c4c9d6;cursor:pointer;">'
        + '<i class="bi bi-x-circle"></i></button></div>'

        + '<select class="form-control part-area-trabajo" '
        + 'style="width:100%;padding:6px 8px;font-size:12.5px;margin-bottom:7px;" '
        + 'onchange="calcularMatArea(this)">'
        + '<option value="">— ¿Qué trabajo? —</option>' + opciones + '</select>'

        + '<div style="display:flex;gap:8px;flex-wrap:wrap;">'
        + ['pared','techo','piso'].map(sup =>
            '<div style="width:104px;">'
            + '<label class="text-sm" style="text-transform:capitalize;font-size:11px;">'
            + sup + '</label>'
            + '<div style="display:flex;align-items:center;gap:4px;">'
            + '<input type="text" inputmode="decimal" class="form-control part-area-m2" '
            + 'data-sup="' + sup + '" value="'
            + ((pre && pre.sup && pre.sup[sup])
                ? String(pre.sup[sup]).replace('.', ',') : '')
            + '" style="flex:1;min-width:0;'
            + 'padding:6px 8px;font-size:12.5px;" '
            + 'oninput="normalizarDecimal(this); calcularMatArea(this);">'
            + '<span style="font-size:11px;color:#8a6d1a;font-weight:600;">m²</span>'
            + '</div></div>').join('')
        + '</div>';

    cont.appendChild(bloque);
    const sel = bloque.querySelector('.part-area-trabajo');
    // Al precargar no se roba el foco: el tecnico no pidio escribir aqui.
    if (sel && !pre) sel.focus();
}

/** Foto de un área común del edificio. */
function subirFotoArea(areaKey, btn) {
    const cont = btn.closest('.area-row').querySelector('.area-fotos');
    cont.dataset.area = areaKey;
    _areaFotoDestino = cont;
    elegirOrigenFoto({
        nivel: 'edificio',
        refId: EDIFICIO_ID,
        pideParte: false,
        parteFija: areaKey,
        cont: cont,
    });
}

// Calcular materiales de un área según m² y tipo de trabajo.
/* ===================================================================
 * CEMENTO GRIS · BADGE DE SACOS DE 45 KG (lado cliente)
 * Espejo de badgeSacosCementoGris() de includes/seguimiento.php.
 * Si la receta ya viene en 'saco', esa cifra YA cuenta sacos de 45 kg
 * y no se vuelve a dividir. En kg se divide entre 45.
 * =================================================================== */
const KG_POR_SACO_CEMENTO = 45;

function esCementoGrisJS(material) {
    const m = String(material || '').toLowerCase();
    return m.indexOf('cemento') !== -1 && m.indexOf('gris') !== -1;
}

function sacosCementoGrisJS(cantidad, unidad) {
    const c = parseFloat(cantidad) || 0;
    if (c <= 0) return 0;
    const u = String(unidad || 'kg').toLowerCase().trim();
    if (u === 'saco' || u === 'sacos') return Math.ceil(c);
    return Math.ceil(c / KG_POR_SACO_CEMENTO);
}

/** Badge listo para insertar debajo del indicador. '' si no aplica. */
function badgeSacosCementoGrisJS(material, cantidad, unidad) {
    if (!esCementoGrisJS(material)) return '';
    const s = sacosCementoGrisJS(cantidad, unidad);
    if (s <= 0) return '';
    return '<div style="display:inline-block;background:#8a6d1a14;'
         + 'border:1px solid #8a6d1a3a;border-radius:20px;padding:2px 8px;'
         + 'margin-top:3px;font-size:11px;color:#8a6d1a;font-weight:700;'
         + 'line-height:1.3;">Cantidad de sacos de 45 kg: '
         + s.toLocaleString('es-VE') + '</div>';
}

async function calcularMatArea(inp) {
    if (!inp) return;
    const row = inp.closest('.area-row');
    if (!row) return;

    // Se suman las tres superficies, igual que en los ambientes.
    let m2 = 0;
    row.querySelectorAll('.area-sup').forEach(i => { m2 += aNumero(i.value); });

    // El campo oculto conserva el total para el guardado.
    const oculto = row.querySelector('.area-m2');
    if (oculto) oculto.value = m2 > 0 ? String(m2).replace('.', ',') : '';

    // Se suman también los trabajos adicionales del área.
    const partidas = [];
    const selPrin = row.querySelector('.area-trabajo');
    if (selPrin && selPrin.value && m2 > 0) {
        partidas.push({ trabajo: selPrin.value, m2: m2 });
    }
    row.querySelectorAll('.partida-area').forEach(bl => {
        const st = bl.querySelector('.part-area-trabajo');
        let sub = 0;
        bl.querySelectorAll('.part-area-m2').forEach(i => { sub += aNumero(i.value); });
        if (st && st.value && sub > 0) partidas.push({ trabajo: st.value, m2: sub });
    });

    const cont = row.querySelector('.area-materiales');
    if (!cont) return;

    if (!partidas.length) { cont.style.display = 'none'; return; }

    cont.innerHTML = '<span style="color:#767c94;">Calculando materiales…</span>';
    cont.style.display = 'block';

    try {
        // Se pide el material de cada trabajo y se suman los repetidos.
        const total = {};
        for (const p of partidas) {
            const res = await fetch(URL_BASE + 'calcular_materiales.php?tipo='
                + encodeURIComponent(p.trabajo) + '&m2=' + p.m2);
            const d = await res.json();
            if (!d.ok || !d.materiales) continue;
            d.materiales.forEach(m => {
                const k = m.material;
                if (!total[k]) total[k] = { cant: 0, uni: m.unidad };
                total[k].cant += parseFloat(String(m.cantidad).replace(',', '.')) || 0;
            });
        }

        const claves = Object.keys(total).sort();
        if (!claves.length) { cont.style.display = 'none'; return; }

        // El cemento gris se compra en sacos de 45 kg: se muestra el badge.
        cont.innerHTML = '<b><i class="bi bi-box-seam"></i> Materiales estimados</b>'
            + (partidas.length > 1
                ? ' <span style="color:#767c94;font-weight:400;">('
                  + partidas.length + ' trabajos)</span>' : '')
            + '<br>'
            + claves.map(k => {
                const d = total[k];
                const n = d.cant.toLocaleString('es-VE',
                    { maximumFractionDigits: d.uni === 'm3' ? 2 : 0 });
                const extra = badgeSacosCementoGrisJS(k, d.cant, d.uni);
                return '• ' + k + ': <b>' + n + '</b> ' + d.uni + extra;
            }).join('<br>');
        cont.style.display = 'block';

    } catch (e) {
        cont.innerHTML = '<span style="color:#767c94;">'
            + 'No se pudo calcular. Se guardará igual.</span>';
    }
}
// Recalcular también al cambiar el tipo de trabajo.
document.querySelectorAll('.area-trabajo').forEach(sel => {
    sel.addEventListener('change', function(){
        calcularMatArea(this.closest('.area-row').querySelector('.area-m2'));
    });
});

// ================= PASO 1: DATOS DEL EDIFICIO =================
// Campo calculado: total de apartamentos = pisos × apartamentos por piso.
function toggleLocales(chk) {
    const det = document.getElementById('locales-detalle');
    if (det) det.style.display = chk.checked ? 'block' : 'none';
    if (!chk.checked) {
        const n = document.getElementById('num_locales');
        if (n) n.value = '';
    }
}

function calcularTotalAptos() {
    const pisos = parseInt(document.getElementById('num_pisos').value) || 0;
    const app = parseInt(document.getElementById('aptos_por_piso').value) || 0;
    document.getElementById('total_apartamentos').value = pisos * app;
}

async function guardarEdificio(ev) {
    ev.preventDefault();
    if (!PUEDE_EDITAR) return false;
    const payload = {
        inspeccion_id: INSPECCION_ID,
        num_pisos: document.getElementById('num_pisos').value,
        aptos_por_piso: document.getElementById('aptos_por_piso').value,
        tiene_areas_comunes: 1,
        tiene_locales: document.getElementById('tiene-locales')?.checked ? 1 : 0,
        num_locales: parseInt(document.getElementById('num_locales')?.value) || 0,
        areas_comunes: [],
    };
    // Areas marcadas pero sin datos: se avisa antes de guardar.
    const areasIncompletas = [];

    // Recolectar las áreas marcadas para reparar, con su trabajo y m².
    document.querySelectorAll('.area-row').forEach(row => {
        if (!row.querySelector('.area-reparar').checked) return;

        // Metros por superficie, igual que en los ambientes.
        const sups = {};
        let total = 0;
        row.querySelectorAll('.area-sup').forEach(i => {
            const v = aNumero(i.value);
            if (v > 0) { sups[i.dataset.sup] = v; total += v; }
        });

        // Trabajos adicionales de la misma área.
        const extras = [];
        row.querySelectorAll('.partida-area').forEach(bl => {
            const st = bl.querySelector('.part-area-trabajo');
            const mm = {};
            let sub = 0;
            bl.querySelectorAll('.part-area-m2').forEach(i => {
                const v = aNumero(i.value);
                if (v > 0) { mm[i.dataset.sup] = v; sub += v; }
            });
            if (st && st.value && sub > 0) {
                extras.push({ tipo_trabajo: st.value, superficies: mm,
                              metros_cuadrados: sub });
            }
        });

        // Nombre visible: en las áreas "Otros" es lo único que permite
        // volver a dibujar la fila después de refrescar.
        const lblNom = row.querySelector('.area-chk-lbl span');
        const selArea = row.querySelector('.area-trabajo');

        payload.areas_comunes.push({
            tipo: row.dataset.area,
            nombre_libre: lblNom ? lblNom.textContent.trim() : '',
            necesita_reparacion: 1,
            tipo_trabajo: selArea ? selArea.value : '',
            metros_cuadrados: total,
            superficies: sups,
            extras: extras,
        });

        // Si un area quedo marcada pero sin trabajo ni metros, se avisa:
        // guardarla asi borraria lo que ya estuviera registrado.
        if (!row.querySelector('.area-trabajo').value || total <= 0) {
            const lbl = row.querySelector('.area-chk-lbl span');
            areasIncompletas.push(lbl ? lbl.textContent.trim() : row.dataset.area);
        }
    });

    // Aviso claro antes de sobreescribir con datos vacios.
    if (areasIncompletas.length) {
        const seguir = confirm(
            'Estas areas comunes estan marcadas para reparar pero les falta '
            + 'el tipo de trabajo o los metros:\n\n· '
            + areasIncompletas.join('\n· ')
            + '\n\nSi continua, se guardaran sin esos datos.\n'
            + '¿Desea continuar de todos modos?');
        if (!seguir) return false;
    }
    // Copia local siempre, antes de intentar enviar.
    guardarBorrador('paso1_' + INSPECCION_ID, payload);

    // SIN SEÑAL: se generan los pisos aquí mismo para poder seguir llenando.
    if (!navigator.onLine) {
        await continuarSinSenal(payload);
        return false;
    }

    try {
        const res = await fetch(URL_BASE + 'guardar_rec_edificio.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials:'same-origin'
        });
        const texto = await res.text();
        let data;
        try { data = JSON.parse(texto); }
        catch (e) { await continuarSinSenal(payload); return false; }

        if (data.ok) {
            borrarBorrador('paso1_' + INSPECCION_ID);
            location.href = 'levantamiento.php?inspeccion=' + INSPECCION_ID + '&paso=2';
        } else {
            alert(data.mensaje || 'Error al guardar.');
        }
    } catch (e) {
        // Se cayó la señal: seguir trabajando igual.
        await continuarSinSenal(payload);
    }
    return false;
}

/**
 * Permite continuar el levantamiento sin conexión.
 * Genera los pisos y apartamentos en el navegador, con la misma
 * nomenclatura que usaría el servidor, y encola el guardado real.
 */
async function continuarSinSenal(payload) {
    const nPisos = parseInt(payload.num_pisos) || 0;
    const nAptos = parseInt(payload.aptos_por_piso) || 0;
    if (nPisos < 1) { alert('Indique la cantidad de pisos.'); return; }

    // Si ya se creó la estructura antes, no se vuelve a encolar: dos
    // envíos hacen que el servidor genere los pisos dos veces y el
    // levantamiento queda duplicado.
    let yaCreada = null;
    try {
        yaCreada = JSON.parse(localStorage.getItem('estructura_' + INSPECCION_ID) || 'null');
    } catch (e) { yaCreada = null; }

    const mismaEstructura = yaCreada
        && parseInt(yaCreada.num_pisos) === nPisos
        && parseInt(yaCreada.aptos_por_piso) === nAptos;

    if (mismaEstructura) {
        // Nada cambió: se vuelve a dibujar lo que ya está guardado.
        dibujarEstructuraLocal(yaCreada);
        irPaso(2);
        return;
    }

    if (yaCreada && !mismaEstructura) {
        const ok = confirm(
            'Ya había creado ' + yaCreada.num_pisos + ' piso(s) en este teléfono.\n\n'
            + 'Si continúa, se reemplazan por ' + nPisos + ' piso(s) y se pierde '
            + 'lo que haya llenado.\n\n¿Seguro que quiere cambiarlos?');
        if (!ok) return;

        // Se quita el envío anterior para que no lleguen los dos.
        if (window.ObrasOffline && ObrasOffline.quitarDeCola) {
            try { await ObrasOffline.quitarDeCola('estructura_' + INSPECCION_ID); }
            catch (e) { /* seguir */ }
        }
    }

    if (window.ObrasOffline) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_edificio.php', payload,
            'Datos del edificio (paso 1)', 'estructura_' + INSPECCION_ID);
    }

    // Estructura local: los ids son negativos para distinguirlos de los
    // reales del servidor. Al sincronizar se reemplazan por los definitivos.
    // Se guardan las cantidades para poder comparar después: si el
    // técnico vuelve a tocar "Continuar" con los mismos números, no
    // hace falta recrear nada ni encolar otro envío.
    const estructura = {
        inspeccion: INSPECCION_ID,
        num_pisos: nPisos,
        aptos_por_piso: nAptos,
        pisos: [],
        creada_en: new Date().toISOString(),
    };
    for (let p = 1; p <= nPisos; p++) {
        const piso = { id: -p, numero_piso: p, apartamentos: [] };
        for (let a = 1; a <= nAptos; a++) {
            const letra = a <= 26 ? String.fromCharCode(64 + a) : String(a);
            piso.apartamentos.push({
                id: -(p * 1000 + a),
                identificador: p + '-' + letra,
                jefe_nombre: '', jefe_cedula: '', jefe_telefono: '',
                num_habitaciones: 0, num_salas: 0, num_banos: 0,
                num_cocinas: 0, num_balcones: 0,
                local: true,
            });
        }
        estructura.pisos.push(piso);
    }

    try {
        localStorage.setItem('estructura_' + INSPECCION_ID, JSON.stringify(estructura));
    } catch (e) { /* seguir igual */ }

    alert('Sin señal: puede continuar el levantamiento.\n\n'
        + 'Se prepararon ' + nPisos + ' piso(s) con ' + nAptos + ' apartamento(s) cada uno. '
        + 'Todo lo que registre se guardará en el teléfono y subirá al recuperar la conexión.');

    dibujarEstructuraLocal(estructura);
    irPaso(2);
}

/** Dibuja los pisos y apartamentos generados sin conexión. */
function dibujarEstructuraLocal(estructura) {
    const panel = document.getElementById('paso-2');
    if (!panel) return;

    // Aviso de que se está trabajando con una estructura local.
    if (!document.getElementById('aviso-local')) {
        const av = document.createElement('div');
        av.id = 'aviso-local';
        av.style.cssText = 'background:#fffbf0;border:1px solid #C9A22755;border-radius:9px;'
            + 'padding:11px 14px;margin-bottom:14px;font-size:13px;color:#8a6d1a;';
        av.innerHTML = '<i class="bi bi-phone-fill"></i> <strong>Trabajando sin señal.</strong> '
            + 'Los pisos y apartamentos se crearon en su teléfono. '
            + 'Al recuperar la conexión se enviarán al sistema.';
        panel.insertBefore(av, panel.firstChild);
    }

    // Selector de pisos.
    let sel = document.getElementById('selector-piso');
    if (!sel) {
        const cont = document.createElement('div');
        cont.className = 'field';
        cont.style.cssText = 'max-width:320px;margin-bottom:16px;';
        cont.innerHTML = '<label class="text-sm" style="font-weight:600;">'
            + '<i class="bi bi-list-ol"></i> Seleccione el piso</label>'
            + '<select id="selector-piso" class="form-control" onchange="mostrarPisoLocal()"></select>';
        panel.appendChild(cont);
        sel = document.getElementById('selector-piso');
    }
    sel.innerHTML = '<option value="">— Elija un piso —</option>'
        + estructura.pisos.map(p => '<option value="' + p.id + '">Piso ' + p.numero_piso + '</option>').join('');

    // Contenedor de los apartamentos del piso elegido.
    if (!document.getElementById('piso-local-cont')) {
        const c = document.createElement('div');
        c.id = 'piso-local-cont';
        panel.appendChild(c);
    }
    window._estructuraLocal = estructura;
}

/** Muestra los apartamentos del piso seleccionado (modo sin señal). */
function mostrarPisoLocal() {
    const sel = document.getElementById('selector-piso');
    const cont = document.getElementById('piso-local-cont');
    if (!sel || !cont || !window._estructuraLocal) return;
    const pid = parseInt(sel.value);
    if (!pid) { cont.innerHTML = ''; return; }

    const piso = window._estructuraLocal.pisos.find(p => p.id === pid);
    if (!piso) return;

    cont.innerHTML = '<div class="bloque-tit" style="margin-top:16px;">'
        + '<i class="bi bi-door-open"></i> Apartamentos del piso ' + piso.numero_piso + '</div>'
        + '<div class="apto-lista" id="apto-lista-local"></div>';

    const lista = document.getElementById('apto-lista-local');
    piso.apartamentos.forEach(a => pintarApartamento(a, lista));
}

// ================= PASO 2: PISOS =================
// Muestra solo el piso seleccionado en el dropdown.
// Cargar los locales comerciales del edificio y pintarlos.
async function cargarLocales() {
    const lista = document.getElementById('locales-lista');
    if (!lista || lista.dataset.cargado) return;
    lista.dataset.cargado = '1';
    try {
        const res = await fetch(URL_BASE + 'listar_rec_aptos.php?locales_de=' + EDIFICIO_ID);
        const data = await res.json();
        if (data.ok && Array.isArray(data.locales)) {
            data.locales.forEach(lc => {
                lc.es_local = 1;               // marca para pintar en modo local
                pintarApartamento(lc, lista);
            });
        }
    } catch (e) { /* si falla, se reintenta al reabrir el paso */ }
}

function mostrarPisoSeleccionado() {
    const pisoId = document.getElementById('selector-piso').value;
    document.querySelectorAll('.piso-panel').forEach(p => p.classList.add('hidden'));
    if (!pisoId) return;
    const panel = document.getElementById('piso-panel-' + pisoId);
    if (!panel) return;
    panel.classList.remove('hidden');
    // Cargar apartamentos si aún no se han cargado.
    if (!panel.dataset.cargado) {
        panel.dataset.cargado = '1';
        cargarAptosDelPiso(panel);
    }
}

async function cargarAptosDelPiso(card) {
    const pisoId = parseInt(card.dataset.piso);
    const lista = card.querySelector('.apto-lista');
    const numeroPiso = parseInt(card.dataset.numeroPiso || '0');

    // Sin señal se generan aquí mismo: pedirlos al servidor fallaría
    // y el piso quedaría vacío sin poder seguir.
    if (!navigator.onLine) {
        generarAptosLocales(card, pisoId, numeroPiso, APTOS_POR_PISO);
        return;
    }

    try {
        const res = await fetch(URL_BASE + 'listar_rec_aptos.php?piso_id=' + pisoId);
        const data = await res.json();

        if (data.ok && data.apartamentos && data.apartamentos.length) {
            lista.innerHTML = '';
            data.apartamentos.forEach(a => pintarApartamento(a, lista));
        } else {
            // No hay apartamentos: generarlos según el paso 1.
            if (APTOS_POR_PISO > 0) {
                generarAptosAuto(card, pisoId, numeroPiso, APTOS_POR_PISO);
            }
        }
    } catch (e) {
        // Se cayó la señal: se generan en el teléfono.
        generarAptosLocales(card, pisoId, numeroPiso, APTOS_POR_PISO);
    }
}

/**
 * Crea los apartamentos de un piso en el teléfono, sin servidor.
 *
 * Usa ids negativos para no chocar con los reales, y los deja listos
 * para llenar: al recuperar señal se envían con el resto.
 */
function generarAptosLocales(card, pisoId, numeroPiso, cantidad) {
    const lista = card.querySelector('.apto-lista');
    if (!lista) return;

    const n = parseInt(cantidad) || 0;
    if (n < 1) {
        lista.innerHTML = '<div style="font-size:12.5px;color:#8a6d1a;padding:8px 0;">'
            + 'No se indicó cuántos apartamentos tiene cada piso. '
            + 'Vuelva al paso 1 y complete ese dato.</div>';
        return;
    }

    // Si ya se generaron antes, se reutilizan: no se duplican.
    let guardados = null;
    try {
        guardados = JSON.parse(localStorage.getItem('aptos_piso_' + pisoId) || 'null');
    } catch (e) { guardados = null; }

    let aptos;
    if (guardados && Array.isArray(guardados.apartamentos)
        && guardados.apartamentos.length === n) {
        aptos = guardados.apartamentos;
    } else {
        aptos = [];
        for (let i = 1; i <= n; i++) {
            aptos.push({
                // Negativo y único: piso × 100 + número de apartamento.
                id: -(Math.abs(pisoId) * 100 + i),
                identificador: (numeroPiso || 1) + '-' + String.fromCharCode(64 + i),
                piso_id: pisoId,
                jefe_nombre: '', jefe_cedula: '', jefe_telefono: '',
                num_habitaciones: 0, num_salas: 0, num_banos: 0,
                num_cocinas: 0, num_balcones: 0,
                ambientes: [], local: true,
            });
        }
        try {
            localStorage.setItem('aptos_piso_' + pisoId,
                JSON.stringify({ piso_id: pisoId, apartamentos: aptos }));
        } catch (e) { /* sin espacio: seguir igual */ }
    }

    lista.innerHTML = '<div style="background:#fffbf0;border:1px solid #C9A22755;'
        + 'border-radius:8px;padding:9px 12px;margin-bottom:10px;font-size:12.5px;'
        + 'color:#8a6d1a;"><i class="bi bi-phone-fill"></i> '
        + 'Estos apartamentos se crearon en su teléfono. Llénelos con normalidad: '
        + 'todo se enviará al recuperar la señal.</div>';

    aptos.forEach(a => pintarApartamento(a, lista));
}

async function generarAptosAuto(card, pisoId, numeroPiso, cantidad) {
    // Sin señal se generan en el teléfono.
    if (!navigator.onLine) {
        generarAptosLocales(card, pisoId, numeroPiso, cantidad);
        return;
    }

    try {
        const res = await fetch(URL_BASE + 'guardar_rec_apto.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ accion:'generar', piso_id: pisoId,
                                   cantidad, numero_piso: numeroPiso }),
            credentials: 'same-origin'
        });
        const data = await res.json();

        if (data.ok && data.apartamentos) {
            const lista = card.querySelector('.apto-lista');
            lista.innerHTML = '';
            data.apartamentos.forEach(a => pintarApartamento(a, lista));
        } else {
            // El servidor no los creó: se generan en el teléfono para
            // no dejar al técnico sin poder trabajar.
            generarAptosLocales(card, pisoId, numeroPiso, cantidad);
        }
    } catch (e) {
        generarAptosLocales(card, pisoId, numeroPiso, cantidad);
    }
}

// Al cambiar el "Estado del elemento": habilita la foto y guarda reactivamente.
function onEstadoElemento(sel, pisoId) {
    const row = sel.closest('.elem-row');
    const btnFoto = row.querySelector('.btn-foto-elem');
    const chkRep = row.querySelector('.el-reparar');
    if (sel.value === '') {
        btnFoto.disabled = true;
    } else {
        btnFoto.disabled = false;
        // Si el estado requiere acción, marcar reparación por defecto.
        if (sel.value === 'Requiere reparación' || sel.value === 'No funciona') {
            chkRep.checked = true;
        }
    }
    mostrarCajaElemento(row);
    guardarPisoReactivo(pisoId);
}

/** Muestra u oculta la caja de trabajo según la casilla de reparación. */
function mostrarCajaElemento(row) {
    const chk = row.querySelector('.el-reparar');
    const caja = row.querySelector('.el-trabajo-caja');
    if (caja) caja.style.display = (chk && chk.checked) ? 'flex' : 'none';
}

/** Llena los selectores de trabajo de los elementos del piso. */
function llenarTrabajosElementos() {
    // Si el catálogo no cargó (falta el SQL), no hacer nada: el resto
    // de la pantalla debe seguir funcionando.
    if (typeof TIPOS_TRABAJO === 'undefined' || !Array.isArray(TIPOS_TRABAJO)) return;
    document.querySelectorAll('.el-trabajo').forEach(sel => {
        if (sel.dataset.lleno) return;
        sel.dataset.lleno = '1';
        const actual = sel.dataset.valor || '';
        sel.innerHTML = '<option value="">— ¿Qué trabajo? —</option>'
            + TIPOS_TRABAJO.map(t =>
                '<option value="' + t.clave + '"' + (t.clave === actual ? ' selected' : '') + '>'
                + t.nombre + '</option>').join('');
    });
    // Mostrar la caja en los que ya vienen marcados.
    document.querySelectorAll('.elem-row').forEach(mostrarCajaElemento);
}

// El script está al final de la página, así que el DOM ya está listo.
// Usar DOMContentLoaded aquí no dispararía nunca.
try { llenarTrabajosElementos(); } catch (e) { /* no interrumpir el resto */ }

// Si la página abre directamente en el paso 3, cargar el resumen:
// antes solo se cargaba al cambiar de paso.
try {
    const tab3 = document.getElementById('tab-3');
    if (tab3 && tab3.classList.contains('activo')) cargarResumen();
} catch (e) { /* nada */ }

// Al marcar o desmarcar reparación, mostrar u ocultar la caja.
document.addEventListener('change', function (e) {
    if (e.target && e.target.classList.contains('el-reparar')) {
        const row = e.target.closest('.elem-row');
        if (row) mostrarCajaElemento(row);
    }
});

// Guardado reactivo del piso (reemplaza el botón "Guardar elementos del piso").
let _guardarPisoTimer = {};
function guardarPisoReactivo(pisoId) {
    // Debounce: espera 600ms sin cambios antes de guardar.
    clearTimeout(_guardarPisoTimer[pisoId]);
    _guardarPisoTimer[pisoId] = setTimeout(() => guardarPisoAhora(pisoId), 600);
}

async function guardarPisoAhora(pisoId) {
    const card = document.getElementById('piso-panel-' + pisoId);
    if (!card) return;
    const elementos = [];
    card.querySelectorAll('.elem-row').forEach(row => {
        const selT = row.querySelector('.el-trabajo');
        const inpM = row.querySelector('.el-m2');
        elementos.push({
            tipo: row.dataset.tipo,
            presente: row.querySelector('.el-estado').value !== '' ? 1 : 0,
            estado: row.querySelector('.el-estado').value,
            necesita_reparacion: row.querySelector('.el-reparar').checked ? 1 : 0,
            tipo_trabajo: selT ? selT.value : '',
            metros_cuadrados: inpM ? aNumero(inpM.value) : 0,
        });
    });
    const payload = {
        piso_id: pisoId,
        tiene_areas_comunes: card.querySelector('.piso-areas').checked ? 1 : 0,
        areas_comunes_desc: card.querySelector('.piso-areas-desc').value,
        elementos,
    };
    const res = await fetch(URL_BASE + 'guardar_rec_piso.php', {
        method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.ok && data.elementos) {
        card.querySelectorAll('.elem-row').forEach(row => {
            const id = data.elementos[row.dataset.tipo];
            if (id) row.dataset.elemId = id;
        });
    }
}

// ================= APARTAMENTOS (dentro de cada piso) =================
// Regenera los apartamentos de un piso con la cantidad indicada.
// Si se reduce, el servidor elimina los sobrantes con sus datos.
async function regenerarAptos(btn, pisoId, numeroPiso) {
    const card = document.getElementById('piso-panel-' + pisoId);
    if (!card) return;
    const input = card.querySelector('.apto-cantidad');
    const msg = card.querySelector('.apto-msg');
    const cantidad = parseInt(input.value) || 0;

    if (cantidad < 1 || cantidad > 100) {
        msg.textContent = 'Indique entre 1 y 100.';
        msg.style.color = '#A61C1C';
        return;
    }

    // Si va a eliminar apartamentos, pedir confirmación explícita.
    const actuales = card.querySelectorAll('.apto-lista .apto-card').length;
    if (actuales > 0 && cantidad < actuales) {
        const van = actuales - cantidad;
        const ok = confirm('Se eliminarán ' + van + ' apartamento(s) con sus ambientes, '
            + 'avances y fotos.\n\nEsta acción no se puede deshacer. ¿Continuar?');
        if (!ok) { input.value = actuales; return; }
    }

    btn.disabled = true;
    msg.textContent = 'Regenerando…';
    msg.style.color = '#5b6478';

    try {
        const res = await fetch(URL_BASE + 'guardar_rec_apto.php', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ accion:'generar', piso_id: pisoId,
                                   cantidad: cantidad, numero_piso: numeroPiso })
        });
        const data = await res.json();
        if (data.sesion_expirada) { alert(data.mensaje); return; }
        if (!data.ok) {
            msg.textContent = data.mensaje || 'No se pudo regenerar.';
            msg.style.color = '#A61C1C';
            return;
        }
        const lista = card.querySelector('.apto-lista');
        lista.innerHTML = '';
        (data.apartamentos || []).forEach(a => pintarApartamento(a, lista));
        const actual = card.querySelector('.apto-actual');
        if (actual) actual.textContent = (data.apartamentos || []).length;
        msg.textContent = '✓ ' + (data.apartamentos || []).length + ' apartamento(s)';
        msg.style.color = '#2E7D32';
        setTimeout(() => { msg.textContent = ''; }, 3000);
    } catch (e) {
        msg.textContent = 'Sin conexión. Intente de nuevo.';
        msg.style.color = '#A61C1C';
    } finally {
        btn.disabled = false;
    }
}

function pintarApartamento(a, lista) {
    // Al final de esta función se reaplica el modo consulta, porque los
    // campos nuevos nacen habilitados.
    const card = document.createElement('div');
    card.className = 'apto-card';
    // Datos para poder saltar directo a este apartamento cuando el
    // cierre reporta que le falta algo.
    if (a.id) card.dataset.aptoId = a.id;
    card.dataset.ident = a.identificador || '';
    card.innerHTML = `
        <div class="apto-head" onclick="abrirApto(this)">
            <i class="bi ${a.es_local ? 'bi-shop' : 'bi-door-open'}"></i> ${a.es_local ? 'Local ' + escHtml(a.identificador) : (ES_CASA ? 'Nivel ' + escHtml(a.identificador) : 'Apartamento ' + escHtml(a.identificador))}
        </div>
        <div class="apto-body hidden">
            <!-- Primero: ¿se puede hacer el levantamiento? -->
            <div style="background:#fffbf0;border:1px solid #C9A22755;border-radius:9px;
                        padding:12px 14px;margin-bottom:14px;">
                <div class="text-sm" style="color:#8a6d1a;font-weight:600;margin-bottom:9px;">
                    <i class="bi bi-question-circle-fill"></i>
                    ¿Se puede hacer el levantamiento en este apartamento?
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <button type="button" class="btn btn-outline btn-sm"
                            style="border-color:#A61C1C55;color:#A61C1C;"
                            onclick="marcarVisita(${a.id}, 'permiso_denegado', this)">
                        <i class="bi bi-x-octagon"></i> No dejó entrar
                    </button>
                    <button type="button" class="btn btn-outline btn-sm"
                            style="border-color:#97a0b855;color:#5b6478;"
                            onclick="marcarVisita(${a.id}, 'no_esta', this)">
                        <i class="bi bi-door-closed"></i> Ocupante no se encuentra
                    </button>
                    <button type="button" class="btn btn-outline btn-sm"
                            style="border-color:#2d448855;color:#2d4488;"
                            onclick="marcarVisita(${a.id}, 'cuenta_propia', this)">
                        <i class="bi bi-tools"></i> Reparación por cuenta propia
                    </button>
                    <button type="button" class="btn btn-outline btn-sm"
                            style="border-color:#2E7D3255;color:#2E7D32;"
                            onclick="marcarVisita(${a.id}, 'sin_dano', this)">
                        <i class="bi bi-check-circle"></i> Inspeccionado · sin daño
                    </button>
                </div>
                <div class="text-sm" style="color:#8a6d1a;margin-top:8px;font-size:11.5px;">
                    Si marca alguna, se pasa directo al siguiente apartamento.
                    Si sí se puede, continúe con los datos de abajo.
                </div>
            </div>

            <!-- Datos del jefe de familia (obligatorios) -->
            <?php // En casas se piden una sola vez, en el primer nivel. ?>
            <div class="bloque-jefe" style="background:#f7f9fd;border-radius:9px;padding:12px 14px;margin-bottom:14px;">
                <div class="bloque-tit" style="margin:0 0 10px;"><i class="bi bi-person-vcard"></i> ${a.es_local ? 'Responsable del local' : 'Jefe de familia'}</div>
                <div style="display:flex;gap:10px;flex-wrap:wrap;">
                    <div class="field jefe-field" style="flex:2;min-width:180px;">
                        <label class="text-sm">Nombre completo *</label>
                        <input type="text" class="form-control jefe-nombre" onchange="guardarJefe(${a.id}, this)" value="${escHtml(a.jefe_nombre||'')}" placeholder="Nombre y apellido">
                    </div>
                    <div class="field jefe-field" style="flex:1;min-width:120px;">
                        <label class="text-sm">Cédula *</label>
                        <input type="text" class="form-control jefe-cedula" onchange="guardarJefe(${a.id}, this)" value="${escHtml(a.jefe_cedula||'')}" placeholder="V-12345678" inputmode="numeric">
                    </div>
                    <div class="field jefe-field" style="flex:1;min-width:120px;">
                        <label class="text-sm">Teléfono *</label>
                        <input type="tel" class="form-control jefe-telefono" onchange="guardarJefe(${a.id}, this)" value="${escHtml(a.jefe_telefono||'')}" placeholder="0412-1234567" inputmode="tel">
                    </div>
                </div>
            </div>
            <!-- Cantidad de ambientes -->
            <div class="bloque-tit" style="margin:0 0 8px;"><i class="bi bi-grid-3x3-gap"></i> ${a.es_local ? 'Ambientes del local' : 'Ambientes del apartamento'}</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;">
                ${(a.es_local
                    ? [['venta','Área de venta'],['deposito','Depósitos'],['banoslocal','Baños']]
                    : [['habitaciones','Habitaciones'],['salas','Salas'],['banos','Baños'],['cocinas','Cocinas'],['balcones','Balcones']]
                  ).map(([t,lbl]) => `
                    <div class="field" style="width:110px;">
                        <label class="text-sm">${lbl}</label>
                        <input type="number" min="0" max="30" class="form-control amb-${t}" value="${a['num_'+t]||0}">
                    </div>`).join('')}
                <button type="button" class="btn btn-primary btn-sm" onclick="guardarApto(this, ${a.id})">
                    <i class="bi bi-check-lg"></i> Generar ambientes
                </button>
            </div>


            <div class="amb-lista" style="margin-top:14px;"></div>
        </div>`;
    lista.appendChild(card);

    // Autoguardado local mientras escribe + recuperar lo pendiente.
    const cuerpo = card.querySelector('.apto-body');
    if (cuerpo) {
        cuerpo.querySelectorAll('input').forEach(inp => {
            inp.addEventListener('input', () => autoguardarApto(a.id, cuerpo));
        });
        // Si quedó algo escrito sin guardar, se recupera.
        const b = leerBorrador(a.id);
        if (b && b.datos && !a.jefe_nombre) restaurarBorrador(a.id, cuerpo);
    }
    // Si hay ambientes guardados en el teléfono (aún sin subir), se muestran
    // esos: son los que el técnico ve y puede fotografiar.
    const locales = leerAmbientesLocales(a.id);
    if (locales && locales.ambientes && locales.ambientes.length) {
        const cuerpoAp = card.querySelector('.apto-body');
        pintarAmbientesLocales(cuerpoAp, {
            num_habitaciones: a.num_habitaciones, num_salas: a.num_salas,
            num_banos: a.num_banos, num_cocinas: a.num_cocinas,
            num_balcones: a.num_balcones,
        }, a.id);
        marcarAptoPendiente(cuerpoAp, 'Guardado en el teléfono');
    } else {
        // Siempre se intenta cargar lo ya guardado: puede haber ambientes
        // con fotos aunque las cantidades del formulario estén en cero.
        // Sin esto, quien vuelve a cargar fotos tenía que crear todo de nuevo.
        cargarAmbientes(a.id, card.querySelector('.amb-lista'));
    }

    try { aplicarSoloLectura(); } catch (e) { /* seguir */ }
    try { ajustarCasaJefeFamilia(); } catch (e) { /* seguir */ }

    // Al recargar, mostrar el apartamento cerrado y con su estado a la
    // vista (completo, con pendientes, o motivo de visita). Así, en un
    // edificio de muchos pisos, se ve de un vistazo qué falta sin abrir
    // uno por uno. Solo aplica cuando el servidor mandó ese estado.
    if (a._estado && a._estado.estado && a._estado.estado !== 'vacio') {
        try { aplicarEstadoApto(card, a); } catch (e) { /* seguir */ }
    }
}

/**
 * Pinta la cabecera de un apartamento ya trabajado con su estado.
 *
 *  - COMPLETO: se cierra y, al abrirlo, se ve en modo lectura (los
 *    campos quedan como información fija, no como formulario). El botón
 *    "Editar" lo vuelve editable.
 *  - INCOMPLETO: se deja abierto y se lista lo que falta, para que no
 *    haya que llegar al cierre para enterarse.
 *  - VISITA: lo maneja pintarAptoMarcado; aquí no se toca.
 *
 * Nunca borra el contenido: solo cambia cómo se ve.
 */
function aplicarEstadoApto(card, a) {
    const est = a._estado || {};
    const cab = card.querySelector('.apto-head');
    const cuerpo = card.querySelector('.apto-body');
    if (!cab) return;

    // Los apartamentos con motivo de visita ya se pintan aparte.
    if (est.estado === 'visita') return;

    // Colores y textos según el estado.
    let color, icono, texto;
    if (est.estado === 'incompleto') {
        color = '#C9A227'; icono = 'bi-exclamation-triangle-fill';
        texto = 'Falta completar';
    } else { // completo
        color = '#2E7D32'; icono = 'bi-check-circle-fill';
        texto = 'Completo';
    }

    // Marca en la cabecera (si no la tiene ya).
    const marcaVieja = cab.querySelector('.apto-marca');
    if (marcaVieja) marcaVieja.remove();
    cab.insertAdjacentHTML('beforeend',
        '<span class="apto-marca" style="float:right;font-size:11.5px;font-weight:600;'
        + 'color:' + color + ';background:' + color + '18;border-radius:20px;'
        + 'padding:2px 10px;"><i class="bi ' + icono + '"></i> ' + escHtml(texto) + '</span>');

    // Quitar restos de un estado anterior.
    const faltanViejo = card.querySelector('.apto-faltan');
    if (faltanViejo) faltanViejo.remove();
    const editarViejo = card.querySelector('.apto-editar');
    if (editarViejo) editarViejo.remove();

    if (est.estado === 'incompleto') {
        // Se deja ABIERTO y editable, con la lista de lo que falta arriba.
        if (cuerpo) cuerpo.classList.remove('apto-lectura', 'hidden');
        if (Array.isArray(est.faltan) && est.faltan.length) {
            const items = est.faltan.map(f => '<li>' + escHtml(f) + '</li>').join('');
            cab.insertAdjacentHTML('afterend',
                '<div class="apto-faltan" style="background:#fffbf0;border:1px solid #C9A22755;'
                + 'padding:9px 13px;font-size:12px;color:#8a6d1a;">'
                + '<b><i class="bi bi-exclamation-triangle"></i> Le falta:</b>'
                + '<ul style="margin:5px 0 0;padding-left:20px;">' + items + '</ul></div>');
        }
        return;
    }

    // --- COMPLETO: cerrar y dejar en modo lectura ---
    if (cuerpo) {
        cuerpo.classList.add('hidden');
        activarModoLectura(cuerpo);
    }

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-outline btn-sm apto-editar';
    btn.style.cssText = 'margin:8px 13px 12px;';
    btn.innerHTML = '<i class="bi bi-pencil"></i> Editar';
    btn.onclick = function () {
        const cuerpoAp = card.querySelector('.apto-body');
        if (cuerpoAp) {
            cuerpoAp.classList.remove('hidden');
            desactivarModoLectura(cuerpoAp);
            cuerpoAp.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        const marca = cab.querySelector('.apto-marca');
        if (marca) marca.remove();
        btn.remove();
    };
    card.appendChild(btn);
}

/** Pone el cuerpo de un apartamento en modo lectura (campos fijos). */
function activarModoLectura(cuerpo) {
    if (!cuerpo || cuerpo.classList.contains('apto-lectura')) return;
    cuerpo.classList.add('apto-lectura');
    // Un aviso claro de que está en modo lectura.
    if (!cuerpo.querySelector('.apto-lectura-aviso')) {
        const av = document.createElement('div');
        av.className = 'apto-lectura-aviso';
        av.innerHTML = '<i class="bi bi-check-circle-fill"></i> '
            + 'Apartamento completo. Toque <b>Editar</b> para cambiar algo.';
        cuerpo.insertBefore(av, cuerpo.firstChild);
    }
    // Bloquear los campos para que se vean como información, no formulario.
    cuerpo.querySelectorAll('input, select, textarea').forEach(el => {
        el.dataset.eraEditable = '1';
        el.setAttribute('readonly', 'readonly');
        el.setAttribute('tabindex', '-1');
    });
}

/** Devuelve el cuerpo a modo edición normal. */
function desactivarModoLectura(cuerpo) {
    if (!cuerpo) return;
    cuerpo.classList.remove('apto-lectura');
    const av = cuerpo.querySelector('.apto-lectura-aviso');
    if (av) av.remove();
    cuerpo.querySelectorAll('input, select, textarea').forEach(el => {
        el.removeAttribute('readonly');
        el.removeAttribute('tabindex');
        delete el.dataset.eraEditable;
    });
}

/**
 * Tras guardar un apartamento, se pide su estado al servidor y se
 * colapsa mostrando la marca y lo que le falte (si algo). Así el
 * técnico ve de una vez si quedó completo, sin llegar al cierre.
 */
async function colapsarAptoTrasGuardar(card, aptoId) {
    if (!card || !aptoId || aptoId < 0) return;
    try {
        const res = await fetch(URL_BASE + 'listar_rec_aptos.php?estado_de=' + aptoId,
                                { credentials: 'same-origin' });
        const d = await res.json();
        if (!d || !d.ok || !d.estado) return;
        // Solo se cierra en modo lectura si quedó COMPLETO. Si le falta
        // algo, se deja abierto mostrando qué falta, para completarlo ya.
        aplicarEstadoApto(card, { _estado: d.estado, id: aptoId });
    } catch (e) { /* si falla, se deja abierto: no estorba */ }
}

/**
 * Marca el resultado de la visita a un apartamento que no se pudo
 * levantar (no estaba, no dejaron entrar, repara por su cuenta, etc.).
 * No pide datos del jefe de familia: no tendría sentido.
 */
async function marcarVisita(aptoId, estado, btn) {
    const textos = {
        sin_dano:          '¿Confirma que revisó el apartamento y NO TIENE DAÑOS?',
        cuenta_propia:     '¿Confirma que la familia REPARA POR CUENTA PROPIA?',
        no_esta:           '¿Confirma que EL OCUPANTE NO SE ENCUENTRA?',
        permiso_denegado:  '¿Confirma que NO DEJARON ENTRAR?',
    };
    if (!confirm(textos[estado] || '¿Confirma?')) return;

    const ejemplos = {
        sin_dano:         'Ej: se revisaron todos los ambientes, sin grietas',
        no_esta:          'Ej: se visitó dos veces, sin respuesta',
        permiso_denegado: 'Ej: el ocupante no permitió el ingreso',
        cuenta_propia:    'Ej: la familia ya contrató a un albañil',
    };
    const obs = prompt('Nota (opcional):\n\n' + (ejemplos[estado] || ''), '');
    if (obs === null) return;   // canceló

    const card = btn.closest('.apto-card');
    const cuerpo = btn.closest('.apto-body');
    btn.disabled = true;

    const payload = { accion:'marcar_visita', apartamento_id: aptoId,
                      estado: estado, observacion: obs };

    // Sin señal: queda en cola.
    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
            'Apartamento ' + aptoId + ' · ' + estado);
        pintarAptoMarcado(card, cuerpo, estado, obs);
        saltarAlSiguiente(card);
        return;
    }

    try {
        const res = await fetch(URL_BASE + 'guardar_rec_apto.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials:'same-origin'
        });
        const d = await res.json();
        if (!d.ok) { alert(d.mensaje || 'No se pudo guardar.'); btn.disabled = false; return; }
        pintarAptoMarcado(card, cuerpo, estado, obs);
        saltarAlSiguiente(card);
    } catch (e) {
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
                'Apartamento ' + aptoId + ' · ' + estado);
            pintarAptoMarcado(card, cuerpo, estado, obs);
            saltarAlSiguiente(card);
        } else {
            alert('Sin conexión. Intente de nuevo.');
            btn.disabled = false;
        }
    }
}

/** Deja el apartamento marcado visualmente y cierra su detalle. */
function pintarAptoMarcado(card, cuerpo, estado, obs) {
    // El apartamento quedó atendido: actualizar la barra de avance.
    refrescarProgreso();
    const estilos = {
        sin_dano:         { color: '#2E7D32', icono: 'bi-check-circle-fill',
                            texto: 'Inspeccionado · sin daño' },
        cuenta_propia:    { color: '#2d4488', icono: 'bi-tools',
                            texto: 'Repara por cuenta propia' },
        no_esta:          { color: '#5b6478', icono: 'bi-door-closed-fill',
                            texto: 'Ocupante no se encuentra' },
        permiso_denegado: { color: '#A61C1C', icono: 'bi-x-octagon-fill',
                            texto: 'No dejó entrar' },
    };
    const e = estilos[estado] || estilos.no_esta;
    const color = e.color, icono = e.icono, texto = e.texto;

    const cab = card.querySelector('.apto-head');
    if (cab && !cab.querySelector('.apto-marca')) {
        cab.insertAdjacentHTML('beforeend',
            '<span class="apto-marca" style="float:right;font-size:11.5px;font-weight:600;'
            + 'color:' + color + ';background:' + color + '18;border-radius:20px;'
            + 'padding:2px 10px;"><i class="bi ' + icono + '"></i> ' + texto + '</span>');
    }

    if (cuerpo) {
        cuerpo.classList.add('apto-marcado');   // ya resuelto: no se valida
        cuerpo.innerHTML = '<div style="background:' + color + '10;border:1px solid '
            + color + '44;border-radius:9px;padding:13px 15px;">'
            + '<div style="font-weight:700;color:' + color + ';font-size:14px;">'
            + '<i class="bi ' + icono + '"></i> ' + texto + '</div>'
            + (obs ? '<div style="font-size:12.5px;color:#5b6478;margin-top:5px;">' + obs + '</div>' : '')
            + '<button type="button" class="btn btn-outline btn-sm" style="margin-top:9px;"'
            + ' onclick="location.reload()">'
            + '<i class="bi bi-arrow-counterclockwise"></i> Corregir</button></div>';
        cuerpo.classList.add('hidden');
    }
}

/** Abre el siguiente apartamento del piso, para no perder el hilo. */
function saltarAlSiguiente(card) {
    const siguiente = card.nextElementSibling;
    if (!siguiente || !siguiente.classList.contains('apto-card')) {
        // Era el último: avisar y quedarse donde está.
        const msg = document.createElement('div');
        msg.style.cssText = 'background:#eef7f0;border-radius:8px;padding:10px 13px;'
            + 'margin-top:9px;font-size:13px;color:#2E7D32;font-weight:600;';
        msg.innerHTML = '<i class="bi bi-check-circle-fill"></i> '
            + 'Terminó los apartamentos de este piso.';
        card.parentNode.appendChild(msg);
        setTimeout(() => msg.remove(), 5000);
        return;
    }

    const cuerpo = siguiente.querySelector('.apto-body');
    if (cuerpo) cuerpo.classList.remove('hidden');
    siguiente.scrollIntoView({ behavior: 'smooth', block: 'start' });

    // Poner el cursor en el primer campo, listo para escribir.
    setTimeout(() => {
        const primero = siguiente.querySelector('.jefe-nombre');
        if (primero) primero.focus();
    }, 400);
}

async function guardarApto(btn, aptoId) {
    const cont = btn.closest('.apto-body');
    // Validar que los datos del jefe de familia estén completos (obligatorios).
    const nombre = cont.querySelector('.jefe-nombre').value.trim();
    const cedula = cont.querySelector('.jefe-cedula').value.trim();
    const telefono = cont.querySelector('.jefe-telefono').value.trim();
    if (!nombre || !cedula || !telefono) {
        const quien = cont.querySelector('.amb-venta') ? 'del responsable del local' : 'del jefe de familia';
        alert('Complete los datos ' + quien + ' (nombre, cédula y teléfono) antes de continuar.');
        return;
    }

    // Los ambientes marcados como "necesita reparación" deben tener metros
    // cuadrados: sin ese dato no se pueden calcular los materiales.
    const sinMetros = [];
    const sinTrabajo = [];
    const sinFoto = [];
    cont.querySelectorAll('.amb-row').forEach(row => {
        const chk = row.querySelector('.amb-reparar');
        if (!chk || !chk.checked) {
            marcarAmbienteSinMetros(row, false);
            marcarAmbienteSinFoto(row, false);
            return;
        }

        const nom = row.querySelector('.amb-nom');
        const etiqueta = nom ? nom.textContent.trim() : 'un ambiente';

        // El tipo de trabajo define qué materiales se piden: es obligatorio.
        const selT = row.querySelector('.amb-trabajo');
        if (selT && !selT.value) {
            sinTrabajo.push(etiqueta);
            selT.style.border = '2px solid #A61C1C';
        } else if (selT) {
            selT.style.border = '';
        }

        const falta = !ambienteTieneMetros(row);
        marcarAmbienteSinMetros(row, falta);
        if (falta) sinMetros.push(etiqueta);

        // Un ambiente a reparar necesita foto: es la evidencia del daño.
        const nFotos = row.querySelectorAll('.amb-fotos img').length;
        const faltaFoto = nFotos === 0;
        marcarAmbienteSinFoto(row, faltaFoto);
        if (faltaFoto) sinFoto.push(etiqueta);
    });

    // Un solo aviso con todo lo que falta: tres alertas seguidas
    // interrumpen demasiado el trabajo en campo.
    if (sinTrabajo.length || sinMetros.length || sinFoto.length) {
        let msg = 'Falta completar estos ambientes:\n';
        if (sinTrabajo.length) msg += '\nQué trabajo hacer:\n· ' + sinTrabajo.join('\n· ');
        if (sinMetros.length)  msg += '\nMetros cuadrados:\n· ' + sinMetros.join('\n· ');
        if (sinFoto.length)    msg += '\nFoto del daño:\n· ' + sinFoto.join('\n· ');
        alert(msg);

        // Llevar al primer campo que falta.
        const primero = cont.querySelector('.amb-trabajo[style*="2px solid"]')
                     || cont.querySelector('.amb-reparacion[style*="2px solid"]')
                     || cont.querySelector('.amb-fotos[style*="2px dashed"]');
        if (primero) primero.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }

    // Un local comercial tiene otros campos de conteo. Se detecta por la
    // presencia del contenedor de venta.
    const esLocal = !!cont.querySelector('.amb-venta');
    const numDe = sel => { const el = cont.querySelector(sel); return el ? el.value : ''; };

    const payload = esLocal ? {
        accion:'guardar_apto', apartamento_id: aptoId,
        jefe_nombre: nombre, jefe_cedula: cedula, jefe_telefono: telefono,
        nombre_local: (cont.querySelector('.nombre-local')?.value || '').trim(),
        num_venta:      numDe('.amb-venta'),
        num_deposito:   numDe('.amb-deposito'),
        num_banoslocal: numDe('.amb-banoslocal'),
    } : {
        accion:'guardar_apto', apartamento_id: aptoId,
        jefe_nombre: nombre, jefe_cedula: cedula, jefe_telefono: telefono,
        num_habitaciones: cont.querySelector('.amb-habitaciones').value,
        num_salas:        cont.querySelector('.amb-salas').value,
        num_banos:        cont.querySelector('.amb-banos').value,
        num_cocinas:      cont.querySelector('.amb-cocinas').value,
        num_balcones:     cont.querySelector('.amb-balcones').value,
    };
    // Datos para poder reconstruir este apartamento en el servidor si se
    // creó sin señal (id negativo). El id temporal por sí solo no basta.
    const cardEl = btn.closest('.apto-card');
    const panelEl = cardEl ? cardEl.closest('.piso-panel') : null;
    const localesPanel = cardEl ? cardEl.closest('#locales-lista') : null;
    payload.identificador = cardEl ? (cardEl.dataset.ident || '') : '';
    payload.piso_id = panelEl ? parseInt(panelEl.dataset.piso) || 0 : 0;
    payload.es_local = (esLocal || localesPanel) ? 1 : 0;
    // Un local vive en la planta baja: si no hay panel de piso, se resuelve
    // en el servidor con el piso de menor número del edificio.
    payload.edificio_id = (typeof EDIFICIO_ID !== 'undefined') ? EDIFICIO_ID : 0;

    // Guardar copia local ANTES de enviar: si se cae la señal, no se pierde.
    guardarBorrador(aptoId, payload);

    // Apartamento creado sin conexión (id negativo): todavía no existe en el
    // servidor. Se guarda en la estructura local y se enviará al sincronizar.
    if (aptoId < 0) {
        guardarAptoLocal(aptoId, payload);
        // Hay que generar los ambientes antes de pintarlos, y pasar el
        // id: sin él la función no encuentra lo guardado y la lista
        // sale vacía.
        guardarAmbientesLocales(aptoId, payload);
        pintarAmbientesLocales(cont, payload, aptoId);

        // Se encola para que suba al recuperar señal. La clave evita
        // que se acumulen varios envíos del mismo apartamento.
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php',
                Object.assign({}, payload, { apartamento_local: true }),
                'Apartamento ' + (payload.identificador || aptoId),
                'apto_' + aptoId);
        }

        marcarAptoPendiente(cont, 'Guardado en el teléfono');
        return;
    }

    // Sin señal: queda en cola y se sube después.
    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
            'Apartamento ' + aptoId + ' · ' + nombre);
        // Guardar también la estructura del apartamento, para poder seguir
        // trabajando en él (ver los ambientes, tomar fotos) sin señal.
        guardarAmbientesLocales(aptoId, payload);
        pintarAmbientesLocales(cont, payload, aptoId);
        marcarAptoPendiente(cont, 'Guardado en el teléfono');
        return;
    }

    try {
        const res = await fetch(URL_BASE + 'guardar_rec_apto.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials: 'same-origin'
        });
        const texto = await res.text();
        let data;
        try { data = JSON.parse(texto); }
        catch (e) {
            // El servidor respondió HTML (sesión caída o error): no perder nada.
            if (window.ObrasOffline) {
                await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
                    'Apartamento ' + aptoId + ' · ' + nombre);
                guardarAmbientesLocales(aptoId, payload);
                pintarAmbientesLocales(cont, payload, aptoId);
                marcarAptoPendiente(cont, 'Guardado en el teléfono');
            } else {
                alert('El servidor respondió algo inesperado. Sus datos siguen en pantalla, intente de nuevo.');
            }
            return;
        }
        if (data.sesion_expirada) { alert(data.mensaje); return; }
        if (data.ok) {
            borrarBorrador(aptoId);
            // Ya están en el servidor: se limpia la copia local.
            try { localStorage.removeItem('ambientes_' + aptoId); } catch (e) {}
            pintarAmbientes(data.ambientes, cont.querySelector('.amb-lista'));
            marcarAptoPendiente(cont, '');
            refrescarProgreso();
            // Si el apartamento quedó completo, se cierra en modo lectura.
            // Si le falta algo, colapsarAptoTrasGuardar lo deja abierto
            // con el aviso de lo que falta.
            const tarjeta = btn.closest('.apto-card');
            if (tarjeta) colapsarAptoTrasGuardar(tarjeta, aptoId);
        } else {
            alert(data.mensaje || 'Error al guardar.');
        }
    } catch (e) {
        // Se cayó la señal a mitad: encolar en vez de perder el trabajo.
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
                'Apartamento ' + aptoId + ' · ' + nombre);
            guardarAmbientesLocales(aptoId, payload);
            pintarAmbientesLocales(cont, payload, aptoId);
            marcarAptoPendiente(cont, 'Guardado en el teléfono');
        } else {
            alert('Se perdió la conexión.\n\nSus datos siguen en pantalla. Intente guardar de nuevo cuando tenga señal.');
        }
    }
}

// Guarda lo escrito mientras el usuario llena, sin esperar a que envíe.
function autoguardarApto(aptoId, cont) {
    const v = sel => { const el = cont.querySelector(sel); return el ? el.value : ''; };
    guardarBorrador(aptoId, {
        accion:'guardar_apto', apartamento_id: aptoId,
        jefe_nombre: v('.jefe-nombre'), jefe_cedula: v('.jefe-cedula'),
        jefe_telefono: v('.jefe-telefono'),
        num_habitaciones: v('.amb-habitaciones'), num_salas: v('.amb-salas'),
        num_banos: v('.amb-banos'), num_cocinas: v('.amb-cocinas'),
        num_balcones: v('.amb-balcones'),
    });
}

// ---- Autoguardado periódico: respaldo cada 30 segundos ----
// Aunque el usuario no toque nada, lo escrito se conserva. Si se va la
// señal o se cierra el navegador, al volver está todo.
let _ultimoRespaldo = '';

function respaldarTodo() {
    try {
        const estado = { inspeccion: INSPECCION_ID, fecha: new Date().toISOString(), aptos: {} };

        // Datos de cada apartamento que esté abierto en pantalla.
        document.querySelectorAll('.apto-card').forEach(card => {
            const cuerpo = card.querySelector('.apto-body');
            if (!cuerpo) return;
            const btn = cuerpo.querySelector('button[onclick^="guardarApto"]');
            if (!btn) return;
            const m = btn.getAttribute('onclick').match(/guardarApto\(this,\s*(\d+)\)/);
            if (!m) return;
            const id = m[1];
            const v = sel => { const el = cuerpo.querySelector(sel); return el ? el.value : ''; };
            const datos = {
                jefe_nombre: v('.jefe-nombre'), jefe_cedula: v('.jefe-cedula'),
                jefe_telefono: v('.jefe-telefono'),
                num_habitaciones: v('.amb-habitaciones'), num_salas: v('.amb-salas'),
                num_banos: v('.amb-banos'), num_cocinas: v('.amb-cocinas'),
                num_balcones: v('.amb-balcones'),
            };
            // Ambientes: lo que más cuesta rehacer si se pierde.
            const ambientes = [];
            cuerpo.querySelectorAll('.amb-row').forEach(row => {
                const chk = row.querySelector('.amb-reparar');
                const selT = row.querySelector('.amb-trabajo');
                const metros = {};
                row.querySelectorAll('[data-sup]').forEach(inp => {
                    if (inp.closest('.partida-extra')) return;
                    if (inp.value && inp.value !== '0') metros[inp.dataset.sup] = inp.value;
                });

                // Trabajos adicionales del mismo ambiente.
                const extras = [];
                row.querySelectorAll('.partida-extra').forEach(bl => {
                    const st = bl.querySelector('.part-trabajo');
                    const mm = {};
                    bl.querySelectorAll('[data-sup]').forEach(inp => {
                        if (inp.value && inp.value !== '0') mm[inp.dataset.sup] = inp.value;
                    });
                    if ((st && st.value) || Object.keys(mm).length) {
                        extras.push({ trabajo: st ? st.value : '', metros: mm });
                    }
                });

                const nom = row.querySelector('.amb-nom');
                if ((chk && chk.checked) || Object.keys(metros).length || extras.length) {
                    ambientes.push({
                        amb: row.dataset.amb || '',
                        nombre: nom ? nom.textContent.trim() : '',
                        repara: chk ? chk.checked : false,
                        trabajo: selT ? selT.value : '',
                        metros: metros,
                        extras: extras,
                    });
                }
            });
            if (ambientes.length) datos.ambientes = ambientes;

            // Solo respaldar si tiene algo escrito.
            const hayAlgo = Object.keys(datos).some(k => {
                const x = datos[k];
                if (Array.isArray(x)) return x.length > 0;
                return x && x !== '0';
            });
            if (hayAlgo) estado.aptos[id] = datos;
        });

        // Áreas comunes del edificio.
        const areas = [];
        document.querySelectorAll('.area-row').forEach(row => {
            const chk = row.querySelector('.area-reparar');
            if (!chk || !chk.checked) return;
            const selT = row.querySelector('.area-trabajo');
            const m2 = row.querySelector('.area-m2');
            areas.push({
                area: row.dataset.area || '',
                trabajo: selT ? selT.value : '',
                m2: m2 ? m2.value : '',
            });
        });
        if (areas.length) estado.areas = areas;

        // Cierre, si está llenándolo.
        const form = document.getElementById('form-cierre');
        if (form) {
            const c = {};
            ['azotea','tanques'].forEach(k => {
                const sel = form.querySelector('input[name="'+k+'_estado"]:checked');
                if (sel) c[k+'_estado'] = sel.value;
                const obs = form.querySelector('input[name="'+k+'_obs"]');
                if (obs && obs.value) c[k+'_obs'] = obs.value;
            });
            if (Object.keys(c).length) estado.cierre = c;
        }

        const serial = JSON.stringify(estado);
        if (serial === _ultimoRespaldo) return;   // sin cambios, no reescribir
        try {
            localStorage.setItem('respaldo_lev_' + INSPECCION_ID, serial);
            _ultimoRespaldo = serial;
            mostrarSelloRespaldo();
            avisarAlmacenamiento(false);   // si antes falló, quitar el aviso
        } catch (err) {
            // El teléfono se quedó sin espacio. NO se puede fallar en
            // silencio: si el técnico sigue llenando creyendo que se
            // respalda, y el navegador se cierra, pierde el trabajo.
            // Se le avisa de forma visible y persistente.
            avisarAlmacenamiento(true);
        }
    } catch (e) { /* un error de lectura no debe tumbar el respaldo */ }
}

/**
 * Aviso persistente de almacenamiento lleno. Le dice al técnico que
 * sincronice para liberar espacio, porque el respaldo automático dejó
 * de funcionar y podría perder lo que siga escribiendo.
 */
function avisarAlmacenamiento(lleno) {
    let el = document.getElementById('aviso-almacenamiento');
    if (!lleno) { if (el) el.remove(); return; }
    if (el) return;   // ya está mostrado
    el = document.createElement('div');
    el.id = 'aviso-almacenamiento';
    el.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:99999;'
        + 'background:#A61C1C;color:#fff;padding:11px 14px;font-size:13px;'
        + 'font-weight:600;text-align:center;box-shadow:0 2px 10px rgba(0,0,0,.3);';
    el.innerHTML = '<i class="bi bi-exclamation-triangle-fill"></i> '
        + 'El teléfono se quedó sin espacio. Conéctese y sincronice YA para '
        + 'no perder datos. Mientras tanto, el respaldo automático está detenido.';
    document.body.appendChild(el);
}

// Sello discreto que confirma que hay respaldo local.
function mostrarSelloRespaldo() {
    let sello = document.getElementById('sello-respaldo');
    if (!sello) {
        sello = document.createElement('div');
        sello.id = 'sello-respaldo';
        sello.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:1400;'
            + 'background:#eef7f0;border:1px solid #2E7D3244;color:#2E7D32;'
            + 'border-radius:20px;padding:6px 13px;font-size:12px;font-weight:600;'
            + 'box-shadow:0 2px 8px rgba(20,30,60,.12);';
        document.body.appendChild(sello);
    }
    const h = new Date().toLocaleTimeString('es-VE', {hour:'2-digit', minute:'2-digit'});
    sello.innerHTML = '<i class="bi bi-shield-check"></i> Respaldado ' + h;
    sello.style.opacity = '1';
    clearTimeout(sello._t);
    sello._t = setTimeout(() => { sello.style.opacity = '.45'; }, 4000);
}

// Recupera el respaldo si el navegador se cerró sin guardar.
function revisarRespaldoPrevio() {
    try {
        const raw = localStorage.getItem('respaldo_lev_' + INSPECCION_ID);
        if (!raw) return;
        const est = JSON.parse(raw);
        const n = Object.keys(est.aptos || {}).length;
        if (!n) return;
        const cuando = est.fecha ? new Date(est.fecha).toLocaleString('es-VE') : '';
        const aviso = document.createElement('div');
        aviso.style.cssText = 'background:#fffbf0;border:1px solid #C9A22755;border-radius:9px;'
            + 'padding:12px 14px;margin-bottom:14px;font-size:13px;color:#8a6d1a;';
        aviso.innerHTML = '<i class="bi bi-clock-history"></i> '
            + '<strong>Hay datos sin guardar en este teléfono.</strong><br>'
            + 'Se encontró información de ' + n + ' apartamento(s), escrita el '
            + cuando + '.<br>'
            + '<button onclick="restaurarRespaldo()" class="btn btn-primary btn-sm" '
            + 'style="margin-top:8px;">'
            + '<i class="bi bi-arrow-counterclockwise"></i> Recuperar esos datos</button> '
            + '<button onclick="descartarRespaldo(this)" class="btn btn-outline btn-sm" '
            + 'style="margin-top:8px;">Descartar</button>';
        const panel = document.getElementById('paso-2');
        if (panel) panel.insertBefore(aviso, panel.firstChild);
    } catch (e) { /* nada */ }
}

/**
 * Vuelve a poner en pantalla lo que quedó guardado en el teléfono.
 * Se usa cuando la aplicación se reinició antes de que el técnico
 * alcanzara a guardar.
 */
function restaurarRespaldo() {
    let est;
    try {
        est = JSON.parse(localStorage.getItem('respaldo_lev_' + INSPECCION_ID) || 'null');
    } catch (e) { est = null; }
    if (!est || !est.aptos) { alert('No se encontró el respaldo.'); return; }

    let puestos = 0, pendientes = 0;

    Object.keys(est.aptos).forEach(id => {
        const d = est.aptos[id];
        const btn = document.querySelector('button[onclick^="guardarApto(this, ' + id + ')"]');
        const cuerpo = btn ? btn.closest('.apto-body') : null;

        // Si el apartamento no está en pantalla, se deja para después.
        if (!cuerpo) { pendientes++; return; }

        const poner = (sel, val) => {
            const el = cuerpo.querySelector(sel);
            if (el && val) { el.value = val; }
        };
        poner('.jefe-nombre', d.jefe_nombre);
        poner('.jefe-cedula', d.jefe_cedula);
        poner('.jefe-telefono', d.jefe_telefono);
        poner('.amb-habitaciones', d.num_habitaciones);
        poner('.amb-salas', d.num_salas);
        poner('.amb-banos', d.num_banos);
        poner('.amb-cocinas', d.num_cocinas);
        poner('.amb-balcones', d.num_balcones);

        // Ambientes con sus metros y trabajo.
        (d.ambientes || []).forEach(amb => {
            const row = cuerpo.querySelector('.amb-row[data-amb="' + amb.amb + '"]');
            if (!row) return;

            const chk = row.querySelector('.amb-reparar');
            if (chk && amb.repara && !chk.checked) {
                chk.checked = true;
                const bloque = row.querySelector('.amb-reparacion');
                if (bloque) bloque.style.display = 'block';
            }
            const selT = row.querySelector('.amb-trabajo');
            if (selT && amb.trabajo) { selT.value = amb.trabajo; avisoSuperficies(selT); }

            Object.keys(amb.metros || {}).forEach(sup => {
                const inp = row.querySelector('.sup-' + sup);
                if (inp) inp.value = amb.metros[sup];
            });

            // Trabajos adicionales.
            (amb.extras || []).forEach(ex => {
                const bAdd = row.querySelector('[onclick*="agregarPartida"]');
                if (!bAdd) return;
                agregarPartida(bAdd, amb.amb);
                const bloques = row.querySelectorAll('.partida-extra');
                const ultimo = bloques[bloques.length - 1];
                if (!ultimo) return;
                const st = ultimo.querySelector('.part-trabajo');
                if (st && ex.trabajo) st.value = ex.trabajo;
                Object.keys(ex.metros || {}).forEach(sup => {
                    const inp = ultimo.querySelector('[data-sup="' + sup + '"]');
                    if (inp) inp.value = ex.metros[sup];
                });
            });

            actualizarTotalM2(row);
        });

        puestos++;
    });

    // Áreas comunes.
    (est.areas || []).forEach(a => {
        const row = document.querySelector('.area-row[data-area="' + a.area + '"]');
        if (!row) return;
        const chk = row.querySelector('.area-reparar');
        if (chk && !chk.checked) {
            chk.checked = true;
            const det = row.querySelector('.area-detalle');
            if (det) det.style.display = 'block';
        }
        const selT = row.querySelector('.area-trabajo');
        if (selT && a.trabajo) selT.value = a.trabajo;
        const m2 = row.querySelector('.area-m2');
        if (m2 && a.m2) m2.value = a.m2;
    });

    let msg = 'Se recuperaron los datos de ' + puestos + ' apartamento(s).';
    if (pendientes > 0) {
        msg += '\n\nQuedan ' + pendientes + ' apartamento(s) en otros pisos: '
             + 'ábralos y vuelva a tocar "Recuperar" para completarlos.';
    }
    msg += '\n\nRevise que todo esté bien y guarde cada apartamento.';
    alert(msg);
}

/** Descarta el respaldo local tras confirmar. */
function descartarRespaldo(btn) {
    if (!confirm('¿Descartar los datos guardados en este teléfono?\n\n'
        + 'No se podrán recuperar.')) return;
    localStorage.removeItem('respaldo_lev_' + INSPECCION_ID);
    const aviso = btn.closest('div');
    if (aviso) aviso.remove();
}

/**
 * Aviso permanente cuando no hay señal, para que el técnico sepa que
 * puede seguir trabajando y que nada se pierde.
 */
function avisoSinSenal() {
    let barra = document.getElementById('aviso-sin-senal');

    if (navigator.onLine) {
        if (barra) barra.remove();
        return;
    }
    if (barra) return;

    barra = document.createElement('div');
    barra.id = 'aviso-sin-senal';
    barra.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:9998;'
        + 'background:#C9A227;color:#22366F;padding:9px 14px;font-size:13px;'
        + 'font-weight:700;text-align:center;box-shadow:0 -2px 8px rgba(0,0,0,.15);';
    barra.innerHTML = '<i class="bi bi-wifi-off"></i> '
        + 'Sin señal · Siga trabajando: todo se guarda en el teléfono '
        + 'y se envía al recuperar la conexión.';
    document.body.appendChild(barra);
}

// Áreas comunes agregadas sin señal: se vuelven a dibujar.
try { restaurarAreasLibres(); } catch (e) { /* seguir */ }

/**
 * Devuelve a la pantalla lo escrito en las áreas comunes del Paso 1.
 *
 * El borrador ya se guardaba ('paso1_' + INSPECCION_ID) pero nadie lo
 * volvía a leer: por eso, al refrescar sin haber podido enviar, el
 * técnico veía las áreas vacías y creía que se había perdido todo.
 */
function restaurarAreasPaso1() {
    const b = leerBorrador('paso1_' + INSPECCION_ID);
    if (!b || !b.datos || !Array.isArray(b.datos.areas_comunes)) return;

    b.datos.areas_comunes.forEach(a => {
        let row = document.querySelector('.area-row[data-area="' + a.tipo + '"]');

        // Un área "Otros" cuya fila todavía no existe: se redibuja.
        if (!row && String(a.tipo).indexOf('otra_') === 0) {
            const nom = (a.nombre_libre || String(a.tipo).slice(5).replace(/_/g, ' '));
            row = pintarAreaNueva(a.tipo, nom);
        }
        if (!row) return;

        const chk = row.querySelector('.area-reparar');
        if (chk && !chk.checked) {
            chk.checked = true;
            const det = row.querySelector('.area-detalle');
            if (det) det.style.display = 'block';
            const lbl = row.querySelector('.area-chk-lbl');
            if (lbl) {
                lbl.style.background = '#fdf3e7';
                lbl.style.fontWeight = '600';
                lbl.style.color      = '#A66A00';
            }
        }

        const selT = row.querySelector('.area-trabajo');
        if (selT && a.tipo_trabajo) selT.value = a.tipo_trabajo;

        // Metros por superficie.
        const sups = a.superficies || {};
        Object.keys(sups).forEach(sup => {
            const inp = row.querySelector('.area-sup[data-sup="' + sup + '"]');
            if (inp) inp.value = String(sups[sup]).replace('.', ',');
        });

        // Trabajos adicionales del área.
        (a.extras || []).forEach(ex => {
            const btn = row.querySelector('[onclick*="agregarPartidaArea"]');
            if (!btn) return;
            agregarPartidaArea(btn, a.tipo);
            const bloques = row.querySelectorAll('.partida-area');
            const nuevo = bloques[bloques.length - 1];
            if (!nuevo) return;
            const st = nuevo.querySelector('.part-area-trabajo');
            if (st && ex.tipo_trabajo) st.value = ex.tipo_trabajo;
            Object.keys(ex.superficies || {}).forEach(sup => {
                const inp = nuevo.querySelector('.part-area-m2[data-sup="' + sup + '"]');
                if (inp) inp.value = String(ex.superficies[sup]).replace('.', ',');
            });
        });

        try { calcularMatArea(row.querySelector('.area-sup')); } catch (e) {}
    });
}

// Se llama después de restaurarAreasLibres: primero existen las filas,
// después se rellenan.
try { restaurarAreasPaso1(); } catch (e) { /* seguir */ }

try {
    avisoSinSenal();
    window.addEventListener('online',  avisoSinSenal);
    window.addEventListener('offline', avisoSinSenal);
} catch (e) { /* no interrumpir */ }

// Arranque del respaldo automático.
// El script va al final de la página, así que DOMContentLoaded ya pasó:
// hay que llamar directamente o el respaldo nunca arranca.
try {
    revisarRespaldoPrevio();
} catch (e) {
    console.error('No se pudo revisar el respaldo previo:', e);
}

try {
    setInterval(respaldarTodo, 30000);              // cada 30 segundos
    window.addEventListener('beforeunload', respaldarTodo);  // al cerrar
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) respaldarTodo();       // al cambiar de app
    });
    // Un respaldo inmediato, por si cierran antes de los 30 segundos.
    setTimeout(respaldarTodo, 3000);
} catch (e) {
    console.error('No se pudo activar el respaldo automático:', e);
}

/** Guarda los datos de un apartamento creado sin conexión. */
function guardarAptoLocal(aptoId, datos) {
    let guardado = false;

    // 1) Si el apartamento vive en la estructura completa del edificio
    //    (creada al no haber señal en el paso 1).
    try {
        const est = window._estructuraLocal
            || JSON.parse(localStorage.getItem('estructura_' + INSPECCION_ID) || 'null');
        if (est && Array.isArray(est.pisos)) {
            est.pisos.forEach(p => (p.apartamentos || []).forEach(a => {
                if (a.id === aptoId) {
                    Object.assign(a, datos, { completado: true });
                    guardado = true;
                }
            }));
            if (guardado) {
                localStorage.setItem('estructura_' + INSPECCION_ID, JSON.stringify(est));
                window._estructuraLocal = est;
            }
        }
    } catch (e) { /* seguir con el segundo intento */ }

    if (guardado) return;

    // 2) Si se generó por piso (cuando el edificio ya existía en el
    //    servidor pero el piso se abrió sin señal).
    try {
        // El id del piso sale del id del apartamento: -(piso*100 + n)
        const pisoId = Math.floor(Math.abs(aptoId) / 100);
        const k = 'aptos_piso_' + pisoId;
        const bloque = JSON.parse(localStorage.getItem(k) || 'null');
        if (bloque && Array.isArray(bloque.apartamentos)) {
            bloque.apartamentos.forEach(a => {
                if (a.id === aptoId) Object.assign(a, datos, { completado: true });
            });
            localStorage.setItem(k, JSON.stringify(bloque));
            guardado = true;
        }
    } catch (e) { /* seguir */ }

    // 3) Último recurso: se guarda suelto, para no perder lo escrito.
    if (!guardado) {
        try {
            localStorage.setItem('apto_local_' + aptoId,
                JSON.stringify(Object.assign({}, datos, { id: aptoId, completado: true })));
        } catch (e) { /* sin espacio */ }
    }
}

/**
 * Guarda los ambientes de un apartamento en el teléfono.
 * Así se pueden ver y fotografiar aunque no haya señal, y al sincronizar
 * las fotos se asocian al ambiente correcto.
 */
function guardarAmbientesLocales(aptoId, datos) {
    try {
        const tipos = [
            ['Habitación', parseInt(datos.num_habitaciones) || 0],
            ['Sala',       parseInt(datos.num_salas) || 0],
            ['Baño',       parseInt(datos.num_banos) || 0],
            ['Cocina',     parseInt(datos.num_cocinas) || 0],
            ['Balcón',     parseInt(datos.num_balcones) || 0],
        ];
        const ambientes = [];
        let n = 1;
        tipos.forEach(([tipo, cant]) => {
            for (let i = 1; i <= cant; i++) {
                ambientes.push({
                    // Id temporal: negativo y único dentro del apartamento.
                    id: -(Math.abs(aptoId) * 100 + n),
                    tipo: tipo, numero: i,
                    etiqueta: tipo + ' ' + i,
                    apartamento_id: aptoId,
                    local: true,
                });
                n++;
            }
        });
        localStorage.setItem('ambientes_' + aptoId, JSON.stringify({
            apartamento_id: aptoId,
            jefe_nombre: datos.jefe_nombre || '',
            ambientes: ambientes,
            fecha: new Date().toISOString(),
        }));
    } catch (e) { /* si no hay espacio, se sigue trabajando */ }
}

/** Recupera los ambientes guardados de un apartamento. */
function leerAmbientesLocales(aptoId) {
    try {
        const raw = localStorage.getItem('ambientes_' + aptoId);
        return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
}

/**
 * Dibuja los ambientes sin consultar al servidor.
 * Cada uno permite tomar fotos: quedan en cola con su ambiente temporal
 * y se reasignan al ambiente real cuando el apartamento se sincroniza.
 */
function pintarAmbientesLocales(cont, datos, aptoId) {
    const lista = cont.querySelector('.amb-lista');
    if (!lista) return;
    // Autoguardado por ambiente: saber a qué apartamento pertenece.
    lista.dataset.apto = aptoId;
    window._aptoActivo = aptoId;

    const guardado = leerAmbientesLocales(aptoId);
    const ambientes = guardado ? guardado.ambientes : [];

    if (!ambientes.length) {
        lista.innerHTML = '<div style="font-size:12px;color:#767c94;padding:6px 0;">'
            + 'Indique cuántos ambientes tiene el apartamento.</div>';
        return;
    }

    let html = '<div style="background:#fffbf0;border:1px solid #C9A22755;border-radius:8px;'
        + 'padding:9px 12px;margin-bottom:10px;font-size:12.5px;color:#8a6d1a;">'
        + '<i class="bi bi-phone-fill"></i> Estos ambientes están guardados en su teléfono. '
        + 'Puede tomarles fotos: todo subirá junto al recuperar la señal.</div>';

    const iconos = {'Habitación':'bi-door-closed','Sala':'bi-tv','Balcón':'bi-flower1','Cocina':'bi-fire','Baño':'bi-droplet'};
    const tipos = (Array.isArray(TIPOS_TRABAJO) ? TIPOS_TRABAJO : []);

    ambientes.forEach(am => {
        const rep = am.necesita_reparacion == 1;
        html += `
        <div class="amb-row" data-amb="${am.id}" data-amb-local="${am.id}"
             style="border:1px solid #e8ebf3;border-radius:9px;padding:10px 12px;margin-bottom:8px;">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <span class="amb-nom" style="font-weight:600;color:#2a3140;">
                    <i class="bi ${iconos[am.tipo]||'bi-square'}"></i> ${am.etiqueta}
                </span>
                <label class="seg-radio">
                    <input type="checkbox" class="amb-reparar" ${rep?'checked':''}
                           onchange="toggleReparar(this, ${am.id})"> Necesita reparación
                </label>
                <button type="button" class="btn btn-outline btn-sm"
                        onclick="fotoAmbienteLocal(${am.id}, '${String(am.etiqueta).replace(/'/g, "\\'")}', ${aptoId})">
                    <i class="bi bi-camera"></i> Foto
                </button>
                <span class="amb-hint text-sm" style="color:#767c94;">
                    ${rep?'Suba fotos indicando la parte':'Suba 1 foto del estado'}
                </span>
            </div>
            <div class="amb-reparacion" style="${rep?'':'display:none;'}margin-top:10px;padding:10px;background:#fbf8ef;border-radius:8px;">
                <div style="background:#fff;border:1px solid #C9A22755;border-radius:7px;
                            padding:8px 11px;margin-bottom:10px;font-size:12px;color:#8a6d1a;">
                    <strong><i class="bi bi-exclamation-circle-fill"></i> Este ambiente necesita
                    tres datos obligatorios:</strong><br>
                    1. Qué trabajo hacer &nbsp;·&nbsp; 2. Cuántos metros &nbsp;·&nbsp; 3. Foto del daño
                </div>
                <div class="text-sm" style="font-weight:600;color:#8a6d1a;margin-bottom:6px;">
                    <i class="bi bi-tools"></i> ¿Qué trabajo hay que hacer?
                    <span style="color:#A61C1C;">*</span>
                </div>
                <select class="form-control amb-trabajo" style="margin-bottom:10px;"
                        onchange="guardarTrabajo(${am.id}, this); avisoSuperficies(this); recalcularMateriales(this.closest('.amb-row'));">
                    <option value="">— Seleccione el trabajo —</option>
                    ${tipos.map(t =>
                        `<option value="${t.clave}" ${am.tipo_trabajo === t.clave ? 'selected' : ''}
                                 title="${t.descripcion || ''}">${t.nombre}</option>`).join('')}
                </select>
                <div class="text-sm" style="font-weight:600;color:#8a6d1a;margin-bottom:6px;">
                    <i class="bi bi-rulers"></i> Metros cuadrados a reparar
                    <span style="color:#A61C1C;">*</span>
                    <span style="font-weight:400;font-size:11.5px;color:#8a6d1a;">
                        — indique al menos uno
                    </span>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    ${['pared','techo','piso'].map(sup => `
                        <div style="width:112px;">
                            <label class="text-sm" style="text-transform:capitalize;">${sup}</label>
                            <div style="display:flex;align-items:center;gap:5px;">
                                <input type="text" inputmode="decimal" class="form-control sup-${sup}"
                                       data-sup="${sup}" value="0" style="flex:1;min-width:0;"
                                       oninput="normalizarDecimal(this); actualizarTotalM2(this.closest('.amb-row'));"
                                       onchange="guardarReparacion(${am.id}, this)">
                                <span style="font-size:12px;color:#8a6d1a;font-weight:600;">m²</span>
                            </div>
                        </div>`).join('')}
                </div>

                <div class="amb-total-m2" style="margin-top:9px;background:#fff;
                     border:1px solid #C9A22755;border-radius:8px;padding:9px 13px;
                     display:flex;justify-content:space-between;align-items:center;">
                    <span style="font-size:12.5px;color:#8a6d1a;font-weight:600;">
                        Total de este ambiente
                    </span>
                    <span class="amb-suma" style="font-size:18px;font-weight:800;color:#22366F;">
                        0 m²
                    </span>
                </div>

                <div class="amb-partidas"></div>

                <button type="button" class="btn btn-outline btn-sm"
                        style="margin-top:9px;border-color:#2d448855;color:#2d4488;font-size:12px;"
                        onclick="agregarPartida(this, ${am.id})">
                    <i class="bi bi-plus-circle"></i> Agregar otro trabajo aquí
                </button>

                <div class="amb-materiales text-sm" style="margin-top:8px;color:#55617f;"></div>
            </div>
            <span class="amb-fotos amb-fotos-local" id="amb-fotos-${am.id}"
                  style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;"></span>
        </div>`;
    });

    lista.innerHTML = html;

    // Repintar lo que el técnico ya había escrito para estos ambientes.
    restaurarAmbientesLocales(aptoId, lista);
    try { aplicarSoloLectura(); } catch (e) { /* seguir */ }
}

/**
 * Vuelve a colocar en pantalla el trabajo y los metros que el técnico
 * ya había escrito sin señal. Sin esto, al cerrar y reabrir el
 * apartamento los datos seguían guardados pero se veían vacíos.
 */
function restaurarAmbientesLocales(aptoId, lista) {
    const b = leerBorrador(aptoId);
    if (!b || !b.datos || !Array.isArray(b.datos.ambientes)) return;

    b.datos.ambientes.forEach(g => {
        const row = lista.querySelector('.amb-row[data-amb="' + g.amb + '"]');
        if (!row) return;

        const chk = row.querySelector('.amb-reparar');
        if (chk && g.repara) {
            chk.checked = true;
            const bloque = row.querySelector('.amb-reparacion');
            if (bloque) bloque.style.display = 'block';
            const hint = row.querySelector('.amb-hint');
            if (hint) hint.textContent = 'Suba fotos indicando la parte';
        }

        const selT = row.querySelector('.amb-trabajo');
        if (selT && g.trabajo) selT.value = g.trabajo;

        Object.keys(g.metros || {}).forEach(sup => {
            const inp = row.querySelector('.sup-' + sup);
            if (inp) inp.value = g.metros[sup];
        });

        (g.extras || []).forEach(ex => {
            const btn = row.querySelector('[onclick*="agregarPartida"]');
            if (!btn) return;
            agregarPartida(btn, g.amb);
            const bloques = row.querySelectorAll('.partida-extra');
            const nuevo = bloques[bloques.length - 1];
            if (!nuevo) return;
            const st = nuevo.querySelector('.part-trabajo');
            if (st && ex.trabajo) st.value = ex.trabajo;
            Object.keys(ex.metros || {}).forEach(sup => {
                const inp = nuevo.querySelector('[data-sup="' + sup + '"]');
                if (inp) inp.value = ex.metros[sup];
            });
        });

        actualizarTotalM2(row);
        recalcularMateriales(row);
    });
}

/**
 * Toma una foto de un ambiente que todavía no existe en el servidor.
 * Se encola indicando el apartamento y la posición del ambiente, para
 * que al sincronizar se asocie al ambiente correcto.
 */
function fotoAmbienteLocal(ambLocalId, etiqueta, aptoId) {
    elegirOrigenFoto({
        nivel: 'ambiente_local',
        refId: ambLocalId,
        aptoId: aptoId,
        etiqueta: etiqueta,
        cont: document.getElementById('amb-fotos-' + ambLocalId),
        pideParte: false,
        parteFija: 'antes',
    });
}

// ---- Borradores locales: lo escrito no se pierde aunque se corte todo ----

/**
 * Autoguardado de un ambiente en el teléfono, en CADA cambio.
 *
 * Antes, el trabajo/metros/reparación de un ambiente solo se guardaba al
 * pulsar "Guardar apartamento". Si el técnico refrescaba, cerraba sesión
 * o se le caía todo antes de ese botón, perdía lo escrito en los
 * ambientes. Ahora, apenas cambia un campo, se persiste aquí — y
 * restaurarAmbientesLocales() lo vuelve a pintar al reabrir.
 *
 * Guarda en el MISMO borrador del apartamento (borrador_apto_<id>),
 * dentro de datos.ambientes[], con la forma que espera la restauración.
 */
function autoguardarAmbiente(row) {
    try {
        if (!row) return;
        const ambId = row.getAttribute('data-amb');
        if (ambId === null) return;

        // Encontrar el apartamento dueño de este ambiente.
        const card = row.closest('.apto-card');
        let aptoId = card && card.dataset.aptoId ? card.dataset.aptoId : null;
        if (aptoId === null) {
            // Apto local: la lista de ambientes cuelga de un contenedor con
            // el id en el DOM; si no, se usa el que dejó pintarAmbientes.
            aptoId = row.closest('.amb-lista')?.dataset.apto
                  || card?.dataset.ident
                  || window._aptoActivo;
        }
        if (aptoId === null || aptoId === undefined) return;

        // Estado actual del ambiente.
        const chk  = row.querySelector('.amb-reparar');
        const selT = row.querySelector('.amb-trabajo');
        const g = {
            amb: isNaN(parseInt(ambId)) ? ambId : parseInt(ambId),
            repara: chk ? (chk.checked ? 1 : 0) : 0,
            trabajo: selT ? selT.value : '',
            metros: {},
            extras: [],
        };
        row.querySelectorAll('[data-sup]').forEach(inp => {
            if (inp.closest('.partida-extra')) return;
            const v = aNumero(inp.value);
            if (v > 0) g.metros[inp.dataset.sup] = inp.value;
        });
        row.querySelectorAll('.partida-extra').forEach(bl => {
            const st = bl.querySelector('.part-trabajo');
            const ex = { trabajo: st ? st.value : '', metros: {} };
            bl.querySelectorAll('[data-sup]').forEach(inp => {
                const v = aNumero(inp.value);
                if (v > 0) ex.metros[inp.dataset.sup] = inp.value;
            });
            if (ex.trabajo || Object.keys(ex.metros).length) g.extras.push(ex);
        });

        // Mezclar en el borrador existente sin pisar otros campos.
        const b = leerBorrador(aptoId);
        const datos = (b && b.datos) ? b.datos : {};
        if (!Array.isArray(datos.ambientes)) datos.ambientes = [];
        const i = datos.ambientes.findIndex(x => String(x.amb) === String(g.amb));
        if (i >= 0) datos.ambientes[i] = g; else datos.ambientes.push(g);

        guardarBorrador(aptoId, datos);
    } catch (e) { /* nunca interrumpir el llenado por un fallo de guardado */ }
}

function guardarBorrador(aptoId, datos) {
    try {
        localStorage.setItem('borrador_apto_' + aptoId, JSON.stringify({
            datos: datos, fecha: new Date().toISOString()
        }));
    } catch (e) { /* si no hay espacio, seguir igual */ }
}

function borrarBorrador(aptoId) {
    try { localStorage.removeItem('borrador_apto_' + aptoId); } catch (e) {}
}

function leerBorrador(aptoId) {
    try {
        const raw = localStorage.getItem('borrador_apto_' + aptoId);
        return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
}

// Restaura lo que el usuario había escrito y no llegó a guardarse.
function restaurarBorrador(aptoId, cont) {
    const b = leerBorrador(aptoId);
    if (!b || !b.datos) return false;
    const d = b.datos;
    const set = (sel, val) => { const el = cont.querySelector(sel); if (el && val != null) el.value = val; };
    set('.jefe-nombre', d.jefe_nombre);
    set('.jefe-cedula', d.jefe_cedula);
    set('.jefe-telefono', d.jefe_telefono);
    set('.amb-habitaciones', d.num_habitaciones);
    set('.amb-salas', d.num_salas);
    set('.amb-banos', d.num_banos);
    set('.amb-cocinas', d.num_cocinas);
    set('.amb-balcones', d.num_balcones);
    marcarAptoPendiente(cont, 'Se recuperó lo que había escrito');
    return true;
}

function marcarAptoPendiente(cont, texto) {
    let el = cont.querySelector('.apto-estado');
    if (!el) {
        el = document.createElement('div');
        el.className = 'apto-estado';
        el.style.cssText = 'font-size:12.5px;font-weight:600;margin-top:8px;';
        cont.appendChild(el);
    }
    if (!texto) { el.textContent = ''; return; }
    el.style.color = '#8a6d1a';
    el.innerHTML = '<i class="bi bi-phone-fill"></i> ' + texto;
}

async function cargarAmbientes(aptoId, contenedor) {
    // Marcar el contenedor con su apartamento: el autoguardado por
    // ambiente lo necesita para saber en qué borrador escribir.
    if (contenedor) contenedor.dataset.apto = aptoId;
    window._aptoActivo = aptoId;
    const res = await fetch(URL_BASE + 'listar_rec_aptos.php?ambientes_de=' + aptoId);
    const data = await res.json();
    if (data.ok) pintarAmbientes(data.ambientes, contenedor);
}

function pintarAmbientes(ambientes, contenedor) {
    if (!ambientes || !ambientes.length) { contenedor.innerHTML = ''; return; }
    const iconos = {'Habitación':'bi-door-closed','Sala':'bi-tv','Balcón':'bi-flower1','Cocina':'bi-fire'};
    let html = '';
    ambientes.forEach(am => {
        const rep = am.necesita_reparacion == 1;
        html += `
        <div class="amb-row" data-amb="${am.id}" style="border:1px solid #e8ebf3;border-radius:9px;padding:10px 12px;margin-bottom:8px;">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <span class="amb-nom" style="font-weight:600;color:#2a3140;"><i class="bi ${iconos[am.tipo]||'bi-square'}"></i> ${am.tipo} ${am.numero}</span>
                <label class="seg-radio"><input type="checkbox" class="amb-reparar" ${rep?'checked':''} onchange="toggleReparar(this, ${am.id})"> Necesita reparación</label>
                <button type="button" class="btn btn-outline btn-sm" onclick="fotoAmbiente(this, ${am.id})"><i class="bi bi-camera"></i> Foto${rep?'s':''}</button>
                <span class="amb-hint text-sm" style="color:#767c94;">${rep?'Suba fotos indicando la parte':'Suba 1 foto del estado'}</span>
            </div>
            <div class="amb-reparacion" style="${rep?'':'display:none;'}margin-top:10px;padding:10px;background:#fbf8ef;border-radius:8px;">
                <div style="background:#fff;border:1px solid #C9A22755;border-radius:7px;
                            padding:8px 11px;margin-bottom:10px;font-size:12px;color:#8a6d1a;">
                    <strong><i class="bi bi-exclamation-circle-fill"></i> Este ambiente necesita
                    tres datos obligatorios:</strong><br>
                    1. Qué trabajo hacer &nbsp;·&nbsp; 2. Cuántos metros &nbsp;·&nbsp; 3. Foto del daño
                </div>
                <div class="text-sm" style="font-weight:600;color:#8a6d1a;margin-bottom:6px;">
                    <i class="bi bi-tools"></i> ¿Qué trabajo hay que hacer?
                    <span style="color:#A61C1C;">*</span>
                </div>
                <select class="form-control amb-trabajo" style="margin-bottom:10px;"
                        onchange="guardarTrabajo(${am.id}, this); avisoSuperficies(this); recalcularMateriales(this.closest('.amb-row'));">
                    <option value="">— Seleccione el trabajo —</option>
                    ${(Array.isArray(TIPOS_TRABAJO) ? TIPOS_TRABAJO : []).map(t =>
                        `<option value="${t.clave}" ${am.tipo_trabajo === t.clave ? 'selected' : ''}
                                 title="${t.descripcion || ''}">${t.nombre}</option>`).join('')}
                </select>
                <div class="text-sm" style="font-weight:600;color:#8a6d1a;margin-bottom:6px;">
                    <i class="bi bi-rulers"></i> Metros cuadrados a reparar
                    <span style="color:#A61C1C;">*</span>
                    <span style="font-weight:400;font-size:11.5px;color:#8a6d1a;">
                        — indique al menos uno
                    </span>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    ${['pared','techo','piso'].map(sup => `
                        <div style="width:112px;">
                            <label class="text-sm" style="text-transform:capitalize;">${sup}</label>
                            <div style="display:flex;align-items:center;gap:5px;">
                                <input type="text" inputmode="decimal" class="form-control sup-${sup}"
                                       data-sup="${sup}" value="0" style="flex:1;min-width:0;"
                                       oninput="normalizarDecimal(this); actualizarTotalM2(this.closest('.amb-row'));"
                                       onchange="guardarReparacion(${am.id}, this)">
                                <span style="font-size:12px;color:#8a6d1a;font-weight:600;">m²</span>
                            </div>
                        </div>`).join('')}
                </div>

                <!-- Total de metros del ambiente -->
                <div class="amb-total-m2" style="margin-top:9px;background:#fff;
                     border:1px solid #C9A22755;border-radius:8px;padding:9px 13px;
                     display:flex;justify-content:space-between;align-items:center;">
                    <span style="font-size:12.5px;color:#8a6d1a;font-weight:600;">
                        Total de este ambiente
                    </span>
                    <span class="amb-suma" style="font-size:18px;font-weight:800;color:#22366F;">
                        0 m²
                    </span>
                </div>

                <div class="amb-partidas"></div>

                <button type="button" class="btn btn-outline btn-sm"
                        style="margin-top:9px;border-color:#2d448855;color:#2d4488;font-size:12px;"
                        onclick="agregarPartida(this, ${am.id})">
                    <i class="bi bi-plus-circle"></i> Agregar otro trabajo aquí
                </button>

                <div class="amb-materiales text-sm" style="margin-top:8px;color:#55617f;"></div>
            </div>
            <div class="amb-fotos" style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;"></div>
        </div>`;
    });
    contenedor.innerHTML = html;
    try { aplicarSoloLectura(); } catch (e) { /* seguir */ }
    ambientes.forEach(am => {
        fetch(URL_BASE + 'listar_rec_aptos.php?fotos_de=' + am.id).then(r=>r.json()).then(d=>{
            if (d.ok && d.fotos.length) {
                const row = contenedor.querySelector('.amb-row[data-amb="'+am.id+'"] .amb-fotos');
                d.fotos.forEach(f => agregarMiniFoto(row, f));
            }
        });
        fetch(URL_BASE + 'listar_rec_aptos.php?reparaciones_de=' + am.id).then(r=>r.json()).then(d=>{
            if (d.ok && d.reparaciones && d.reparaciones.length) {
                const row = contenedor.querySelector('.amb-row[data-amb="'+am.id+'"]');
                let trabajoGuardado = '';
                // Agrupar por tipo de trabajo: cada uno es una partida.
                const porTrabajo = {};
                d.reparaciones.forEach(rep => {
                    const t = rep.tipo_trabajo || '';
                    if (!porTrabajo[t]) porTrabajo[t] = [];
                    porTrabajo[t].push(rep);
                });

                const trabajos = Object.keys(porTrabajo);
                trabajoGuardado = trabajos[0] || '';

                // El primer trabajo va en los campos principales.
                (porTrabajo[trabajoGuardado] || []).forEach(rep => {
                    const inp = row.querySelector('.sup-' + rep.tipo_superficie);
                    // Se muestra con coma, como se escribe en Venezuela.
                    if (inp) inp.value = String(rep.metros_cuadrados).replace('.', ',');
                });
                if (trabajoGuardado) {
                    const sel = row.querySelector('.amb-trabajo');
                    if (sel) { sel.value = trabajoGuardado; avisoSuperficies(sel); }
                }

                // Los demás se pintan como trabajos adicionales.
                trabajos.slice(1).forEach(t => {
                    if (!t) return;
                    const btn = row.querySelector('[onclick*="agregarPartida"]');
                    if (!btn) return;
                    agregarPartida(btn, am.id);

                    const bloques = row.querySelectorAll('.partida-extra');
                    const nuevo = bloques[bloques.length - 1];
                    if (!nuevo) return;

                    const selT = nuevo.querySelector('.part-trabajo');
                    if (selT) selT.value = t;
                    porTrabajo[t].forEach(rep => {
                        const inp = nuevo.querySelector('[data-sup="' + rep.tipo_superficie + '"]');
                        if (inp) inp.value = String(rep.metros_cuadrados).replace('.', ',');
                    });
                });
                actualizarTotalM2(row);
                recalcularMateriales(row);
            }
        });
    });
}

/**
 * Convierte el punto en coma mientras se escribe.
 * En Venezuela el separador decimal es la coma, pero los teclados de
 * celular suelen ofrecer punto. Así el técnico escribe como quiera.
 */
function normalizarDecimal(inp) {
    const pos = inp.selectionStart;
    let v = inp.value;

    // Solo dígitos y un separador.
    v = v.replace(/[^0-9.,]/g, '');
    v = v.replace(/\./g, ',');          // el punto pasa a coma
    const partes = v.split(',');
    if (partes.length > 2) {            // más de una coma: se queda la primera
        v = partes[0] + ',' + partes.slice(1).join('');
    }
    // Máximo dos decimales.
    const p = v.split(',');
    if (p[1] && p[1].length > 2) v = p[0] + ',' + p[1].slice(0, 2);

    if (v !== inp.value) {
        inp.value = v;
        try { inp.setSelectionRange(pos, pos); } catch (e) {}
    }
}

/** Convierte "12,5" a 12.5 para enviarlo al servidor. */
function aNumero(txt) {
    if (txt === null || txt === undefined) return 0;
    const n = parseFloat(String(txt).replace(',', '.'));
    return isNaN(n) ? 0 : n;
}

/**
 * En casas, los datos del jefe de familia se piden una sola vez:
 * es la misma familia en todos los niveles.
 */
function ajustarCasaJefeFamilia() {
    if (!ES_CASA) return;
    const cuerpos = document.querySelectorAll('.apto-card .apto-body');
    cuerpos.forEach((c, i) => {
        if (i === 0) return;   // el primero conserva el bloque
        const b = c.querySelector('.bloque-jefe');
        if (b) b.style.display = 'none';
    });
}

/**
 * Abre un apartamento, pero antes revisa que el que estaba abierto
 * esté completo.
 *
 * Sin esto, el técnico salta de uno a otro y deja huecos que después
 * hay que rastrear edificio por edificio.
 */
function abrirApto(cab) {
    const cuerpo = cab.nextElementSibling;
    const yaAbierto = !cuerpo.classList.contains('hidden');

    // Si se está cerrando, no hay nada que revisar.
    if (yaAbierto) {
        cuerpo.classList.add('hidden');
        return;
    }

    // Revisar el apartamento que quedó abierto, si hay alguno.
    const abierto = document.querySelector('.apto-card .apto-body:not(.hidden)');
    if (abierto && abierto !== cuerpo) {
        const falta = queFaltaEnApto(abierto);
        if (falta) {
            alert('Antes de pasar al siguiente apartamento:\n\n' + falta);
            abierto.scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }
        abierto.classList.add('hidden');
    }

    cuerpo.classList.remove('hidden');
}

/**
 * Qué le falta a un apartamento para darse por terminado.
 * Devuelve el texto de lo que falta, o cadena vacía si está completo.
 */
function queFaltaEnApto(cuerpo) {
    if (!cuerpo) return '';

    // Si se marcó como no visitado, ya está resuelto.
    if (cuerpo.querySelector('.apto-marcado')) return '';

    const v = sel => {
        const el = cuerpo.querySelector(sel);
        return el ? (el.value || '').trim() : '';
    };

    // Un apartamento sin ambientes generados todavía no se tocó.
    const filas = cuerpo.querySelectorAll('.amb-row');
    const sinTocar = filas.length === 0
                  && !v('.jefe-nombre') && !v('.jefe-cedula');
    if (sinTocar) return '';   // ni siquiera lo empezó: no se bloquea

    const faltan = [];

    // Datos del jefe de familia. En casas solo se piden en el primer
    // nivel: si el bloque está oculto, no se valida.
    const bloqueJefe = cuerpo.querySelector('.bloque-jefe');
    const pideJefe = !bloqueJefe || bloqueJefe.style.display !== 'none';
    if (pideJefe) {
        if (!v('.jefe-nombre'))   faltan.push('· El nombre del jefe de familia');
        if (!v('.jefe-cedula'))   faltan.push('· La cédula');
        if (!v('.jefe-telefono')) faltan.push('· El teléfono');
    }

    // Ambientes marcados para reparar.
    filas.forEach(row => {
        const chk = row.querySelector('.amb-reparar');
        if (!chk || !chk.checked) return;

        const nom = row.querySelector('.amb-nom');
        const et = nom ? nom.textContent.trim() : 'un ambiente';

        const selT = row.querySelector('.amb-trabajo');
        if (selT && !selT.value) faltan.push('· ' + et + ': qué trabajo hacer');

        let m2 = 0;
        row.querySelectorAll('[data-sup]').forEach(i => { m2 += aNumero(i.value); });
        if (m2 <= 0) faltan.push('· ' + et + ': los metros cuadrados');

        // Se cuentan las fotos subidas y las que esperan señal.
        const nFotos = row.querySelectorAll('.amb-fotos img').length
                     + row.querySelectorAll('.amb-fotos-local img').length
                     + row.querySelectorAll('.foto-pendiente').length;
        if (nFotos === 0) {
            faltan.push('· ' + et + ': la foto del daño');
        }
    });

    if (!faltan.length) return '';
    return faltan.slice(0, 8).join('\n')
         + (faltan.length > 8 ? '\n· y ' + (faltan.length - 8) + ' más' : '')
         + '\n\nSi no pudo entrar, use los botones de arriba.';
}

/**
 * Guarda los datos del jefe de familia apenas se escriben.
 *
 * Antes solo se enviaban al tocar "Generar ambientes": si se iba la
 * señal antes, se perdía todo lo escrito. Ahora cada campo se guarda
 * al salir de él, y si no hay conexión queda en la cola de envío.
 */
async function guardarJefe(aptoId, input) {
    if (!PUEDE_EDITAR) return;
    const cuerpo = input.closest('.apto-body');
    if (!cuerpo) return;

    const v = sel => {
        const el = cuerpo.querySelector(sel);
        return el ? (el.value || '').trim() : '';
    };

    const payload = {
        accion: 'jefe_familia',
        apartamento_id: aptoId,
        jefe_nombre:   v('.jefe-nombre'),
        jefe_cedula:   v('.jefe-cedula'),
        jefe_telefono: v('.jefe-telefono'),
    };

    // Respaldo inmediato en el teléfono, pase lo que pase.
    try { respaldarTodo(); } catch (e) {}

    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
            'Jefe de familia · apto ' + aptoId);
        marcarGuardado(input, 'En el teléfono');
        return;
    }

    try {
        const res = await fetch(URL_BASE + 'guardar_rec_apto.php', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials: 'same-origin'
        });
        const d = await res.json();
        marcarGuardado(input, d.ok ? 'Guardado' : 'No se pudo');
    } catch (e) {
        // Sin señal: a la cola.
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
                'Jefe de familia · apto ' + aptoId);
            marcarGuardado(input, 'En el teléfono');
        }
    }
}

/** Señal breve de que el dato quedó guardado. */
function marcarGuardado(input, texto) {
    if (!input) return;
    const ok = texto === 'Guardado' || texto === 'En el teléfono';
    input.style.borderColor = ok ? '#2E7D32' : '#A61C1C';
    setTimeout(() => { input.style.borderColor = ''; }, 1800);
}

/** Quita un trabajo adicional y vuelve a guardar el ambiente. */
function quitarPartida(btn, ambId) {
    const bloque = btn.closest('.partida-extra');
    const row = btn.closest('.amb-row');
    if (bloque) bloque.remove();
    actualizarTotalM2(row);

    // Guardar de nuevo: si no, la partida borrada seguiría en la base.
    const algun = row.querySelector('[data-sup]');
    if (algun) guardarReparacion(ambId, algun);
}

/**
 * Suma los metros del ambiente y los muestra abajo.
 * Incluye los trabajos adicionales, para que el técnico vea el total
 * real de lo que hay que reparar ahí.
 */
function actualizarTotalM2(row) {
    if (!row) return;
    let suma = 0;
    row.querySelectorAll('[data-sup]').forEach(inp => { suma += aNumero(inp.value); });

    const dest = row.querySelector('.amb-suma');
    if (!dest) return;

    // Se muestra con coma, como se escribe en Venezuela.
    const txt = (Math.round(suma * 100) / 100).toString().replace('.', ',');
    dest.textContent = txt + ' m²';
    dest.style.color = suma > 0 ? '#22366F' : '#c4c9d6';

    const caja = row.querySelector('.amb-total-m2');
    if (caja) {
        caja.style.borderColor = suma > 0 ? '#C9A22755' : '#e5e8f0';
        caja.style.background  = suma > 0 ? '#fffdf5' : '#fff';
    }

    // Autoguardado mientras escribe (con pequeño retardo para no saturar
    // el teléfono en cada tecla). Así ni un refresco a media palabra
    // pierde los metros.
    clearTimeout(row._autosaveT);
    row._autosaveT = setTimeout(() => autoguardarAmbiente(row), 400);
}

/**
 * Agrega otro trabajo al mismo ambiente.
 * Sirve cuando en una habitación hay que hacer dos cosas distintas:
 * por ejemplo levantar una pared Y frisar el techo.
 */
function agregarPartida(btn, ambId) {
    const row = btn.closest('.amb-row');
    const cont = row.querySelector('.amb-partidas');
    if (!cont) return;

    const n = cont.querySelectorAll('.partida-extra').length + 2;
    const opciones = (Array.isArray(TIPOS_TRABAJO) ? TIPOS_TRABAJO : [])
        .map(t => '<option value="' + t.clave + '">' + t.nombre + '</option>').join('');

    const bloque = document.createElement('div');
    bloque.className = 'partida-extra';
    bloque.style.cssText = 'border-top:1px dashed #C9A22766;margin-top:11px;padding-top:11px;';
    bloque.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:7px;">'
        + '<span style="font-size:12px;font-weight:700;color:#8a6d1a;">'
        + '<i class="bi bi-tools"></i> Trabajo ' + n + '</span>'
        + '<button type="button" onclick="quitarPartida(this, ' + ambId + ')" '
        + 'style="background:transparent;border:0;color:#c4c9d6;cursor:pointer;font-size:15px;">'
        + '<i class="bi bi-x-circle"></i></button></div>'

        + '<select class="form-control part-trabajo" style="margin-bottom:9px;" '
        + 'onchange="guardarReparacion(' + ambId + ', this)">'
        + '<option value="">— ¿Qué trabajo? —</option>' + opciones + '</select>'

        + '<div style="display:flex;gap:8px;flex-wrap:wrap;">'
        + ['pared', 'techo', 'piso'].map(sup =>
            '<div style="width:112px;">'
            + '<label class="text-sm" style="text-transform:capitalize;">' + sup + '</label>'
            + '<div style="display:flex;align-items:center;gap:5px;">'
            + '<input type="text" inputmode="decimal" class="form-control part-m2" '
            + 'data-sup="' + sup + '" value="0" style="flex:1;min-width:0;" '
            + 'oninput="normalizarDecimal(this); actualizarTotalM2(this.closest(\'.amb-row\'));" '
            + 'onchange="guardarReparacion(' + ambId + ', this)">'
            + '<span style="font-size:12px;color:#8a6d1a;font-weight:600;">m²</span>'
            + '</div></div>').join('')
        + '</div>';

    cont.appendChild(bloque);
    const sel = bloque.querySelector('.part-trabajo');
    if (sel) sel.focus();
}

/** Guarda el tipo de trabajo elegido para un ambiente. */
async function guardarTrabajo(ambId, sel) {
    // Guardar en el teléfono SIEMPRE y primero: si algo pasa después
    // (refresco, sesión caída), lo escrito ya está a salvo.
    autoguardarAmbiente(sel.closest('.amb-row'));

    const payload = { accion:'guardar_trabajo', ambiente_id: ambId, tipo_trabajo: sel.value };
    // Ambiente aún no creado en el servidor: se queda en el borrador local.
    if (ambId < 0) return;
    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
            'Tipo de trabajo · ambiente ' + ambId);
        return;
    }
    try {
        await fetch(URL_BASE + 'guardar_rec_apto.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials:'same-origin'
        });
    } catch (e) {
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
                'Tipo de trabajo · ambiente ' + ambId);
        }
    }
}

function ambienteTieneMetros(row) {
    if (!row) return true;
    const chk = row.querySelector('.amb-reparar');
    if (!chk || !chk.checked) return true;   // sin reparación, no aplica
    // Los campos de metros son de texto (se escribe con coma), no number.
    let suma = 0;
    row.querySelectorAll('.amb-reparacion [data-sup]').forEach(i => {
        suma += aNumero(i.value);
    });
    return suma > 0;
}

/** Resalta el recuadro de fotos cuando falta la evidencia del daño. */
function marcarAmbienteSinFoto(row, falta) {
    if (!row) return;
    const cont = row.querySelector('.amb-fotos');
    if (!cont) return;
    if (falta) {
        cont.style.border = '2px dashed #A61C1C';
        cont.style.borderRadius = '8px';
        cont.style.padding = '9px';
        cont.style.background = '#fff6f6';
        if (!cont.querySelector('.amb-falta-foto')) {
            const aviso = document.createElement('div');
            aviso.className = 'amb-falta-foto';
            aviso.style.cssText = 'font-size:12px;color:#A61C1C;font-weight:600;width:100%;';
            aviso.innerHTML = '<i class="bi bi-camera-fill"></i> '
                + 'Falta la foto que muestre el daño.';
            cont.appendChild(aviso);
        }
    } else {
        cont.style.border = '';
        cont.style.padding = '';
        cont.style.background = '';
        const aviso = cont.querySelector('.amb-falta-foto');
        if (aviso) aviso.remove();
    }
}

/** Resalta en rojo los ambientes que están sin metros. */
function marcarAmbienteSinMetros(row, falta) {
    if (!row) return;
    const caja = row.querySelector('.amb-reparacion');
    if (!caja) return;
    if (falta) {
        caja.style.border = '2px solid #A61C1C';
        caja.style.background = '#fff6f6';
        let aviso = caja.querySelector('.amb-falta-m2');
        if (!aviso) {
            aviso = document.createElement('div');
            aviso.className = 'amb-falta-m2';
            aviso.style.cssText = 'font-size:12px;color:#A61C1C;font-weight:600;margin-top:6px;';
            aviso.innerHTML = '<i class="bi bi-exclamation-triangle-fill"></i> '
                + 'Falta indicar los metros cuadrados a reparar.';
            caja.appendChild(aviso);
        }
    } else {
        caja.style.border = '';
        caja.style.background = '#fbf8ef';
        const aviso = caja.querySelector('.amb-falta-m2');
        if (aviso) aviso.remove();
    }
}

async function toggleReparar(chk, ambId) {
    const row = chk.closest('.amb-row');
    row.querySelector('.amb-hint').textContent = chk.checked ? 'Suba fotos indicando la parte' : 'Suba 1 foto del estado';
    const bloque = row.querySelector('.amb-reparacion');
    if (bloque) bloque.style.display = chk.checked ? 'block' : 'none';

    // Guardar en el teléfono de inmediato, pase lo que pase después.
    autoguardarAmbiente(row);

    const payload = { accion:'guardar_ambiente', ambiente_id: ambId,
                      necesita_reparacion: chk.checked?1:0 };

    // Ambiente creado sin señal (id negativo): todavía no existe en el
    // servidor, así que solo se guarda en el teléfono.
    if (ambId < 0) return;

    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
            'Necesita reparación · ambiente ' + ambId);
        return;
    }
    try {
        await fetch(URL_BASE + 'guardar_rec_apto.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials:'same-origin'
        });
    } catch (e) {
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
                'Necesita reparación · ambiente ' + ambId);
        }
    }
}

async function guardarReparacion(ambId, input) {
    const row = input.closest('.amb-row');

    // Guardar en el teléfono de inmediato: los metros no se pierden
    // aunque el ambiente aún no exista en el servidor o se caiga la señal.
    autoguardarAmbiente(row);

    const reparaciones = [];

    // Trabajo principal del ambiente.
    const selT = row.querySelector('.amb-trabajo');
    const trabajoBase = selT ? selT.value : '';

    // Metros del trabajo principal: los campos que NO están dentro de
    // una partida extra.
    row.querySelectorAll('[data-sup]').forEach(inp => {
        if (inp.closest('.partida-extra')) return;   // esos van aparte
        const m2 = aNumero(inp.value);
        if (m2 > 0) {
            reparaciones.push({
                tipo_superficie: inp.dataset.sup,
                metros_cuadrados: m2,
                tipo_trabajo: trabajoBase,
            });
        }
    });

    // Trabajos adicionales del mismo ambiente, cada uno con lo suyo.
    row.querySelectorAll('.partida-extra').forEach(bloque => {
        const sel = bloque.querySelector('.part-trabajo');
        const trab = sel ? sel.value : '';
        if (!trab) return;   // sin trabajo indicado no se guarda
        bloque.querySelectorAll('[data-sup]').forEach(inp => {
            const m2 = aNumero(inp.value);
            if (m2 > 0) {
                reparaciones.push({
                    tipo_superficie: inp.dataset.sup,
                    metros_cuadrados: m2,
                    tipo_trabajo: trab,
                });
            }
        });
    });

    // El tipo de trabajo viaja junto a los metros: así no se pierde si el
    // técnico llena los m² antes de elegir el trabajo.
    reparaciones.tipo_trabajo = trabajoBase;

    const payload = {
        accion: 'guardar_reparaciones', nivel: 'ambiente', ref_id: ambId,
        reparaciones: reparaciones,
        tipo_trabajo: selT ? selT.value : '',
    };

    // Ambiente creado sin señal: sus metros viajan con el apartamento
    // cuando este se sincroniza, no por separado.
    if (ambId < 0) { recalcularMateriales(row); return; }

    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
            'Metros del ambiente ' + ambId);
        recalcularMateriales(row);
        return;
    }

    try {
        await fetch(URL_BASE + 'guardar_rec_apto.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials:'same-origin'
        });
    } catch (e) {
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_apto.php', payload,
                'Metros del ambiente ' + ambId);
        }
    }
    recalcularMateriales(row);
}

/**
 * Vista previa de materiales según el trabajo elegido y los metros.
 * Se calcula en el navegador con las mismas recetas del servidor, para
 * que funcione también sin señal.
 */
function recalcularMateriales(row) {
    const cont = row.querySelector('.amb-materiales');
    if (!cont) return;

    const selT = row.querySelector('.amb-trabajo');
    const trabajo = selT ? selT.value : '';

    let total = 0;
    row.querySelectorAll('[data-sup]').forEach(inp => { total += parseFloat(inp.value) || 0; });

    if (!total) { cont.innerHTML = ''; return; }

    if (!trabajo) {
        cont.innerHTML = '<div style="margin-top:5px;font-size:12px;color:#a8871f;">'
            + '<i class="bi bi-exclamation-circle"></i> '
            + 'Elija el trabajo para ver los materiales.</div>';
        return;
    }

    const receta = RECETAS_TRABAJO[trabajo] || [];
    if (!receta.length) { cont.innerHTML = ''; return; }

    const enteros = ['unidad', 'saco', 'pieza', 'pliego'];
    const items = receta.map(r => {
        let c = total * parseFloat(r.cantidad);
        c = enteros.includes(r.unidad) ? Math.ceil(c) : Math.round(c * 100) / 100;
        return '<span style="display:inline-block;background:#eef2fb;border-radius:14px;'
             + 'padding:2px 9px;margin:2px;font-size:11.5px;">'
             + r.material + ': <b>' + c.toLocaleString('es-VE') + '</b> ' + r.unidad
             + badgeSacosCementoGrisJS(r.material, c, r.unidad) + '</span>';
    }).join('');

    cont.innerHTML = '<div style="margin-top:5px;"><i class="bi bi-box-seam"></i> '
        + '<span style="font-size:11.5px;color:#5b6478;">Materiales estimados para '
        + total.toLocaleString('es-VE') + ' m²:</span><br>' + items + '</div>';
}

// ================= FOTOS (compartido) =================
// Al tocar "Foto" se abre el selector nativo del teléfono INMEDIATAMENTE
// (cámara o galería, el móvil pregunta). La "parte" (pared, techo…) se pide
// DESPUÉS de elegir la imagen, con botones — nunca con prompt, porque eso
// bloqueaba la apertura de la cámara en el móvil.
// (la variable _fotoDestino se declara al inicio del script)

/**
 * Marca que la edificación no tiene etiqueta.
 * Al activarla se oculta el botón de foto y se pide el motivo, para que
 * quede claro que no es un olvido sino una constancia.
 */
function onSinEtiqueta(chk) {
    const bloque = document.getElementById('bloque-etiqueta');
    const motivo = document.getElementById('motivo-sin-etiqueta');

    if (chk.checked) {
        // Si ya había fotos cargadas, avisar antes de marcar.
        const fotos = document.getElementById('etiqueta-fotos');
        if (fotos && fotos.children.length > 0) {
            if (!confirm('Ya hay una foto de etiqueta cargada.\n\n¿Seguro que esta edificación no tiene etiqueta?')) {
                chk.checked = false;
                return;
            }
        }
        bloque.style.display = 'none';
        motivo.style.display = 'block';
    } else {
        bloque.style.display = '';
        motivo.style.display = 'none';
    }
    guardarSinEtiqueta();
}

/** Guarda la constancia de "sin etiqueta" (funciona con y sin señal). */
async function guardarSinEtiqueta() {
    const chk = document.getElementById('sin-etiqueta');
    if (!chk) return;
    const payload = {
        inspeccion_id: INSPECCION_ID,
        accion: 'sin_etiqueta',
        sin_etiqueta: chk.checked ? 1 : 0,
        etiqueta_motivo: (document.getElementById('etiqueta-motivo') || {}).value || '',
        etiqueta_obs: (document.getElementById('etiqueta-obs') || {}).value || '',
    };

    // Copia local siempre.
    guardarBorrador('etiqueta_' + INSPECCION_ID, payload);

    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_edificio.php', payload,
            chk.checked ? 'Sin etiqueta' : 'Tiene etiqueta');
        avisoEtiqueta('Guardado en el teléfono', '#8a6d1a');
        return;
    }

    try {
        const res = await fetch(URL_BASE + 'guardar_rec_edificio.php', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials: 'same-origin'
        });
        const texto = await res.text();
        let d;
        try { d = JSON.parse(texto); } catch (e) { d = null; }
        if (d && d.ok) {
            avisoEtiqueta('Guardado', '#2E7D32');
        } else if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_edificio.php', payload,
                chk.checked ? 'Sin etiqueta' : 'Tiene etiqueta');
            avisoEtiqueta('Guardado en el teléfono', '#8a6d1a');
        }
    } catch (e) {
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('avance', URL_BASE + 'guardar_rec_edificio.php', payload,
                chk.checked ? 'Sin etiqueta' : 'Tiene etiqueta');
            avisoEtiqueta('Guardado en el teléfono', '#8a6d1a');
        }
    }
}

function avisoEtiqueta(texto, color) {
    let el = document.getElementById('etiqueta-aviso');
    if (!el) {
        el = document.createElement('div');
        el.id = 'etiqueta-aviso';
        el.style.cssText = 'font-size:12.5px;font-weight:600;margin:-4px 0 14px;';
        const motivo = document.getElementById('motivo-sin-etiqueta');
        if (motivo && motivo.parentNode) motivo.parentNode.insertBefore(el, motivo.nextSibling);
    }
    el.style.color = color;
    el.innerHTML = '<i class="bi bi-check-circle-fill"></i> ' + texto;
    clearTimeout(el._t);
    el._t = setTimeout(() => { el.textContent = ''; }, 3000);
}

function subirFotoEtiqueta(btn) {
    // La etiqueta se guarda a nivel 'edificio', con parte 'etiqueta'.
    elegirOrigenFoto({
        nivel:'edificio', refId: EDIFICIO_ID,
        pideParte: false, parteFija: 'etiqueta',
        cont: document.getElementById('etiqueta-fotos')
    });
}

function subirFotoElemento(btn, pisoId, tipo) {
    const row = btn.closest('.elem-row');
    if (!row.dataset.elemId) {
        alert('Primero guarde los elementos del piso para poder adjuntar fotos.');
        return;
    }
    const reparaEl = row.querySelector('.el-reparar').checked;
    elegirOrigenFoto({
        nivel:'elemento_piso', refId: row.dataset.elemId,
        pideParte: reparaEl,
        parteFija: reparaEl ? null : 'antes',
        cont: row.querySelector('.elem-fotos')
    });
}

function fotoAmbiente(btn, ambId) {
    const row = btn.closest('.amb-row');
    const necesitaReparar = row.querySelector('.amb-reparar').checked;
    if (!necesitaReparar && row.querySelectorAll('.amb-fotos img').length >= 1) {
        alert('Este ambiente no necesita reparación: basta con una foto. Marque "Necesita reparación" para agregar más.');
        return;
    }
    elegirOrigenFoto({
        nivel:'ambiente', refId: ambId,
        pideParte: necesitaReparar,
        // Sin reparación es la foto del estado inicial: se marca como
        // "antes" para que el seguimiento la muestre.
        parteFija: necesitaReparar ? null : 'antes',
        cont: row.querySelector('.amb-fotos')
    });
}

/**
 * Pregunta si toma la foto con la cámara o la elige de la galería.
 * Las de cámara se respaldan siempre en el teléfono: esas no quedan
 * en la galería por sí solas y se perderían si falla la subida.
 */
function elegirOrigenFoto(destino) {
    _fotoDestino = destino;
    const capa = document.createElement('div');
    capa.id = 'origen-foto';
    capa.style.cssText = 'position:fixed;inset:0;background:rgba(20,25,40,.6);z-index:2300;'
        + 'display:flex;align-items:flex-end;justify-content:center;';
    capa.innerHTML =
        '<div style="background:#fff;border-radius:14px 14px 0 0;width:100%;max-width:440px;padding:18px 18px 22px;">'
        + '<div style="font-weight:700;color:#22366F;font-size:16px;margin-bottom:14px;text-align:center;">'
        + '¿Cómo quiere agregar la foto?</div>'
        + '<button type="button" onclick="_abrirCamara()" '
        + 'style="width:100%;display:flex;align-items:center;gap:12px;background:#22366F;color:#fff;'
        + 'border:0;border-radius:10px;padding:14px 16px;font-size:15px;font-weight:600;'
        + 'cursor:pointer;margin-bottom:10px;">'
        + '<i class="bi bi-camera-fill" style="font-size:22px;"></i>'
        + '<span style="flex:1;text-align:left;">Tomar foto ahora<br>'
        + '<span style="font-size:12px;font-weight:400;opacity:.85;">Se guarda en su teléfono</span></span></button>'
        + '<button type="button" onclick="_abrirGaleria()" '
        + 'style="width:100%;display:flex;align-items:center;gap:12px;background:#fff;color:#22366F;'
        + 'border:2px solid #dbe0ec;border-radius:10px;padding:14px 16px;font-size:15px;font-weight:600;'
        + 'cursor:pointer;margin-bottom:10px;">'
        + '<i class="bi bi-images" style="font-size:22px;"></i>'
        + '<span style="flex:1;text-align:left;">Elegir de la galería<br>'
        + '<span style="font-size:12px;font-weight:400;color:#5b6478;">Una foto que ya tomó</span></span></button>'
        + '<button type="button" onclick="_cerrarOrigen()" '
        + 'style="width:100%;background:transparent;border:0;color:#5b6478;padding:10px;'
        + 'font-size:14px;cursor:pointer;">Cancelar</button>'
        + '</div>';
    document.body.appendChild(capa);
}

function _cerrarOrigen() {
    const c = document.getElementById('origen-foto');
    if (c) c.remove();
}
function _abrirCamara() {
    _cerrarOrigen();
    document.getElementById('rec-file-camara').click();
}
function _abrirGaleria() {
    _cerrarOrigen();
    document.getElementById('rec-file-galeria').click();
}

async function _onFotoElegida(input, desdeCamara) {
    if (!input.files || !input.files[0] || !_fotoDestino) { input.value=''; return; }
    const archivo = input.files[0];
    const destino = _fotoDestino;
    input.value = '';            // liberar el input para la próxima
    _fotoDestino = null;

    // Si el elemento necesita reparación, preguntar la parte DESPUÉS de tener la foto.
    if (destino.parteFija) {
        enviarFoto(archivo, destino, destino.parteFija, desdeCamara);
    } else if (destino.pideParte) {
        pedirParte(parte => enviarFoto(archivo, destino, parte, desdeCamara));
    } else {
        enviarFoto(archivo, destino, null, desdeCamara);
    }
}

/* Muestra un pequeño panel con botones de parte (pared, techo, piso…)
   más un campo "otra". Llama al callback con la parte elegida. */
function pedirParte(callback) {
    // Partes que se fotografían en obra de mampostería.
    const partes = ['Pared','Techo','Piso','Puerta','Ventana','Grieta','Humedad','Otra'];
    const ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(20,25,40,.55);z-index:9999;display:flex;align-items:flex-end;justify-content:center;';
    ov.innerHTML = `
      <div style="background:#fff;width:100%;max-width:480px;border-radius:16px 16px 0 0;padding:18px 18px 26px;">
        <div style="font-weight:700;color:#22366F;font-size:15px;margin-bottom:4px;">¿Qué parte muestra la foto?</div>
        <div style="font-size:12px;color:#767c94;margin-bottom:12px;">Toque una opción</div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
          ${partes.map(p=>`<button type="button" class="pp-btn" data-p="${p}" style="flex:1;min-width:90px;padding:12px;border:1px solid #d4d9e6;border-radius:10px;background:#f7f9fd;font-size:14px;font-weight:600;color:#2a3140;">${p}</button>`).join('')}
        </div>
        <input type="text" id="pp-otra" placeholder="Especifique si eligió Otra…" style="width:100%;margin-top:10px;padding:11px;border:1px solid #d4d9e6;border-radius:10px;font-size:14px;display:none;">
        <button type="button" id="pp-cancel" style="width:100%;margin-top:12px;padding:11px;border:0;border-radius:10px;background:#eef0f5;color:#55617f;font-size:14px;">Cancelar</button>
      </div>`;
    document.body.appendChild(ov);

    ov.querySelectorAll('.pp-btn').forEach(b => b.onclick = () => {
        if (b.dataset.p === 'Otra') {
            const inp = ov.querySelector('#pp-otra');
            inp.style.display = 'block'; inp.focus();
            inp.onkeydown = (e) => { if (e.key==='Enter' && inp.value.trim()) { document.body.removeChild(ov); callback(inp.value.trim()); } };
        } else {
            document.body.removeChild(ov);
            callback(b.dataset.p);
        }
    });
    ov.querySelector('#pp-cancel').onclick = () => document.body.removeChild(ov);
}

/**
 * Comprime una foto antes de guardarla o subirla.
 *
 * Las cámaras de los teléfonos sacan fotos de 3–8 MB. Sin comprimir,
 * un edificio de 100 apartamentos con varias fotos por ambiente son
 * cientos de MB que el técnico paga de su plan de datos, que le drenan
 * la batería y que con mala señal tardan muchísimo (y fallan a la mitad).
 *
 * Se reduce el lado mayor a 1600 px y se guarda como JPEG al 72 %. Una
 * foto de 5 MB baja a ~250–400 KB: 10–20 veces menos, sin perder el
 * detalle que hace falta para evaluar un daño.
 *
 * Es a prueba de fallos: si algo sale mal (formato raro, sin canvas,
 * memoria), devuelve el archivo original para NUNCA perder la foto.
 */
async function comprimirFoto(archivo) {
    const MAX_LADO = 1600;
    const CALIDAD  = 0.72;
    // Formatos que el servidor acepta tal cual (sin recomprimir).
    const ACEPTADOS = ['image/jpeg', 'image/png', 'image/webp'];

    try {
        if (!archivo || !archivo.type || archivo.type.indexOf('image/') !== 0) {
            return archivo;
        }

        const yaAceptado = ACEPTADOS.indexOf(archivo.type) !== -1;

        // Si ya es pequeña Y de un formato aceptado, no vale la pena tocarla.
        if (yaAceptado && archivo.size && archivo.size < 600 * 1024) return archivo;

        const bitmap = await cargarImagen(archivo);

        // No se pudo decodificar (típico: HEIC de iPhone en un navegador
        // que no lo entiende). NO se puede devolver el original: el
        // servidor solo acepta JPEG/PNG/WEBP y lo rechazaría, dejando al
        // técnico sin poder subir la foto. Se marca el fallo para avisar.
        if (!bitmap) {
            if (!yaAceptado) {
                const err = new Error('No se pudo convertir la foto (formato ' + archivo.type + ').');
                err.formatoNoSoportado = true;
                throw err;
            }
            // Es un formato aceptado pero no se pudo decodificar para
            // reducirla: se sube tal cual (grande, pero válida).
            return archivo;
        }

        let width = bitmap.width, height = bitmap.height;
        if (width > MAX_LADO || height > MAX_LADO) {
            if (width >= height) { height = Math.round(height * MAX_LADO / width); width = MAX_LADO; }
            else                 { width = Math.round(width * MAX_LADO / height); height = MAX_LADO; }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width; canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return yaAceptado ? archivo : convertirOFallar(archivo);
        // Fondo blanco: si el original tenía transparencia (PNG), al pasar
        // a JPEG no queda negra.
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(bitmap, 0, 0, width, height);
        if (bitmap.close) { try { bitmap.close(); } catch (e) {} }

        const blob = await new Promise(res => {
            try { canvas.toBlob(res, 'image/jpeg', CALIDAD); }
            catch (e) { res(null); }
        });
        if (!blob || blob.size === 0) {
            // No se pudo generar el JPEG. Si el original ya era aceptado,
            // se usa; si no (HEIC), se avisa.
            if (yaAceptado) return archivo;
            const err = new Error('No se pudo procesar la foto.');
            err.formatoNoSoportado = true;
            throw err;
        }

        // Si la "comprimida" pesa más que el original Y el original ya era
        // un formato aceptado, quedarse con el original.
        if (yaAceptado && archivo.size && blob.size >= archivo.size) return archivo;

        const base = (archivo.name || 'foto.jpg').replace(/\.(png|webp|heic|heif|jpeg|jpg)$/i, '');
        return new File([blob], base + '.jpg',
            { type: 'image/jpeg', lastModified: Date.now() });
    } catch (e) {
        if (e && e.formatoNoSoportado) throw e;   // se maneja arriba
        console.warn('No se pudo comprimir la foto, se usa el original:', e);
        return archivo;
    }
}

/** Último intento de convertir un formato no aceptado; si no, lanza. */
function convertirOFallar(archivo) {
    const err = new Error('No se pudo convertir la foto.');
    err.formatoNoSoportado = true;
    throw err;
}

/** Decodifica un archivo de imagen a algo que el canvas pueda dibujar. */
async function cargarImagen(archivo) {
    // Se prueba primero con <img>: en iOS decodifica HEIC nativo, cosa
    // que createImageBitmap no siempre hace. Si <img> falla, se intenta
    // createImageBitmap como respaldo (más rápido en fotos grandes).
    const porImg = await new Promise(resolve => {
        const url = URL.createObjectURL(archivo);
        const img = new Image();
        img.onload = () => {
            URL.revokeObjectURL(url);
            // Algunos navegadores "cargan" pero sin dimensiones: no sirve.
            if (img.naturalWidth > 0 && img.naturalHeight > 0) resolve(img);
            else resolve(null);
        };
        img.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
        img.src = url;
    });
    if (porImg) return porImg;

    if (window.createImageBitmap) {
        try { return await createImageBitmap(archivo); }
        catch (e) { /* formato no soportado: se rinde */ }
    }
    return null;
}

async function enviarFoto(archivo, destino, parte, desdeCamara) {
    const cont = destino.cont;

    // Comprimir ANTES de respaldar y encolar: así el respaldo local, la
    // cola y la subida usan todos la versión ligera. Un solo punto.
    try {
        archivo = await comprimirFoto(archivo);
    } catch (e) {
        if (e && e.formatoNoSoportado) {
            // Típico en iPhone: la foto es HEIC y el navegador no la pudo
            // convertir. El servidor no la aceptaría. Se avisa claro y NO
            // se encola, para no llenar la cola de fotos que serán
            // rechazadas. La solución del lado del técnico es cambiar el
            // formato de cámara del iPhone a "Más compatible".
            alert('Esta foto está en un formato (HEIC) que no se pudo convertir '
                + 'en este teléfono.\n\nEn iPhone: Ajustes → Cámara → Formatos → '
                + '"Más compatible", y vuelva a tomarla.');
            return;
        }
        console.warn('Fallo al comprimir, se intenta con el original:', e);
    }

    // RESPALDO en el teléfono antes de intentar subirla.
    // Es imprescindible en las de CÁMARA: esas no quedan en la galería
    // por sí solas, así que si falla la subida se perderían.
    // Las de galería ya están en el teléfono, pero se respaldan igual
    // para poder reintentar sin volver a buscarlas.
    // El respaldo NO debe bloquear la subida: si IndexedDB está lento o
    // bloqueado, la foto tiene que enviarse igual.
    let idLocal = null;
    if (window.ObrasFotos) {
        try {
            idLocal = await Promise.race([
                ObrasFotos.respaldar(archivo, {
                    inspeccion_id: INSPECCION_ID, nivel: destino.nivel, ref_id: destino.refId,
                    parte: parte || '', origen: desdeCamara ? 'camara' : 'galeria',
                    descripcion: (parte ? parte + ' · ' : '') + destino.nivel + ' #' + destino.refId,
                }),
                new Promise(r => setTimeout(() => r(null), 3000)),
            ]);
        } catch (e) {
            console.warn('No se pudo respaldar la foto localmente:', e);
        }
    }

    const fd = new FormData();
    fd.append('nivel', destino.nivel);
    fd.append('ref_id', destino.refId);
    if (parte) fd.append('parte', parte);
    fd.append('foto', archivo);

    // Foto de un ambiente creado sin conexión: todavía no existe en el
    // servidor, así que se guarda indicando a qué apartamento pertenece
    // y qué posición ocupa. Al sincronizar se asocia al ambiente real.
    if (destino.nivel === 'ambiente_local') {
        await ObrasOffline.encolar('foto_ambiente_pendiente', URL_BASE + 'subir_foto_rec.php',
            { apartamento_id: destino.aptoId, ambiente_local: destino.refId,
              etiqueta: destino.etiqueta, parte: parte || 'antes',
              foto: archivo, nombre_archivo: archivo.name || 'foto.jpg' },
            'Foto · ' + destino.etiqueta + ' (apto ' + destino.aptoId + ')');
        if (cont) {
            cont.insertAdjacentHTML('beforeend',
                '<span style="font-size:11px;color:#8a6d1a;background:#fffbf0;'
                + 'border:1px solid #C9A22755;border-radius:6px;padding:2px 7px;">'
                + '<i class="bi bi-phone-fill"></i> 1</span>');
        }
        return;
    }

    // Sin señal: queda en cola y se sube después.
    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('foto', URL_BASE + 'subir_foto_rec.php',
            { nivel: destino.nivel, ref_id: destino.refId, parte: parte || '',
              foto: archivo, nombre_archivo: archivo.name || 'foto.jpg' },
            'Foto ' + (parte || '') + ' · ' + destino.nivel + ' #' + destino.refId);
        // La foto se muestra igual que si se hubiera subido: la
        // validación cuenta imágenes, no textos.
        if (cont) miniFotoPendiente(cont, archivo, parte);
        return;
    }

    if (cont) cont.insertAdjacentHTML('beforeend', '<span class="subiendo">Subiendo…</span>');
    console.log('Subiendo foto:', {
        nivel: destino.nivel, ref_id: destino.refId, parte: parte,
        peso_kb: Math.round((archivo.size || 0) / 1024),
    });
    try {
        const res = await fetch(URL_BASE + 'subir_foto_rec.php',
            { method:'POST', body: fd, credentials:'same-origin' });
        const texto = await res.text();
        if (cont) cont.querySelector('.subiendo')?.remove();
        let data;
        try { data = JSON.parse(texto); }
        catch (e) {
            // Respuesta inesperada (sesión caída, error): no perder la foto.
            if (window.ObrasOffline) {
                await ObrasOffline.encolar('foto', URL_BASE + 'subir_foto_rec.php',
                    { nivel: destino.nivel, ref_id: destino.refId, parte: parte || '',
                      foto: archivo, nombre_archivo: archivo.name || 'foto.jpg' },
                    'Foto ' + (parte || '') + ' · ' + destino.nivel + ' #' + destino.refId);
                if (cont) miniFotoPendiente(cont, archivo, parte);
                alert('El servidor no respondió bien.\n\nLa foto quedó guardada en el teléfono y se subirá después.');
            } else {
                alert('El servidor respondió algo inesperado. La foto está guardada en el teléfono.');
            }
            return;
        }
        if (data.ok) {
            if (cont) agregarMiniFoto(cont, data.foto);
            if (idLocal && window.ObrasFotos) ObrasFotos.marcarSubida(idLocal);
        } else {
            // Mostrar el motivo real: antes fallaba sin decir por qué.
            console.error('Subida rechazada:', data);
            alert('No se pudo guardar la foto.\n\n'
                + (data.mensaje || 'El servidor la rechazó sin indicar el motivo.'));
        }
    } catch(e) {
        if (cont) cont.querySelector('.subiendo')?.remove();
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('foto', URL_BASE + 'subir_foto_rec.php',
                { nivel: destino.nivel, ref_id: destino.refId, parte: parte || '',
                  foto: archivo, nombre_archivo: archivo.name || 'foto.jpg' },
                'Foto ' + (parte || '') + ' · ' + destino.nivel + ' #' + destino.refId);
            // Se muestra la foto real, no un texto: la validación
            // cuenta imágenes para saber si el ambiente está completo.
            if (cont) miniFotoPendiente(cont, archivo, parte);
        } else {
            alert('Se perdió la conexión.\n\nLa foto está guardada en el teléfono.');
        }
    }
}

/**
 * Muestra la foto que quedó en el teléfono esperando señal.
 *
 * Es importante que sea un <img> real: la validación cuenta las
 * imágenes para saber si el ambiente tiene foto. Antes se ponía un
 * texto y el sistema decía que faltaba la foto aunque estuviera.
 */
function miniFotoPendiente(cont, archivo, parte) {
    if (!cont) return;
    const url = URL.createObjectURL(archivo);
    const et = parte
        ? '<div style="font-size:10px;color:#8a6d1a;text-align:center;">' + parte + '</div>'
        : '';
    cont.insertAdjacentHTML('beforeend',
        '<div style="text-align:center;position:relative;" class="foto-pendiente">'
        + '<img src="' + url + '" alt="Foto guardada en el teléfono" '
        + 'style="width:86px;height:86px;object-fit:cover;border-radius:7px;'
        + 'border:2px solid #C9A227;">'
        + '<span style="position:absolute;top:3px;right:3px;background:#C9A227;'
        + 'color:#22366F;font-size:9px;font-weight:700;padding:1px 5px;'
        + 'border-radius:8px;">En el teléfono</span>'
        + et + '</div>');
}

function agregarMiniFoto(cont, f) {
    const parte = f.parte
        ? '<div style="font-size:10px;color:#55617f;text-align:center;">' + f.parte + '</div>' : '';
    const alt = (f.parte || 'Foto').replace(/"/g, '&quot;').replace(/'/g, '');
    cont.insertAdjacentHTML('beforeend',
        '<div style="text-align:center;">'
        + '<img src="' + f.ruta + '" title="Toque para ampliar" '
        + 'style="width:86px;height:86px;object-fit:cover;border-radius:7px;'
        + 'border:1px solid #d8dce6;cursor:zoom-in;transition:transform .12s;" '
        + 'onmouseover="this.style.transform=\'scale(1.06)\'" '
        + 'onmouseout="this.style.transform=\'\'" '
        + 'onclick="ampliarFoto(\'' + f.ruta + '\', \'' + alt + '\')">'
        + parte + '</div>');
}

/**
 * Visor a pantalla completa para revisar las fotos del levantamiento.
 * Permite acercar hasta 4 aumentos y descargar la imagen.
 */
function ampliarFoto(ruta, titulo) {
    const capa = document.createElement('div');
    capa.id = 'lev-visor';
    capa.style.cssText = 'position:fixed;inset:0;background:rgba(10,14,24,.94);z-index:3000;'
        + 'display:flex;flex-direction:column;';

    capa.innerHTML = `
        <div style="display:flex;align-items:center;gap:11px;padding:12px 16px;
                    background:rgba(0,0,0,.35);color:#fff;flex-shrink:0;">
            <div style="flex:1;min-width:0;font-weight:700;font-size:15px;">${titulo || 'Foto'}</div>
            <button onclick="zoomLev(-1)" title="Alejar"
                    style="background:rgba(255,255,255,.15);border:0;color:#fff;width:38px;height:38px;
                           border-radius:9px;font-size:19px;cursor:pointer;">−</button>
            <button onclick="zoomLev(1)" title="Acercar"
                    style="background:rgba(255,255,255,.15);border:0;color:#fff;width:38px;height:38px;
                           border-radius:9px;font-size:19px;cursor:pointer;">+</button>
            <a href="${ruta}" download title="Descargar"
               style="background:rgba(255,255,255,.15);color:#fff;width:38px;height:38px;
                      border-radius:9px;display:flex;align-items:center;justify-content:center;
                      text-decoration:none;"><i class="bi bi-download"></i></a>
            <button onclick="cerrarVisorLev()" title="Cerrar"
                    style="background:rgba(255,255,255,.15);border:0;color:#fff;width:38px;height:38px;
                           border-radius:9px;font-size:22px;cursor:pointer;line-height:1;">&times;</button>
        </div>
        <div id="lev-visor-cont" style="flex:1;overflow:auto;display:flex;align-items:center;
                                        justify-content:center;padding:14px;">
            <img id="lev-visor-img" src="${ruta}" style="max-width:100%;max-height:100%;
                 transition:transform .18s;transform-origin:center;">
        </div>
        <div style="padding:9px 16px;background:rgba(0,0,0,.35);color:#ffffffaa;
                    font-size:12px;text-align:center;flex-shrink:0;">
            Toque + o − para acercar · Toque fuera de la imagen para cerrar
        </div>`;

    capa.addEventListener('click', e => {
        if (e.target === capa || e.target.id === 'lev-visor-cont') cerrarVisorLev();
    });
    document.body.appendChild(capa);
    window._zoomLev = 1;
    document.addEventListener('keydown', _escLev);
}

function _escLev(e) { if (e.key === 'Escape') cerrarVisorLev(); }

function cerrarVisorLev() {
    const v = document.getElementById('lev-visor');
    if (v) v.remove();
    document.removeEventListener('keydown', _escLev);
}

function zoomLev(dir) {
    const img = document.getElementById('lev-visor-img');
    if (!img) return;
    window._zoomLev = Math.min(4, Math.max(0.5, (window._zoomLev || 1) + dir * 0.35));
    img.style.transform = 'scale(' + window._zoomLev + ')';
}

// ================= PASO 3: CIERRE Y RESUMEN =================
// Muestra la foto solo si el estado es "Requiere reparación".
function onEstadoCierre(key) {
    const sel = document.querySelector('input[name="'+key+'_estado"]:checked');
    const foto = document.getElementById('cierre-foto-' + key);
    if (foto) foto.style.display = (sel && sel.value === 'Requiere reparación') ? 'block' : 'none';
}

// Subir foto del área de cierre (azotea/tanques) que requiere reparación.
function subirFotoCierre(key, btn) {
    elegirOrigenFoto({
        nivel:'edificio', refId: EDIFICIO_ID, pideParte:false, parteFija: key + '_reparacion',
        cont: btn.parentElement.querySelector('.cierre-fotos')
    });
}

async function guardarCierre(ev) {
    ev.preventDefault();
    if (!PUEDE_EDITAR) return false;
    const form = document.getElementById('form-cierre');

    // La azotea y los tanques son parte del levantamiento: sin ellos
    // el edificio queda a medias y hay que volver a subir.
    const faltaCierre = [];
    ['azotea','tanques'].forEach(k => {
        if (!form.querySelector('input[name="'+k+'_estado"]:checked')) {
            faltaCierre.push(k === 'azotea' ? '· El estado de la azotea'
                                            : '· El estado de los tanques de agua');
        }
    });
    if (faltaCierre.length) {
        alert('Falta registrar:\n\n' + faltaCierre.join('\n'));
        return false;
    }

    // Las áreas comunes marcadas para reparar necesitan su trabajo y metros.
    const faltaArea = [];
    document.querySelectorAll('.area-row').forEach(row => {
        const chk = row.querySelector('.area-reparar');
        if (!chk || !chk.checked) return;

        const lbl = row.querySelector('.area-chk-lbl span');
        const nom = lbl ? lbl.textContent.trim() : 'un área común';

        const selT = row.querySelector('.area-trabajo');

        // Los metros se suman de los campos reales, no del campo oculto:
        // ese solo se rellena cuando corre calcularMatArea(), y si el
        // técnico escribió los metros sin que se disparara (o la fila se
        // restauró de un borrador), quedaba vacío y el cierre se bloqueaba
        // aunque los datos estuvieran completos.
        let m2Area = 0;
        row.querySelectorAll('.area-sup').forEach(i => { m2Area += aNumero(i.value); });

        // Un trabajo adicional con sus metros también vale: el área puede
        // tener todo cargado en la partida extra.
        let m2Extra = 0;
        let hayTrabajoExtra = false;
        row.querySelectorAll('.partida-area').forEach(bl => {
            const st = bl.querySelector('.part-area-trabajo');
            if (st && st.value) hayTrabajoExtra = true;
            bl.querySelectorAll('.part-area-m2').forEach(i => { m2Extra += aNumero(i.value); });
        });

        const hayTrabajo = (selT && selT.value) || hayTrabajoExtra;
        const hayMetros  = (m2Area + m2Extra) > 0;

        if (!hayTrabajo) faltaArea.push('· ' + nom + ': qué trabajo hacer');
        if (!hayMetros)  faltaArea.push('· ' + nom + ': los metros');
    });
    if (faltaArea.length) {
        alert('En las áreas comunes falta:\n\n' + faltaArea.join('\n')
            + '\n\nComplételo en el paso 1, o desmarque el área si no hay daño.');
        irPaso(1);
        return false;
    }

    const payload = { inspeccion_id: INSPECCION_ID, accion:'cierre' };
    ['azotea','tanques'].forEach(k => {
        const sel = form.querySelector('input[name="'+k+'_estado"]:checked');
        payload[k+'_estado'] = sel ? sel.value : '';
        const obs = form.querySelector('input[name="'+k+'_obs"]');
        payload[k+'_obs'] = obs ? obs.value : '';
    });
    // Impermeabilización: es una condición de la azotea (sí/no). Marcado
    // guarda "Requiere"; sin marcar queda vacío. Es opcional.
    const chkImper = document.getElementById('req-impermeabilizacion');
    payload.impermeabilizacion_estado = (chkImper && chkImper.checked) ? 'Requiere' : '';
    payload.fecha_inicio_estimada = form.querySelector('input[name="fecha_inicio_estimada"]').value;
    payload.fecha_fin_estimada = form.querySelector('input[name="fecha_fin_estimada"]').value;

    // Copia local del cierre, por si falla el envío.
    guardarBorrador('cierre_' + INSPECCION_ID, payload);

    if (window.ObrasOffline && !navigator.onLine) {
        await ObrasOffline.encolar('cierre', URL_BASE + 'guardar_rec_edificio.php', payload,
            'Cierre del levantamiento');
        alert('Sin señal: el cierre quedó guardado en el teléfono y se enviará al '
            + 'recuperar la conexión.\n\nSi al enviarse falta algún dato, el sistema '
            + 'se lo mostrará para completarlo. Nada se pierde.');
        ofrecerComprobante();
        return false;
    }

    try {
        const res = await fetch(URL_BASE + 'guardar_rec_edificio.php', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload), credentials:'same-origin'
        });
        const texto = await res.text();
        let data;
        try { data = JSON.parse(texto); }
        catch (e) {
            if (window.ObrasOffline) {
                await ObrasOffline.encolar('cierre', URL_BASE + 'guardar_rec_edificio.php', payload,
                    'Cierre del levantamiento');
                alert('El servidor no respondió bien. El cierre quedó guardado y se reintentará.');
            }
            return false;
        }
        if (data.ok) {
            borrarBorrador('cierre_' + INSPECCION_ID);
            cargarResumen();
            ofrecerComprobante();
        } else if (Array.isArray(data.faltantes) && data.faltantes.length) {
            // Faltan datos. NO se cerró y NO se borró nada: se guía al
            // técnico punto por punto para que complete cada reparación.
            // El cierre ya guardó lo que se pudo, así que la barra se
            // actualiza para reflejar el avance real.
            refrescarProgreso();
            mostrarGuiaFaltantes(data.faltantes);
        } else {
            alert(data.mensaje || 'Error al guardar.');
        }
    } catch (e) {
        if (window.ObrasOffline) {
            await ObrasOffline.encolar('cierre', URL_BASE + 'guardar_rec_edificio.php', payload,
                'Cierre del levantamiento');
            alert('Se perdió la conexión. El cierre quedó guardado en el teléfono.');
            ofrecerComprobante();
        } else {
            alert('Se perdió la conexión. Intente cerrar de nuevo cuando tenga señal.');
        }
    }
    return false;
}

/**
 * Al cerrar, ofrece descargar el comprobante en PDF.
 * Queda en el teléfono como respaldo de todo lo registrado.
 */

/**
 * Guía de datos faltantes al intentar cerrar.
 *
 * En lugar de un alert con toda la lista (que el técnico no puede seguir
 * y que asusta como si se hubiera borrado algo), muestra un panel fijo
 * con cada reparación incompleta y un botón "Ir" que lo lleva justo a
 * ese apartamento o área. NADA se borra: el levantamiento sigue igual,
 * solo falta completar estos puntos.
 */
let _faltantesPendientes = [];

function mostrarGuiaFaltantes(faltantes) {
    _faltantesPendientes = faltantes.slice();

    // Quitar un panel anterior si lo hubiera.
    const viejo = document.getElementById('guia-faltantes');
    if (viejo) viejo.remove();

    const cont = document.createElement('div');
    cont.id = 'guia-faltantes';
    cont.style.cssText =
        'position:fixed;left:0;right:0;bottom:0;z-index:9999;'
        + 'background:#fff;border-top:3px solid #C9A227;'
        + 'box-shadow:0 -8px 24px rgba(0,0,0,.18);'
        + 'max-height:62vh;display:flex;flex-direction:column;';

    let filas = '';
    faltantes.forEach((f, i) => {
        const falta = (f.falta || []).join(', ');
        filas +=
            '<div class="gf-item" data-idx="' + i + '" '
            + 'style="display:flex;align-items:center;gap:10px;padding:11px 14px;'
            + 'border-bottom:1px solid #f0f2f7;">'
            + '<span style="flex-shrink:0;width:22px;height:22px;border-radius:50%;'
            + 'background:#A61C1C;color:#fff;font-size:12px;font-weight:700;'
            + 'display:flex;align-items:center;justify-content:center;">' + (i + 1) + '</span>'
            + '<div style="flex:1;min-width:0;">'
            + '<div style="font-weight:600;font-size:13px;color:#2a3140;">' + escHtml(f.donde) + '</div>'
            + '<div style="font-size:11.5px;color:#A61C1C;">Falta: ' + escHtml(falta) + '</div>'
            + '</div>'
            + '<button type="button" class="btn btn-primary btn-sm" '
            + 'style="flex-shrink:0;" onclick="irAFaltante(' + i + ')">Ir <i class="bi bi-arrow-right"></i></button>'
            + '</div>';
    });

    cont.innerHTML =
        '<div style="display:flex;align-items:center;justify-content:space-between;'
        + 'padding:12px 14px;border-bottom:1px solid #eef0f5;">'
        + '<div style="font-weight:800;color:#22366F;font-size:14px;">'
        + '<i class="bi bi-list-check"></i> Faltan ' + faltantes.length + ' por completar</div>'
        + '<button type="button" onclick="cerrarGuiaFaltantes()" '
        + 'style="border:0;background:none;font-size:20px;color:#767c94;cursor:pointer;">&times;</button>'
        + '</div>'
        + '<div style="padding:8px 14px;background:#fbf8ef;font-size:12px;color:#8a6d1a;">'
        + '<i class="bi bi-shield-check"></i> Tranquilo: no se borró nada. '
        + 'Toque <b>Ir</b> en cada punto, complete lo que falta y vuelva a cerrar.'
        + '</div>'
        + '<div style="overflow-y:auto;flex:1;">' + filas + '</div>';

    document.body.appendChild(cont);
    // Espacio para que el panel no tape el contenido al final.
    document.body.style.paddingBottom = '62vh';
}

function cerrarGuiaFaltantes() {
    const c = document.getElementById('guia-faltantes');
    if (c) c.remove();
    document.body.style.paddingBottom = '';
}

/** Lleva la pantalla justo al punto que le falta datos. */
async function irAFaltante(idx) {
    const f = _faltantesPendientes[idx];
    if (!f) return;

    // Datos básicos del edificio: están en el Paso 1.
    if (f.tipo === 'edificio') {
        irPaso(1);
        setTimeout(() => {
            const paso = document.getElementById('paso-1');
            if (paso) paso.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 200);
        return;
    }

    // Cierre (azotea, tanques, impermeabilización): está en el Paso 3.
    if (f.tipo === 'cierre') {
        irPaso(3);
        setTimeout(() => {
            const form = document.getElementById('form-cierre');
            if (form) form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 200);
        return;
    }

    // Apartamento sin atender: llevar a su piso en el Paso 2.
    if (f.tipo === 'apartamento') {
        irPaso(2);
        const sel = document.getElementById('selector-piso');
        if (sel && f.piso_id) {
            sel.value = f.piso_id;
            mostrarPisoSeleccionado();
        }
        const card = await esperarApto(f.apto_id, f.apto_ident);
        if (!card) {
            alert('Abra el piso ' + (f.piso_numero || '') + ' y busque el apto '
                + (f.apto_ident || '') + ' para registrarlo o marcar la visita.');
            return;
        }
        const body = card.querySelector('.apto-body');
        if (body && body.classList.contains('hidden')) {
            const head = card.querySelector('.apto-head');
            if (head) head.click();
        }
        resaltar(card);
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }

    if (f.tipo === 'area_comun') {
        // Las áreas comunes están en el Paso 1.
        irPaso(1);
        setTimeout(() => {
            const row = document.querySelector('.area-row[data-area="' + f.area_tipo + '"]');
            if (row) {
                const chk = row.querySelector('.area-reparar');
                if (chk && !chk.checked) chk.checked = true;
                const det = row.querySelector('.area-detalle');
                if (det) det.style.display = 'block';
                resaltar(row);
                row.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }, 250);
        return;
    }

    if (f.tipo === 'local') {
        // Los locales están en su panel del Paso 2.
        irPaso(2);
        try { await cargarLocales(); } catch (e) {}
        const card = await esperarApto(f.apto_id, f.apto_ident);
        if (!card) {
            alert('Abra el panel de locales comerciales y busque ' + (f.apto_ident || '')
                + ' para completar los datos.');
            return;
        }
        const body = card.querySelector('.apto-body');
        if (body && body.classList.contains('hidden')) {
            const head = card.querySelector('.apto-head');
            if (head) head.click();
        }
        setTimeout(() => {
            const amb = card.querySelector('.amb-row[data-amb="' + f.ambiente_id + '"]');
            const destino = amb || card;
            resaltar(destino);
            destino.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 300);
        return;
    }

    // Ambiente de apartamento: está en el Paso 2, dentro de su piso.
    irPaso(2);

    // Seleccionar el piso correcto y esperar a que carguen sus aptos.
    const sel = document.getElementById('selector-piso');
    if (sel && f.piso_id) {
        sel.value = f.piso_id;
        mostrarPisoSeleccionado();
    }

    // El piso carga sus apartamentos por red; se espera a que aparezca
    // la tarjeta del apartamento buscado (hasta ~3 s).
    const card = await esperarApto(f.apto_id, f.apto_ident);
    if (!card) {
        alert('Abra el piso ' + (f.piso_numero || '') + ' y busque el apto '
            + (f.apto_ident || '') + ' para completar los datos.');
        return;
    }

    // Abrir el apartamento si está cerrado.
    const body = card.querySelector('.apto-body');
    if (body && body.classList.contains('hidden')) {
        const head = card.querySelector('.apto-head');
        if (head) head.click();
    }

    setTimeout(() => {
        const amb = card.querySelector('.amb-row[data-amb="' + f.ambiente_id + '"]');
        const destino = amb || card;
        resaltar(destino);
        destino.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 300);
}

/** Espera a que exista la tarjeta de un apartamento tras cargar el piso. */
function esperarApto(aptoId, ident, intentos = 15) {
    return new Promise(resolve => {
        const buscar = () => {
            let card = aptoId
                ? document.querySelector('.apto-card[data-apto-id="' + aptoId + '"]')
                : null;
            if (!card && ident) {
                card = Array.from(document.querySelectorAll('.apto-card'))
                    .find(c => (c.dataset.ident || '') === String(ident)) || null;
            }
            if (card) return resolve(card);
            if (--intentos <= 0) return resolve(null);
            setTimeout(buscar, 200);
        };
        buscar();
    });
}

/** Resalta un momento el bloque al que se saltó, para ubicarlo rápido. */
function resaltar(el) {
    if (!el) return;
    const antes = el.style.boxShadow;
    el.style.transition = 'box-shadow .3s';
    el.style.boxShadow = '0 0 0 3px #C9A227';
    setTimeout(() => { el.style.boxShadow = antes; }, 1800);
}

/** Escape mínimo para el texto que va al panel. */
function escHtml(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/**
 * Comprobante generado EN EL TELÉFONO, sin necesidad de servidor.
 * Abre una ventana lista para imprimir o guardar como PDF.
 * Es la constancia de lo registrado cuando se trabajó sin señal.
 */
function comprobanteLocal() {
    const est = window._estructuraLocal
        || JSON.parse(localStorage.getItem('estructura_' + INSPECCION_ID) || 'null');

    const ahora = new Date();
    const fecha = ahora.toLocaleDateString('es-VE');
    const hora  = ahora.toLocaleTimeString('es-VE', {hour:'2-digit', minute:'2-digit'});

    let totApt = 0, totJefes = 0, totAmb = 0;
    let filas = '';

    if (est && est.pisos) {
        est.pisos.forEach(p => {
            const aptos = p.apartamentos || [];
            if (!aptos.length) return;
            filas += '<tr><td colspan="6" style="background:#eef2fb;font-weight:700;color:#22366F;'
                + 'padding:7px 6px;">Piso ' + p.numero_piso + '</td></tr>';
            aptos.forEach(a => {
                totApt++;
                if (a.jefe_nombre) totJefes++;
                const amb = (parseInt(a.num_habitaciones)||0) + (parseInt(a.num_salas)||0)
                          + (parseInt(a.num_banos)||0) + (parseInt(a.num_cocinas)||0)
                          + (parseInt(a.num_balcones)||0);
                totAmb += amb;
                filas += '<tr>'
                    + '<td style="font-weight:700;color:#22366F;">' + escHtml(a.identificador||'') + '</td>'
                    + '<td>' + escHtml(a.jefe_nombre || '— sin registrar —') + '</td>'
                    + '<td>' + escHtml(a.jefe_cedula || '—') + '</td>'
                    + '<td>' + escHtml(a.jefe_telefono || '—') + '</td>'
                    + '<td style="text-align:center;">' + amb + '</td>'
                    + '<td style="text-align:center;color:#8a6d1a;font-size:10px;">pendiente</td>'
                    + '</tr>';
            });
        });
    }

    if (!filas) {
        alert('Todavía no hay apartamentos registrados para incluir en el comprobante.');
        return;
    }

    const aviso = totJefes < totApt
        ? '<div style="background:#fffbf0;border:1px solid #C9A22755;border-radius:7px;'
          + 'padding:8px 11px;font-size:11px;color:#8a6d1a;margin-bottom:10px;">'
          + '<b>Atención:</b> ' + (totApt - totJefes) + ' apartamento(s) sin datos del jefe de familia.</div>'
        : '';

    const html = '<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">'
        + '<title>Comprobante del levantamiento</title><style>'
        + '*{font-family:Arial,sans-serif;box-sizing:border-box;}'
        + 'body{margin:24px;color:#1a1f2b;font-size:12px;}'
        + '.cab{border-bottom:3px solid #C9A227;padding-bottom:12px;margin-bottom:14px;}'
        + '.cab h1{margin:0;font-size:21px;color:#22366F;}'
        + '.cab .sub{color:#55617f;font-size:12px;margin-top:3px;}'
        + '.cab .folio{float:right;text-align:right;font-size:11px;color:#55617f;}'
        + 'h2{font-size:12px;text-transform:uppercase;color:#22366F;margin:15px 0 7px;'
        + 'padding-bottom:4px;border-bottom:1px solid #e8ebf3;}'
        + 'table{width:100%;border-collapse:collapse;}'
        + 'th{background:#22366F;color:#fff;font-size:10px;padding:6px 5px;text-align:left;text-transform:uppercase;}'
        + 'td{font-size:10.5px;padding:5px;border-bottom:1px solid #e8ebf3;}'
        + '.datos td{padding:4px 6px;font-size:11.5px;}'
        + '.datos .lbl{color:#55617f;width:130px;}'
        + '.res{display:table;width:100%;border-spacing:6px;margin-bottom:8px;}'
        + '.rc{display:table-cell;text-align:center;padding:10px 6px;border:1px solid #dde3ef;border-radius:8px;}'
        + '.rc .n{font-size:20px;font-weight:800;color:#22366F;}'
        + '.rc .l{font-size:9px;text-transform:uppercase;color:#55617f;}'
        + '.nota{background:#f4f7fd;border-radius:8px;padding:9px 12px;font-size:11px;color:#3a4256;margin-bottom:12px;}'
        + '.firma{margin-top:26px;display:table;width:100%;border-spacing:20px;}'
        + '.firma div{display:table-cell;width:50%;border-top:1px solid #2a3140;padding-top:5px;'
        + 'font-size:10.5px;color:#55617f;text-align:center;}'
        + '@media print{.noprint{display:none;}}'
        + '</style></head><body>'
        + '<div class="cab"><div class="folio">' + fecha + '<br>' + hora + '</div>'
        + '<h1>Levantamiento técnico</h1>'
        + '<div class="sub">Gestión de Obras Avanzadas · Constancia registrada sin conexión</div></div>'
        + '<div class="nota"><b>Este comprobante se generó en el teléfono, sin conexión.</b> '
        + 'Los datos están guardados en el dispositivo y se enviarán al sistema al recuperar la señal. '
        + 'Consérvelo como respaldo de lo registrado.</div>'
        + '<h2>Edificación</h2>'
        + '<table class="datos">'
        + '<tr><td class="lbl">Nombre</td><td><b>' + (EDIFICIO_NOMBRE || '—') + '</b></td>'
        + '<td class="lbl">Código</td><td><b>' + (EDIFICIO_CODIGO || '—') + '</b></td></tr>'
        + '<tr><td class="lbl">Parroquia</td><td><b>' + (EDIFICIO_PARROQUIA || '—') + '</b></td>'
        + '<td class="lbl">Pisos</td><td><b>' + (est ? est.pisos.length : 0) + '</b></td></tr>'
        + '</table>'
        + '<h2>Resumen de lo registrado</h2>'
        + '<div class="res">'
        + '<div class="rc"><div class="n">' + (est ? est.pisos.length : 0) + '</div><div class="l">Pisos</div></div>'
        + '<div class="rc"><div class="n">' + totApt + '</div><div class="l">Apartamentos</div></div>'
        + '<div class="rc"><div class="n">' + totJefes + '</div><div class="l">Jefes de familia</div></div>'
        + '<div class="rc"><div class="n">' + totAmb + '</div><div class="l">Ambientes</div></div>'
        + '</div>' + aviso
        + '<h2>Detalle</h2>'
        + '<table><thead><tr><th style="width:52px;">Apto</th><th>Jefe de familia</th>'
        + '<th style="width:86px;">Cédula</th><th style="width:92px;">Teléfono</th>'
        + '<th style="width:60px;">Ambientes</th><th style="width:70px;">Estado</th>'
        + '</tr></thead><tbody>' + filas + '</tbody></table>'
        + '<div class="firma"><div>Firma del técnico responsable</div>'
        + '<div>Firma del supervisor</div></div>'
        + '<p class="noprint" style="margin-top:18px;text-align:center;">'
        + '<button onclick="window.print()" style="padding:10px 24px;background:#22366F;color:#fff;'
        + 'border:0;border-radius:8px;cursor:pointer;font-size:15px;font-weight:600;">'
        + 'Guardar como PDF</button></p>'
        + '<script>window.onload=function(){setTimeout(function(){window.print();},500);};<\/script>'
        + '</body></html>';

    const w = window.open('', '_blank');
    if (!w) { alert('El navegador bloqueó la ventana. Permita las ventanas emergentes e intente de nuevo.'); return; }
    w.document.write(html);
    w.document.close();
}

function ofrecerComprobante() {
    const capa = document.createElement('div');
    capa.style.cssText = 'position:fixed;inset:0;background:rgba(20,25,40,.6);z-index:2100;'
        + 'display:flex;align-items:center;justify-content:center;padding:16px;';
    capa.innerHTML =
        '<div style="background:#fff;border-radius:12px;max-width:400px;width:100%;padding:22px 24px;text-align:center;">'
        + '<div style="font-size:42px;color:#2E7D32;line-height:1;"><i class="bi bi-check-circle-fill"></i></div>'
        + '<h3 style="margin:10px 0 4px;color:#22366F;font-size:19px;">Levantamiento cerrado</h3>'
        + '<p style="font-size:13.5px;color:#5b6478;margin:0 0 16px;">'
        + 'Guarde el comprobante en su teléfono. Es la constancia de todo lo que registró, '
        + 'por si hiciera falta verificarlo.</p>'
        + (navigator.onLine
            ? '<a href="' + URL_BASE + 'comprobante_levantamiento.php?inspeccion=' + INSPECCION_ID + '" '
              + 'target="_blank" class="btn btn-primary" style="width:100%;justify-content:center;margin-bottom:8px;">'
              + '<i class="bi bi-file-earmark-pdf-fill"></i> Descargar comprobante</a>'
            : '<button onclick="comprobanteLocal()" class="btn btn-primary" '
              + 'style="width:100%;justify-content:center;margin-bottom:8px;">'
              + '<i class="bi bi-file-earmark-pdf-fill"></i> Generar comprobante</button>')
        + '<button onclick="this.closest(\'div\').parentElement.remove()" '
        + 'style="width:100%;background:transparent;border:1px solid #dbe0ec;border-radius:8px;'
        + 'padding:9px;color:#55617f;cursor:pointer;font-size:13.5px;">Ahora no</button>'
        + '</div>';
    document.body.appendChild(capa);
}

async function cargarResumen() {
    const cont = document.getElementById('resumen-materiales');
    if (!cont) return;
    cont.innerHTML = '<p class="text-muted">Calculando materiales del edificio…</p>';

    let data;
    try {
        const res = await fetch(URL_BASE + 'resumen_materiales.php?edificio_id=' + EDIFICIO_ID,
                                { credentials: 'same-origin' });
        const texto = await res.text();
        try { data = JSON.parse(texto); }
        catch (e) {
            console.error('Resumen: respuesta inesperada', texto.slice(0, 200));
            cont.innerHTML = '<p class="text-muted">No se pudo cargar el resumen.</p>';
            return;
        }
    } catch (e) {
        cont.innerHTML = '<p class="text-muted">Sin conexión para calcular el resumen.</p>';
        return;
    }

    if (!data.ok) {
        cont.innerHTML = '<p class="text-muted">' + (data.mensaje || 'No se pudo cargar el resumen.') + '</p>';
        return;
    }

    const mats = Object.entries(data.materiales || {});
    const trab = Object.entries(data.por_trabajo || {});

    let html = '<div style="border:3px solid #C9A227;border-radius:12px;overflow:hidden;">'
        + '<div style="background:#C9A227;color:#22366F;padding:13px 18px;">'
        + '<div style="font-size:17px;font-weight:800;">'
        + '<i class="bi bi-building-fill-check"></i> MATERIALES DEL EDIFICIO COMPLETO</div>'
        + '<div style="font-size:12.5px;font-weight:600;opacity:.85;margin-top:2px;">'
        + 'Suma de todos los pisos, apartamentos y áreas comunes</div></div>'
        + '<div style="padding:16px 18px;background:#fffdf5;">';

    if (data.total_m2 > 0) {
        html += '<div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:14px;">'
            + '<div style="background:#fff;border:1px solid #C9A22755;border-radius:10px;padding:12px 18px;">'
            + '<div style="font-size:26px;font-weight:800;color:#22366F;line-height:1;">'
            + Number(data.total_m2).toLocaleString('es-VE', {maximumFractionDigits:2}) + ' m²</div>'
            + '<div style="font-size:11px;color:#5b6478;text-transform:uppercase;margin-top:3px;">'
            + 'Total a reparar</div></div>';

        trab.forEach(([nombre, cant]) => {
            html += '<div style="background:#fff;border:1px solid #e5e8f0;border-radius:10px;padding:12px 15px;">'
                + '<div style="font-size:17px;font-weight:700;color:#2d4488;">'
                + Number(cant).toLocaleString('es-VE') + ' m²</div>'
                + '<div style="font-size:11.5px;color:#5b6478;">' + nombre + '</div></div>';
        });
        html += '</div>';
    }

    if (mats.length) {
        html += '<table style="width:100%;border-collapse:collapse;background:#fff;border-radius:9px;overflow:hidden;">'
            + '<tr style="background:#22366F;color:#fff;">'
            + '<th style="text-align:left;padding:9px 12px;font-size:12px;text-transform:uppercase;">Material</th>'
            + '<th style="text-align:right;padding:9px 12px;font-size:12px;text-transform:uppercase;">Cantidad</th></tr>';
        mats.forEach(([m, c], i) => {
            // La clave trae la unidad entre parentesis: "Cemento gris (saco)".
            const uniM = (m.match(/\(([^)]+)\)\s*$/) || [,'kg'])[1].trim();
            const badgeM = badgeSacosCementoGrisJS(m, c, uniM);
            html += '<tr style="background:' + (i % 2 ? '#f7f9fd' : '#fff') + ';">'
                + '<td style="padding:8px 12px;font-size:13.5px;">' + m + '</td>'
                + '<td style="padding:8px 12px;text-align:right;font-weight:700;color:#22366F;font-size:14px;">'
                + Number(c).toLocaleString('es-VE')
                + (badgeM ? '<br>' + badgeM : '') + '</td></tr>';
        });
        html += '</table>'
            + '<div style="font-size:11.5px;color:#8a6d1a;margin-top:9px;">'
            + '<i class="bi bi-info-circle"></i> Incluye 10% de holgura por desperdicio. '
            + 'Verifique en obra antes de solicitar.</div>';
    } else if (data.total_m2 > 0) {
        html += '<div style="background:#fff;border:1px solid #C9A22755;border-radius:9px;'
            + 'padding:12px 15px;font-size:13px;color:#8a6d1a;">'
            + '<i class="bi bi-exclamation-triangle-fill"></i> '
            + '<strong>Hay metros registrados pero no se calcularon materiales.</strong><br>'
            + 'Falta indicar qué trabajo hay que hacer en cada ambiente.</div>';
    } else {
        html += '<p style="margin:0;color:#5b6478;font-size:13.5px;">'
            + 'Todavía no hay reparaciones con metros cuadrados registrados.</p>';
    }

    html += '</div></div>';
    cont.innerHTML = html;
}

/**
 * Vuelve a pintar TODAS las fotos que cuelgan del edificio.
 *
 * Todas se guardan con nivel='edificio' y el campo `parte` dice a que
 * bloque pertenece cada una:
 *   'etiqueta'            -> foto de la etiqueta de la fachada (paso 1)
 *   '<clave_area>'        -> foto de un area comun: 'lobby', 'escaleras'...
 *   '<clave>_reparacion'  -> foto del cierre: 'azotea_reparacion', etc.
 *
 * Antes solo se recuperaba la de etiqueta y las demas se descartaban en
 * el filtro, asi que al reabrir el levantamiento las areas comunes y el
 * cierre aparecian sin foto aunque estuvieran guardadas. El tecnico creia
 * que se habian perdido y volvia a tomarlas, duplicandolas.
 */
function pintarFotosDelEdificio(fotos) {
    if (!Array.isArray(fotos) || !fotos.length) return;

    // Se limpian los contenedores antes de pintar, para poder llamar a
    // esta funcion mas de una vez sin que las fotos salgan repetidas.
    const vaciar = (el) => { if (el) el.innerHTML = ''; };
    vaciar(document.getElementById('etiqueta-fotos'));
    document.querySelectorAll('.area-row .area-fotos').forEach(vaciar);
    document.querySelectorAll('.cierre-foto .cierre-fotos').forEach(vaciar);

    fotos.forEach(f => {
        const parte = String(f.parte || '').trim();
        if (!parte) return;

        // 1) Etiqueta de la fachada.
        if (parte === 'etiqueta') {
            const c = document.getElementById('etiqueta-fotos');
            if (c) agregarMiniFoto(c, f);
            return;
        }

        // 2) Cierre (azotea / tanques / impermeabilizacion).
        if (parte.endsWith('_reparacion')) {
            const key = parte.slice(0, -'_reparacion'.length);
            const bloque = document.getElementById('cierre-foto-' + key);
            const c = bloque ? bloque.querySelector('.cierre-fotos') : null;
            if (c) agregarMiniFoto(c, f);
            return;
        }

        // 3) Area comun: `parte` es la clave del area.
        const row = document.querySelector('.area-row[data-area="' + parte + '"]');
        if (!row) return;
        const c = row.querySelector('.area-fotos');
        if (!c) return;
        agregarMiniFoto(c, f);

        // Si hay foto, el area estaba marcada para reparar: se abre su
        // detalle para que la foto no quede escondida.
        const chk = row.querySelector('.area-reparar');
        if (chk && !chk.checked) {
            chk.checked = true;
            const det = row.querySelector('.area-detalle');
            if (det) det.style.display = 'block';
            const lbl = row.querySelector('.area-chk-lbl');
            if (lbl) {
                lbl.style.background = '#fdf3e7';
                lbl.style.fontWeight = '600';
                lbl.style.color = '#A66A00';
            }
        }
    });
}

// Recuperar las fotos ya guardadas del edificio al abrir el levantamiento.
(function cargarFotosEdificio() {
    fetch(URL_BASE + 'listar_rec_aptos.php?fotos_nivel=edificio&ref_id=' + EDIFICIO_ID)
        .then(r => r.json()).then(d => {
            if (d.ok && d.fotos) pintarFotosDelEdificio(d.fotos);
        }).catch(()=>{});
})();

// Si venimos de guardar el paso 1, abrir directo el recorrido.
<?php if (($_GET['paso'] ?? '') === '2'): ?>
irPaso(2);
<?php endif; ?>
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
